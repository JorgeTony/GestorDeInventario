package com.hospital.inventario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarioBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(InventarioBackendApplication.class, args);
    }
}