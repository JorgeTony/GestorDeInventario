package com.hospital.inventario.repository;

import com.hospital.inventario.model.FamiliaProducto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface FamiliaProductoRepository extends JpaRepository<FamiliaProducto, Long> {
    
    Optional<FamiliaProducto> findByNombre(String nombre);
    
    List<FamiliaProducto> findByNombreContainingIgnoreCase(String nombre);
    
    @Query("SELECT f FROM FamiliaProducto f ORDER BY SIZE(f.lineasProducto) DESC")
    List<FamiliaProducto> findFamiliasOrdenadasPorCantidadLineas();
    
    @Query("SELECT f FROM FamiliaProducto f WHERE SIZE(f.lineasProducto) > 0")
    List<FamiliaProducto> findFamiliasConLineas();
}