package com.hospital.inventario.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "requerimientos")
public class Requerimiento {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "El código del requerimiento es obligatorio")
    @Size(max = 50, message = "El código no puede exceder 50 caracteres")
    @Column(unique = true, nullable = false)
    private String codigo;
    
    @NotBlank(message = "El área solicitante es obligatoria")
    @Size(max = 100, message = "El área no puede exceder 100 caracteres")
    @Column(nullable = false)
    private String areaSolicitante;
    
    @NotBlank(message = "El solicitante es obligatorio")
    @Size(max = 100, message = "El solicitante no puede exceder 100 caracteres")
    @Column(nullable = false)
    private String solicitante;
    
    @NotNull(message = "La fecha de solicitud es obligatoria")
    @Column(name = "fecha_solicitud", nullable = false)
    private LocalDate fechaSolicitud;
    
    @Column(name = "fecha_requerida")
    private LocalDate fechaRequerida;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EstadoRequerimiento estado = EstadoRequerimiento.PENDIENTE;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PrioridadRequerimiento prioridad = PrioridadRequerimiento.NORMAL;
    
    @Size(max = 1000, message = "Las observaciones no pueden exceder 1000 caracteres")
    @Column(columnDefinition = "TEXT")
    private String observaciones;
    
    @OneToMany(mappedBy = "requerimiento", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<DetalleRequerimiento> detalles = new ArrayList<>();
    
    // Constructores
    public Requerimiento() {}
    
    public Requerimiento(String codigo, String areaSolicitante, String solicitante, LocalDate fechaSolicitud) {
        this.codigo = codigo;
        this.areaSolicitante = areaSolicitante;
        this.solicitante = solicitante;
        this.fechaSolicitud = fechaSolicitud;
    }
    
    // Métodos de negocio
    public int getTotalItems() {
        return detalles != null ? detalles.size() : 0;
    }
    
    public boolean estaVencido() {
        return fechaRequerida != null && fechaRequerida.isBefore(LocalDate.now()) && 
               estado != EstadoRequerimiento.COMPLETADO;
    }
    
    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    
    public String getAreaSolicitante() { return areaSolicitante; }
    public void setAreaSolicitante(String areaSolicitante) { this.areaSolicitante = areaSolicitante; }
    
    public String getSolicitante() { return solicitante; }
    public void setSolicitante(String solicitante) { this.solicitante = solicitante; }
    
    public LocalDate getFechaSolicitud() { return fechaSolicitud; }
    public void setFechaSolicitud(LocalDate fechaSolicitud) { this.fechaSolicitud = fechaSolicitud; }
    
    public LocalDate getFechaRequerida() { return fechaRequerida; }
    public void setFechaRequerida(LocalDate fechaRequerida) { this.fechaRequerida = fechaRequerida; }
    
    public EstadoRequerimiento getEstado() { return estado; }
    public void setEstado(EstadoRequerimiento estado) { this.estado = estado; }
    
    public PrioridadRequerimiento getPrioridad() { return prioridad; }
    public void setPrioridad(PrioridadRequerimiento prioridad) { this.prioridad = prioridad; }
    
    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }
    
    public List<DetalleRequerimiento> getDetalles() { return detalles; }
    public void setDetalles(List<DetalleRequerimiento> detalles) { this.detalles = detalles; }
    
    public enum EstadoRequerimiento {
        PENDIENTE, EN_PROCESO, COMPLETADO, CANCELADO
    }
    
    public enum PrioridadRequerimiento {
        BAJA, NORMAL, ALTA, URGENTE
    }
}