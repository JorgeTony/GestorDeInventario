package com.hospital.inventario.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "ordenes_compra")
public class OrdenCompra {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "El código de la orden es obligatorio")
    @Size(max = 50, message = "El código no puede exceder 50 caracteres")
    @Column(unique = true, nullable = false)
    private String codigo;
    
    @NotBlank(message = "El proveedor es obligatorio")
    @Size(max = 200, message = "El proveedor no puede exceder 200 caracteres")
    @Column(nullable = false)
    private String proveedor;
    
    @NotNull(message = "La fecha de orden es obligatoria")
    @Column(name = "fecha_orden", nullable = false)
    private LocalDate fechaOrden;
    
    @Column(name = "fecha_entrega_esperada")
    private LocalDate fechaEntregaEsperada;
    
    @Column(name = "fecha_entrega_real")
    private LocalDate fechaEntregaReal;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EstadoOrden estado = EstadoOrden.PENDIENTE;
    
    @Column(precision = 12, scale = 2)
    private BigDecimal montoTotal = BigDecimal.ZERO;
    
    @Size(max = 1000, message = "Las observaciones no pueden exceder 1000 caracteres")
    @Column(columnDefinition = "TEXT")
    private String observaciones;
    
    @OneToMany(mappedBy = "ordenCompra", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<DetalleOrdenCompra> detalles = new ArrayList<>();
    
    // Constructores
    public OrdenCompra() {}
    
    public OrdenCompra(String codigo, String proveedor, LocalDate fechaOrden) {
        this.codigo = codigo;
        this.proveedor = proveedor;
        this.fechaOrden = fechaOrden;
    }
    
    // Métodos de negocio
    public int getTotalItems() {
        return detalles != null ? detalles.size() : 0;
    }
    
    public BigDecimal calcularMontoTotal() {
        if (detalles == null) return BigDecimal.ZERO;
        return detalles.stream()
                .map(DetalleOrdenCompra::calcularSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    public boolean estaVencida() {
        return fechaEntregaEsperada != null && fechaEntregaEsperada.isBefore(LocalDate.now()) && 
               estado != EstadoOrden.ENTREGADA;
    }
    
    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    
    public String getProveedor() { return proveedor; }
    public void setProveedor(String proveedor) { this.proveedor = proveedor; }
    
    public LocalDate getFechaOrden() { return fechaOrden; }
    public void setFechaOrden(LocalDate fechaOrden) { this.fechaOrden = fechaOrden; }
    
    public LocalDate getFechaEntregaEsperada() { return fechaEntregaEsperada; }
    public void setFechaEntregaEsperada(LocalDate fechaEntregaEsperada) { this.fechaEntregaEsperada = fechaEntregaEsperada; }
    
    public LocalDate getFechaEntregaReal() { return fechaEntregaReal; }
    public void setFechaEntregaReal(LocalDate fechaEntregaReal) { this.fechaEntregaReal = fechaEntregaReal; }
    
    public EstadoOrden getEstado() { return estado; }
    public void setEstado(EstadoOrden estado) { this.estado = estado; }
    
    public BigDecimal getMontoTotal() { return montoTotal; }
    public void setMontoTotal(BigDecimal montoTotal) { this.montoTotal = montoTotal; }
    
    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }
    
    public List<DetalleOrdenCompra> getDetalles() { return detalles; }
    public void setDetalles(List<DetalleOrdenCompra> detalles) { this.detalles = detalles; }
    
    public enum EstadoOrden {
        PENDIENTE, CONFIRMADA, EN_TRANSITO, ENTREGADA, CANCELADA
    }
}