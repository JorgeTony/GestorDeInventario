package com.hospital.inventario.service;

import com.hospital.inventario.model.OrdenCompra;
import com.hospital.inventario.repository.OrdenCompraRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class OrdenCompraService {
    
    @Autowired
    private OrdenCompraRepository ordenCompraRepository;
    
    public List<OrdenCompra> obtenerTodasLasOrdenes() {
        return ordenCompraRepository.findAll();
    }
    
    public Optional<OrdenCompra> obtenerOrdenPorId(Long id) {
        return ordenCompraRepository.findById(id);
    }
    
    public Optional<OrdenCompra> obtenerOrdenPorCodigo(String codigo) {
        return ordenCompraRepository.findByCodigo(codigo);
    }
    
    public OrdenCompra guardarOrden(OrdenCompra ordenCompra) {
        return ordenCompraRepository.save(ordenCompra);
    }
    
    public void eliminarOrden(Long id) {
        ordenCompraRepository.deleteById(id);
    }
    
    public List<OrdenCompra> obtenerOrdenesPorProveedor(String proveedor) {
        return ordenCompraRepository.findByProveedor(proveedor);
    }
    
    public List<OrdenCompra> obtenerOrdenesPorEstado(OrdenCompra.EstadoOrden estado) {
        return ordenCompraRepository.findByEstado(estado);
    }
    
    public List<OrdenCompra> obtenerOrdenesPorPeriodo(LocalDate fechaInicio, LocalDate fechaFin) {
        return ordenCompraRepository.findOrdenesPorPeriodo(fechaInicio, fechaFin);
    }
    
    public List<OrdenCompra> obtenerOrdenesVencidas() {
        return ordenCompraRepository.findOrdenesVencidas(LocalDate.now());
    }
    
    public List<OrdenCompra> obtenerOrdenesPendientes() {
        return ordenCompraRepository.findOrdenesPendientes();
    }
    
    public Double calcularMontoTotalPorPeriodo(LocalDate fechaInicio, LocalDate fechaFin) {
        return ordenCompraRepository.calcularMontoTotalPorPeriodo(fechaInicio, fechaFin);
    }
    
    public boolean existeCodigoOrden(String codigo) {
        return ordenCompraRepository.findByCodigo(codigo).isPresent();
    }
}