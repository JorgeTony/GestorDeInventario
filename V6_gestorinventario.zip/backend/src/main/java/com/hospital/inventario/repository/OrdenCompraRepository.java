package com.hospital.inventario.repository;

import com.hospital.inventario.model.OrdenCompra;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface OrdenCompraRepository extends JpaRepository<OrdenCompra, Long> {
    
    Optional<OrdenCompra> findByCodigo(String codigo);
    
    List<OrdenCompra> findByProveedor(String proveedor);
    
    List<OrdenCompra> findByEstado(OrdenCompra.EstadoOrden estado);
    
    @Query("SELECT o FROM OrdenCompra o WHERE o.fechaOrden BETWEEN :fechaInicio AND :fechaFin ORDER BY o.fechaOrden DESC")
    List<OrdenCompra> findOrdenesPorPeriodo(@Param("fechaInicio") LocalDate fechaInicio, 
                                           @Param("fechaFin") LocalDate fechaFin);
    
    @Query("SELECT o FROM OrdenCompra o WHERE o.fechaEntregaEsperada < :fecha AND o.estado != 'ENTREGADA'")
    List<OrdenCompra> findOrdenesVencidas(@Param("fecha") LocalDate fecha);
    
    @Query("SELECT o FROM OrdenCompra o WHERE o.estado = 'PENDIENTE' ORDER BY o.fechaOrden ASC")
    List<OrdenCompra> findOrdenesPendientes();
    
    @Query("SELECT SUM(o.montoTotal) FROM OrdenCompra o WHERE o.fechaOrden BETWEEN :fechaInicio AND :fechaFin")
    Double calcularMontoTotalPorPeriodo(@Param("fechaInicio") LocalDate fechaInicio, 
                                       @Param("fechaFin") LocalDate fechaFin);
}