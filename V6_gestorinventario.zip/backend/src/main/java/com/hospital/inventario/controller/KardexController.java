package com.hospital.inventario.controller;

import com.hospital.inventario.service.TransaccionService;
import com.hospital.inventario.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/kardex")
public class KardexController {
    
    @Autowired
    private TransaccionService transaccionService;
    
    @Autowired
    private ProductoService productoService;
    
    @GetMapping
    public String kardex(@RequestParam(required = false) Long productoId,
                        @RequestParam(required = false) String buscar,
                        Model model) {
        
        // Productos para el selector
        model.addAttribute("productos", productoService.obtenerTodosLosProductos());
        
        if (productoId != null) {
            // Mostrar kardex de producto específico
            productoService.obtenerProductoPorId(productoId)
                    .ifPresent(producto -> {
                        model.addAttribute("productoSeleccionado", producto);
                        model.addAttribute("historialTransacciones", 
                                transaccionService.obtenerHistorialProducto(producto));
                    });
        } else if (buscar != null && !buscar.trim().isEmpty()) {
            // Buscar productos
            model.addAttribute("productosEncontrados", productoService.buscarProductos(buscar));
            model.addAttribute("buscar", buscar);
        } else {
            // Vista general del kardex
            model.addAttribute("ultimasTransacciones", transaccionService.obtenerUltimasTransacciones());
        }
        
        return "kardex";
    }
}