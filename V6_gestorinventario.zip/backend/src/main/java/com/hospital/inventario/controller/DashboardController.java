package com.hospital.inventario.controller;

import com.hospital.inventario.service.ProductoService;
import com.hospital.inventario.service.TransaccionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/dashboard")
public class DashboardController {
    
    @Autowired
    private ProductoService productoService;
    
    @Autowired
    private TransaccionService transaccionService;
    
    @GetMapping
    public String dashboard(Model model) {
        // Métricas principales
        model.addAttribute("totalProductos", productoService.contarProductosActivos());
        model.addAttribute("valorInventario", productoService.calcularValorTotalInventario());
        model.addAttribute("productosStockBajo", productoService.obtenerProductosConStockBajo().size());
        model.addAttribute("productosProximosVencer", productoService.obtenerProductosProximosAVencer(30).size());
        
        // Productos destacados
        model.addAttribute("productosStockBajoDetalle", productoService.obtenerProductosConStockBajo());
        model.addAttribute("productosProximosVencerDetalle", productoService.obtenerProductosProximosAVencer(30));
        
        // Últimas transacciones
        model.addAttribute("ultimasTransacciones", transaccionService.obtenerUltimasTransacciones());
        
        return "dashboard";
    }
}