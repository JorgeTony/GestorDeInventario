package com.hospital.inventario.service;

import com.hospital.inventario.model.Producto;
import com.hospital.inventario.model.Categoria;
import com.hospital.inventario.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ProductoService {
    
    @Autowired
    private ProductoRepository productoRepository;
    
    public List<Producto> obtenerTodosLosProductos() {
        return productoRepository.findAll();
    }
    
    public Optional<Producto> obtenerProductoPorId(Long id) {
        return productoRepository.findById(id);
    }
    
    public Optional<Producto> obtenerProductoPorCodigo(String codigo) {
        return productoRepository.findByCodigo(codigo);
    }
    
    public Producto guardarProducto(Producto producto) {
        return productoRepository.save(producto);
    }
    
    public void eliminarProducto(Long id) {
        productoRepository.deleteById(id);
    }
    
    public List<Producto> buscarProductosPorNombre(String nombre) {
        return productoRepository.findByNombreContainingIgnoreCase(nombre);
    }
    
    public List<Producto> obtenerProductosPorCategoria(Categoria categoria) {
        return productoRepository.findByCategoria(categoria);
    }
    
    public List<Producto> obtenerProductosConStockBajo() {
        return productoRepository.findProductosConStockBajo();
    }
    
    public List<Producto> obtenerProductosConStockCritico() {
        return productoRepository.findProductosConStockCritico();
    }
    
    public List<Producto> obtenerProductosProximosAVencer(int dias) {
        LocalDate fechaLimite = LocalDate.now().plusDays(dias);
        return productoRepository.findProductosProximosAVencer(LocalDate.now(), fechaLimite);
    }
    
    public Double calcularValorTotalInventario() {
        return productoRepository.calcularValorTotalInventario();
    }
    
    public List<Producto> buscarProductos(String termino) {
        return productoRepository.buscarPorTermino(termino);
    }
    
    public Producto actualizarStock(Long productoId, Integer nuevoStock) {
        Optional<Producto> productoOpt = productoRepository.findById(productoId);
        if (productoOpt.isPresent()) {
            Producto producto = productoOpt.get();
            producto.setStockActual(nuevoStock);
            return productoRepository.save(producto);
        }
        throw new RuntimeException("Producto no encontrado con ID: " + productoId);
    }
    
    public boolean existeCodigoProducto(String codigo) {
        return productoRepository.findByCodigo(codigo).isPresent();
    }
    
    public long contarProductosActivos() {
        return productoRepository.findAll().stream()
                .filter(p -> p.getEstado() == Producto.EstadoProducto.ACTIVO)
                .count();
    }
}