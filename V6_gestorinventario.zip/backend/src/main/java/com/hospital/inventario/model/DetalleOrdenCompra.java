package com.hospital.inventario.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import java.math.BigDecimal;

@Entity
@Table(name = "detalle_ordenes_compra")
public class DetalleOrdenCompra {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "orden_compra_id", nullable = false)
    private OrdenCompra ordenCompra;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "producto_id", nullable = false)
    private Producto producto;
    
    @NotNull(message = "La cantidad es obligatoria")
    @Min(value = 1, message = "La cantidad debe ser mayor a 0")
    @Column(nullable = false)
    private Integer cantidad;
    
    @DecimalMin(value = "0.0", inclusive = false, message = "El precio debe ser mayor a 0")
    @Digits(integer = 10, fraction = 2, message = "Formato de precio inválido")
    @Column(precision = 12, scale = 2, nullable = false)
    private BigDecimal precioUnitario;
    
    @Min(value = 0, message = "La cantidad recibida no puede ser negativa")
    private Integer cantidadRecibida = 0;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EstadoDetalleOrden estado = EstadoDetalleOrden.PENDIENTE;
    
    // Constructores
    public DetalleOrdenCompra() {}
    
    public DetalleOrdenCompra(OrdenCompra ordenCompra, Producto producto, Integer cantidad, BigDecimal precioUnitario) {
        this.ordenCompra = ordenCompra;
        this.producto = producto;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
    }
    
    // Métodos de negocio
    public BigDecimal calcularSubtotal() {
        if (cantidad != null && precioUnitario != null) {
            return precioUnitario.multiply(BigDecimal.valueOf(cantidad));
        }
        return BigDecimal.ZERO;
    }
    
    public boolean estaCompleto() {
        return cantidadRecibida != null && cantidad != null && cantidadRecibida.equals(cantidad);
    }
    
    public Integer getCantidadPendiente() {
        if (cantidad == null) return 0;
        if (cantidadRecibida == null) return cantidad;
        return cantidad - cantidadRecibida;
    }
    
    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public OrdenCompra getOrdenCompra() { return ordenCompra; }
    public void setOrdenCompra(OrdenCompra ordenCompra) { this.ordenCompra = ordenCompra; }
    
    public Producto getProducto() { return producto; }
    public void setProducto(Producto producto) { this.producto = producto; }
    
    public Integer getCantidad() { return cantidad; }
    public void setCantidad(Integer cantidad) { this.cantidad = cantidad; }
    
    public BigDecimal getPrecioUnitario() { return precioUnitario; }
    public void setPrecioUnitario(BigDecimal precioUnitario) { this.precioUnitario = precioUnitario; }
    
    public Integer getCantidadRecibida() { return cantidadRecibida; }
    public void setCantidadRecibida(Integer cantidadRecibida) { this.cantidadRecibida = cantidadRecibida; }
    
    public EstadoDetalleOrden getEstado() { return estado; }
    public void setEstado(EstadoDetalleOrden estado) { this.estado = estado; }
    
    public enum EstadoDetalleOrden {
        PENDIENTE, PARCIAL, COMPLETO, CANCELADO
    }
}