package com.hospital.inventario.repository;

import com.hospital.inventario.model.Requerimiento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface RequerimientoRepository extends JpaRepository<Requerimiento, Long> {
    
    Optional<Requerimiento> findByCodigo(String codigo);
    
    List<Requerimiento> findByAreaSolicitante(String areaSolicitante);
    
    List<Requerimiento> findByEstado(Requerimiento.EstadoRequerimiento estado);
    
    List<Requerimiento> findByPrioridad(Requerimiento.PrioridadRequerimiento prioridad);
    
    @Query("SELECT r FROM Requerimiento r WHERE r.fechaSolicitud BETWEEN :fechaInicio AND :fechaFin ORDER BY r.fechaSolicitud DESC")
    List<Requerimiento> findRequerimientosPorPeriodo(@Param("fechaInicio") LocalDate fechaInicio, 
                                                    @Param("fechaFin") LocalDate fechaFin);
    
    @Query("SELECT r FROM Requerimiento r WHERE r.fechaRequerida < :fecha AND r.estado != 'COMPLETADO'")
    List<Requerimiento> findRequerimientosVencidos(@Param("fecha") LocalDate fecha);
    
    @Query("SELECT r FROM Requerimiento r WHERE r.estado = 'PENDIENTE' ORDER BY r.prioridad DESC, r.fechaSolicitud ASC")
    List<Requerimiento> findRequerimientosPendientesOrdenados();
}