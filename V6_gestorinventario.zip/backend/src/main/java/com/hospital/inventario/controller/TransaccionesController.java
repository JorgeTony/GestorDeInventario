package com.hospital.inventario.controller;

import com.hospital.inventario.model.Transaccion;
import com.hospital.inventario.service.TransaccionService;
import com.hospital.inventario.service.ProductoService;
import com.hospital.inventario.service.AlmacenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import jakarta.validation.Valid;
import java.time.LocalDateTime;
import java.time.LocalDate;

@Controller
@RequestMapping("/transacciones")
public class TransaccionesController {
    
    @Autowired
    private TransaccionService transaccionService;
    
    @Autowired
    private ProductoService productoService;
    
    @Autowired
    private AlmacenService almacenService;
    
    @GetMapping
    public String listarTransacciones(@RequestParam(required = false) String tipo,
                                     @RequestParam(required = false) String fechaInicio,
                                     @RequestParam(required = false) String fechaFin,
                                     Model model) {
        
        // Fechas por defecto (última semana)
        LocalDate inicio = fechaInicio != null ? LocalDate.parse(fechaInicio) : LocalDate.now().minusWeeks(1);
        LocalDate fin = fechaFin != null ? LocalDate.parse(fechaFin) : LocalDate.now();
        
        model.addAttribute("fechaInicio", inicio);
        model.addAttribute("fechaFin", fin);
        
        // Filtrar por tipo si se especifica
        if (tipo != null && !tipo.isEmpty()) {
            Transaccion.TipoTransaccion tipoEnum = Transaccion.TipoTransaccion.valueOf(tipo.toUpperCase());
            model.addAttribute("transacciones", transaccionService.obtenerTransaccionesPorTipo(tipoEnum));
            model.addAttribute("tipoSeleccionado", tipo);
        } else {
            LocalDateTime inicioDateTime = inicio.atStartOfDay();
            LocalDateTime finDateTime = fin.atTime(23, 59, 59);
            model.addAttribute("transacciones", transaccionService.obtenerTransaccionesPorPeriodo(inicioDateTime, finDateTime));
        }
        
        return "transacciones";
    }
    
    @GetMapping("/nueva")
    public String mostrarFormularioNueva(Model model) {
        model.addAttribute("transaccion", new Transaccion());
        model.addAttribute("productos", productoService.obtenerTodosLosProductos());
        model.addAttribute("almacenes", almacenService.obtenerAlmacenesActivos());
        return "transaccion-form";
    }
    
    @PostMapping("/guardar")
    public String guardarTransaccion(@Valid @ModelAttribute Transaccion transaccion,
                                    BindingResult result,
                                    RedirectAttributes redirectAttributes,
                                    Model model) {
        if (result.hasErrors()) {
            model.addAttribute("productos", productoService.obtenerTodosLosProductos());
            model.addAttribute("almacenes", almacenService.obtenerAlmacenesActivos());
            return "transaccion-form";
        }
        
        try {
            transaccionService.guardarTransaccion(transaccion);
            redirectAttributes.addFlashAttribute("mensaje", "Transacción registrada exitosamente");
            redirectAttributes.addFlashAttribute("tipoMensaje", "success");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al registrar la transacción: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipoMensaje", "error");
        }
        
        return "redirect:/transacciones";
    }
    
    @GetMapping("/detalle/{id}")
    public String verDetalle(@PathVariable Long id, Model model) {
        transaccionService.obtenerTransaccionPorId(id)
                .ifPresent(transaccion -> model.addAttribute("transaccion", transaccion));
        return "transaccion-detalle";
    }
}