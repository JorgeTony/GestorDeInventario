package com.hospital.inventario.repository;

import com.hospital.inventario.model.LineaProducto;
import com.hospital.inventario.model.FamiliaProducto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface LineaProductoRepository extends JpaRepository<LineaProducto, Long> {
    
    Optional<LineaProducto> findByNombre(String nombre);
    
    List<LineaProducto> findByFamiliaProducto(FamiliaProducto familiaProducto);
    
    List<LineaProducto> findByNombreContainingIgnoreCase(String nombre);
    
    @Query("SELECT l FROM LineaProducto l ORDER BY SIZE(l.productos) DESC")
    List<LineaProducto> findLineasOrdenadasPorCantidadProductos();
    
    @Query("SELECT l FROM LineaProducto l WHERE SIZE(l.productos) > 0")
    List<LineaProducto> findLineasConProductos();
}