package com.hospital.inventario.service;

import com.hospital.inventario.model.Almacen;
import com.hospital.inventario.repository.AlmacenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class AlmacenService {
    
    @Autowired
    private AlmacenRepository almacenRepository;
    
    public List<Almacen> obtenerTodosLosAlmacenes() {
        return almacenRepository.findAll();
    }
    
    public Optional<Almacen> obtenerAlmacenPorId(Long id) {
        return almacenRepository.findById(id);
    }
    
    public Optional<Almacen> obtenerAlmacenPorCodigo(String codigo) {
        return almacenRepository.findByCodigo(codigo);
    }
    
    public Almacen guardarAlmacen(Almacen almacen) {
        return almacenRepository.save(almacen);
    }
    
    public void eliminarAlmacen(Long id) {
        almacenRepository.deleteById(id);
    }
    
    public List<Almacen> obtenerAlmacenesActivos() {
        return almacenRepository.findAlmacenesActivos();
    }
    
    public List<Almacen> obtenerAlmacenesPorEstado(Almacen.EstadoAlmacen estado) {
        return almacenRepository.findByEstado(estado);
    }
    
    public List<Almacen> buscarAlmacenesPorNombre(String nombre) {
        return almacenRepository.findByNombreContainingIgnoreCase(nombre);
    }
    
    public List<Almacen> obtenerAlmacenesConProductos() {
        return almacenRepository.findAlmacenesConProductos();
    }
    
    public boolean existeCodigoAlmacen(String codigo) {
        return almacenRepository.findByCodigo(codigo).isPresent();
    }
}