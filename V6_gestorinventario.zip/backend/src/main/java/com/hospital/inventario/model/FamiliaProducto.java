package com.hospital.inventario.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "familias_producto")
public class FamiliaProducto {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "El nombre de la familia es obligatorio")
    @Size(max = 100, message = "El nombre no puede exceder 100 caracteres")
    @Column(unique = true, nullable = false)
    private String nombre;
    
    @Size(max = 500, message = "La descripción no puede exceder 500 caracteres")
    @Column(columnDefinition = "TEXT")
    private String descripcion;
    
    @OneToMany(mappedBy = "familiaProducto", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<LineaProducto> lineasProducto = new ArrayList<>();
    
    // Constructores
    public FamiliaProducto() {}
    
    public FamiliaProducto(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }
    
    // Métodos de negocio
    public int getTotalLineas() {
        return lineasProducto != null ? lineasProducto.size() : 0;
    }
    
    public int getTotalProductos() {
        if (lineasProducto == null) return 0;
        return lineasProducto.stream()
                .mapToInt(LineaProducto::getTotalProductos)
                .sum();
    }
    
    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    
    public List<LineaProducto> getLineasProducto() { return lineasProducto; }
    public void setLineasProducto(List<LineaProducto> lineasProducto) { this.lineasProducto = lineasProducto; }
}