package com.hospital.inventario.controller;

import com.hospital.inventario.service.ProductoService;
import com.hospital.inventario.service.CategoriaService;
import com.hospital.inventario.service.AlmacenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    
    @Autowired
    private ProductoService productoService;
    
    @Autowired
    private CategoriaService categoriaService;
    
    @Autowired
    private AlmacenService almacenService;
    
    @GetMapping("/")
    public String home(Model model) {
        // Estadísticas para el dashboard
        model.addAttribute("totalProductos", productoService.contarProductosActivos());
        model.addAttribute("totalCategorias", categoriaService.obtenerTodasLasCategorias().size());
        model.addAttribute("totalAlmacenes", almacenService.obtenerAlmacenesActivos().size());
        model.addAttribute("valorInventario", productoService.calcularValorTotalInventario());
        
        // Alertas
        model.addAttribute("productosStockBajo", productoService.obtenerProductosConStockBajo());
        model.addAttribute("productosProximosVencer", productoService.obtenerProductosProximosAVencer(30));
        
        return "index";
    }
}