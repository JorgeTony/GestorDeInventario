package com.hospital.inventario.repository;

import com.hospital.inventario.model.Transaccion;
import com.hospital.inventario.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TransaccionRepository extends JpaRepository<Transaccion, Long> {
    
    List<Transaccion> findByProducto(Producto producto);
    
    List<Transaccion> findByTipo(Transaccion.TipoTransaccion tipo);
    
    List<Transaccion> findByUsuario(String usuario);
    
    @Query("SELECT t FROM Transaccion t WHERE t.fechaTransaccion BETWEEN :fechaInicio AND :fechaFin ORDER BY t.fechaTransaccion DESC")
    List<Transaccion> findTransaccionesPorPeriodo(@Param("fechaInicio") LocalDateTime fechaInicio, 
                                                 @Param("fechaFin") LocalDateTime fechaFin);
    
    @Query("SELECT t FROM Transaccion t WHERE t.producto = :producto ORDER BY t.fechaTransaccion DESC")
    List<Transaccion> findHistorialProducto(@Param("producto") Producto producto);
    
    @Query("SELECT t FROM Transaccion t ORDER BY t.fechaTransaccion DESC")
    List<Transaccion> findUltimasTransacciones();
    
    @Query("SELECT COUNT(t) FROM Transaccion t WHERE t.tipo = :tipo AND t.fechaTransaccion >= :fecha")
    long countTransaccionesPorTipoDesde(@Param("tipo") Transaccion.TipoTransaccion tipo, 
                                       @Param("fecha") LocalDateTime fecha);
}