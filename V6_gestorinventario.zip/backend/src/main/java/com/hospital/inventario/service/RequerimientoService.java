package com.hospital.inventario.service;

import com.hospital.inventario.model.Requerimiento;
import com.hospital.inventario.repository.RequerimientoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class RequerimientoService {
    
    @Autowired
    private RequerimientoRepository requerimientoRepository;
    
    public List<Requerimiento> obtenerTodosLosRequerimientos() {
        return requerimientoRepository.findAll();
    }
    
    public Optional<Requerimiento> obtenerRequerimientoPorId(Long id) {
        return requerimientoRepository.findById(id);
    }
    
    public Optional<Requerimiento> obtenerRequerimientoPorCodigo(String codigo) {
        return requerimientoRepository.findByCodigo(codigo);
    }
    
    public Requerimiento guardarRequerimiento(Requerimiento requerimiento) {
        return requerimientoRepository.save(requerimiento);
    }
    
    public void eliminarRequerimiento(Long id) {
        requerimientoRepository.deleteById(id);
    }
    
    public List<Requerimiento> obtenerRequerimientosPorArea(String areaSolicitante) {
        return requerimientoRepository.findByAreaSolicitante(areaSolicitante);
    }
    
    public List<Requerimiento> obtenerRequerimientosPorEstado(Requerimiento.EstadoRequerimiento estado) {
        return requerimientoRepository.findByEstado(estado);
    }
    
    public List<Requerimiento> obtenerRequerimientosPorPrioridad(Requerimiento.PrioridadRequerimiento prioridad) {
        return requerimientoRepository.findByPrioridad(prioridad);
    }
    
    public List<Requerimiento> obtenerRequerimientosPorPeriodo(LocalDate fechaInicio, LocalDate fechaFin) {
        return requerimientoRepository.findRequerimientosPorPeriodo(fechaInicio, fechaFin);
    }
    
    public List<Requerimiento> obtenerRequerimientosVencidos() {
        return requerimientoRepository.findRequerimientosVencidos(LocalDate.now());
    }
    
    public List<Requerimiento> obtenerRequerimientosPendientesOrdenados() {
        return requerimientoRepository.findRequerimientosPendientesOrdenados();
    }
    
    public boolean existeCodigoRequerimiento(String codigo) {
        return requerimientoRepository.findByCodigo(codigo).isPresent();
    }
}