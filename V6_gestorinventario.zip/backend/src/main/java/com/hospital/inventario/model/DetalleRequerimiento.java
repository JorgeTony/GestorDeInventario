package com.hospital.inventario.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Min;

@Entity
@Table(name = "detalle_requerimientos")
public class DetalleRequerimiento {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requerimiento_id", nullable = false)
    private Requerimiento requerimiento;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "producto_id", nullable = false)
    private Producto producto;
    
    @NotNull(message = "La cantidad solicitada es obligatoria")
    @Min(value = 1, message = "La cantidad debe ser mayor a 0")
    @Column(nullable = false)
    private Integer cantidadSolicitada;
    
    @Min(value = 0, message = "La cantidad entregada no puede ser negativa")
    private Integer cantidadEntregada = 0;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EstadoDetalle estado = EstadoDetalle.PENDIENTE;
    
    // Constructores
    public DetalleRequerimiento() {}
    
    public DetalleRequerimiento(Requerimiento requerimiento, Producto producto, Integer cantidadSolicitada) {
        this.requerimiento = requerimiento;
        this.producto = producto;
        this.cantidadSolicitada = cantidadSolicitada;
    }
    
    // Métodos de negocio
    public boolean estaCompleto() {
        return cantidadEntregada != null && cantidadSolicitada != null && 
               cantidadEntregada.equals(cantidadSolicitada);
    }
    
    public Integer getCantidadPendiente() {
        if (cantidadSolicitada == null) return 0;
        if (cantidadEntregada == null) return cantidadSolicitada;
        return cantidadSolicitada - cantidadEntregada;
    }
    
    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public Requerimiento getRequerimiento() { return requerimiento; }
    public void setRequerimiento(Requerimiento requerimiento) { this.requerimiento = requerimiento; }
    
    public Producto getProducto() { return producto; }
    public void setProducto(Producto producto) { this.producto = producto; }
    
    public Integer getCantidadSolicitada() { return cantidadSolicitada; }
    public void setCantidadSolicitada(Integer cantidadSolicitada) { this.cantidadSolicitada = cantidadSolicitada; }
    
    public Integer getCantidadEntregada() { return cantidadEntregada; }
    public void setCantidadEntregada(Integer cantidadEntregada) { this.cantidadEntregada = cantidadEntregada; }
    
    public EstadoDetalle getEstado() { return estado; }
    public void setEstado(EstadoDetalle estado) { this.estado = estado; }
    
    public enum EstadoDetalle {
        PENDIENTE, PARCIAL, COMPLETO, CANCELADO
    }
}