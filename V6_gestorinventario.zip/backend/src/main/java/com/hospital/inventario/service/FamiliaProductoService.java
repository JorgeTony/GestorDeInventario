package com.hospital.inventario.service;

import com.hospital.inventario.model.FamiliaProducto;
import com.hospital.inventario.repository.FamiliaProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class FamiliaProductoService {
    
    @Autowired
    private FamiliaProductoRepository familiaProductoRepository;
    
    public List<FamiliaProducto> obtenerTodasLasFamilias() {
        return familiaProductoRepository.findAll();
    }
    
    public Optional<FamiliaProducto> obtenerFamiliaPorId(Long id) {
        return familiaProductoRepository.findById(id);
    }
    
    public Optional<FamiliaProducto> obtenerFamiliaPorNombre(String nombre) {
        return familiaProductoRepository.findByNombre(nombre);
    }
    
    public FamiliaProducto guardarFamilia(FamiliaProducto familiaProducto) {
        return familiaProductoRepository.save(familiaProducto);
    }
    
    public void eliminarFamilia(Long id) {
        familiaProductoRepository.deleteById(id);
    }
    
    public List<FamiliaProducto> buscarFamiliasPorNombre(String nombre) {
        return familiaProductoRepository.findByNombreContainingIgnoreCase(nombre);
    }
    
    public List<FamiliaProducto> obtenerFamiliasOrdenadasPorLineas() {
        return familiaProductoRepository.findFamiliasOrdenadasPorCantidadLineas();
    }
    
    public List<FamiliaProducto> obtenerFamiliasConLineas() {
        return familiaProductoRepository.findFamiliasConLineas();
    }
    
    public boolean existeNombreFamilia(String nombre) {
        return familiaProductoRepository.findByNombre(nombre).isPresent();
    }
}