package com.hospital.inventario.service;

import com.hospital.inventario.model.Transaccion;
import com.hospital.inventario.model.Producto;
import com.hospital.inventario.repository.TransaccionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class TransaccionService {
    
    @Autowired
    private TransaccionRepository transaccionRepository;
    
    public List<Transaccion> obtenerTodasLasTransacciones() {
        return transaccionRepository.findAll();
    }
    
    public Optional<Transaccion> obtenerTransaccionPorId(Long id) {
        return transaccionRepository.findById(id);
    }
    
    public Transaccion guardarTransaccion(Transaccion transaccion) {
        return transaccionRepository.save(transaccion);
    }
    
    public void eliminarTransaccion(Long id) {
        transaccionRepository.deleteById(id);
    }
    
    public List<Transaccion> obtenerTransaccionesPorProducto(Producto producto) {
        return transaccionRepository.findByProducto(producto);
    }
    
    public List<Transaccion> obtenerTransaccionesPorTipo(Transaccion.TipoTransaccion tipo) {
        return transaccionRepository.findByTipo(tipo);
    }
    
    public List<Transaccion> obtenerTransaccionesPorUsuario(String usuario) {
        return transaccionRepository.findByUsuario(usuario);
    }
    
    public List<Transaccion> obtenerTransaccionesPorPeriodo(LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        return transaccionRepository.findTransaccionesPorPeriodo(fechaInicio, fechaFin);
    }
    
    public List<Transaccion> obtenerHistorialProducto(Producto producto) {
        return transaccionRepository.findHistorialProducto(producto);
    }
    
    public List<Transaccion> obtenerUltimasTransacciones() {
        return transaccionRepository.findUltimasTransacciones();
    }
    
    public long contarTransaccionesPorTipoDesde(Transaccion.TipoTransaccion tipo, LocalDateTime fecha) {
        return transaccionRepository.countTransaccionesPorTipoDesde(tipo, fecha);
    }
}