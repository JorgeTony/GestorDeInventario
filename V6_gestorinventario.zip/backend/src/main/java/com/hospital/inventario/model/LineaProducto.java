package com.hospital.inventario.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "lineas_producto")
public class LineaProducto {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "El nombre de la línea es obligatorio")
    @Size(max = 100, message = "El nombre no puede exceder 100 caracteres")
    @Column(unique = true, nullable = false)
    private String nombre;
    
    @Size(max = 500, message = "La descripción no puede exceder 500 caracteres")
    @Column(columnDefinition = "TEXT")
    private String descripcion;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "familia_producto_id")
    private FamiliaProducto familiaProducto;
    
    @OneToMany(mappedBy = "lineaProducto", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Producto> productos = new ArrayList<>();
    
    // Constructores
    public LineaProducto() {}
    
    public LineaProducto(String nombre, String descripcion, FamiliaProducto familiaProducto) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.familiaProducto = familiaProducto;
    }
    
    // Métodos de negocio
    public int getTotalProductos() {
        return productos != null ? productos.size() : 0;
    }
    
    public long getProductosActivos() {
        return productos != null ? 
            productos.stream().filter(p -> p.getEstado() == Producto.EstadoProducto.ACTIVO).count() : 0;
    }
    
    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    
    public FamiliaProducto getFamiliaProducto() { return familiaProducto; }
    public void setFamiliaProducto(FamiliaProducto familiaProducto) { this.familiaProducto = familiaProducto; }
    
    public List<Producto> getProductos() { return productos; }
    public void setProductos(List<Producto> productos) { this.productos = productos; }
}