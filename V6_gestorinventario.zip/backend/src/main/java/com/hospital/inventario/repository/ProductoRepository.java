package com.hospital.inventario.repository;

import com.hospital.inventario.model.Producto;
import com.hospital.inventario.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {
    
    Optional<Producto> findByCodigo(String codigo);
    
    List<Producto> findByCategoria(Categoria categoria);
    
    List<Producto> findByNombreContainingIgnoreCase(String nombre);
    
    @Query("SELECT p FROM Producto p WHERE p.stockActual <= p.stockMinimo")
    List<Producto> findProductosConStockBajo();
    
    @Query("SELECT p FROM Producto p WHERE p.stockActual < (p.stockMinimo * 0.5)")
    List<Producto> findProductosConStockCritico();
    
    @Query("SELECT p FROM Producto p WHERE p.fechaVencimiento BETWEEN :fechaInicio AND :fechaFin")
    List<Producto> findProductosProximosAVencer(@Param("fechaInicio") LocalDate fechaInicio, 
                                               @Param("fechaFin") LocalDate fechaFin);
    
    @Query("SELECT p FROM Producto p WHERE p.estado = 'ACTIVO' ORDER BY p.stockActual DESC")
    List<Producto> findProductosActivosOrdenadosPorStock();
    
    @Query("SELECT COUNT(p) FROM Producto p WHERE p.categoria = :categoria AND p.estado = 'ACTIVO'")
    long countProductosActivosPorCategoria(@Param("categoria") Categoria categoria);
    
    @Query("SELECT SUM(p.stockActual * p.precioUnitario) FROM Producto p WHERE p.estado = 'ACTIVO'")
    Double calcularValorTotalInventario();
    
    @Query("SELECT p FROM Producto p WHERE p.nombre LIKE %:termino% OR p.codigo LIKE %:termino%")
    List<Producto> buscarPorTermino(@Param("termino") String termino);
}