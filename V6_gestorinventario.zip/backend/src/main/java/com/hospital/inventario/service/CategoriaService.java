package com.hospital.inventario.service;

import com.hospital.inventario.model.Categoria;
import com.hospital.inventario.repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class CategoriaService {
    
    @Autowired
    private CategoriaRepository categoriaRepository;
    
    public List<Categoria> obtenerTodasLasCategorias() {
        return categoriaRepository.findAll();
    }
    
    public Optional<Categoria> obtenerCategoriaPorId(Long id) {
        return categoriaRepository.findById(id);
    }
    
    public Optional<Categoria> obtenerCategoriaPorNombre(String nombre) {
        return categoriaRepository.findByNombre(nombre);
    }
    
    public Categoria guardarCategoria(Categoria categoria) {
        return categoriaRepository.save(categoria);
    }
    
    public void eliminarCategoria(Long id) {
        categoriaRepository.deleteById(id);
    }
    
    public List<Categoria> buscarCategoriasPorNombre(String nombre) {
        return categoriaRepository.findByNombreContainingIgnoreCase(nombre);
    }
    
    public List<Categoria> obtenerCategoriasConProductos() {
        return categoriaRepository.findCategoriasConProductos();
    }
    
    public List<Categoria> obtenerCategoriasOrdenadasPorProductos() {
        return categoriaRepository.findCategoriasOrdenadasPorCantidadProductos();
    }
    
    public boolean existeNombreCategoria(String nombre) {
        return categoriaRepository.findByNombre(nombre).isPresent();
    }
}