package com.hospital.inventario.controller;

import com.hospital.inventario.service.ProductoService;
import com.hospital.inventario.service.AlmacenService;
import com.hospital.inventario.service.TransaccionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/inventario")
public class InventarioController {
    
    @Autowired
    private ProductoService productoService;
    
    @Autowired
    private AlmacenService almacenService;
    
    @Autowired
    private TransaccionService transaccionService;
    
    @GetMapping
    public String inventario(@RequestParam(required = false) String filtro, Model model) {
        // Productos según filtro
        if ("stock-bajo".equals(filtro)) {
            model.addAttribute("productos", productoService.obtenerProductosConStockBajo());
            model.addAttribute("filtroActivo", "Stock Bajo");
        } else if ("stock-critico".equals(filtro)) {
            model.addAttribute("productos", productoService.obtenerProductosConStockCritico());
            model.addAttribute("filtroActivo", "Stock Crítico");
        } else if ("proximos-vencer".equals(filtro)) {
            model.addAttribute("productos", productoService.obtenerProductosProximosAVencer(30));
            model.addAttribute("filtroActivo", "Próximos a Vencer");
        } else {
            model.addAttribute("productos", productoService.obtenerTodosLosProductos());
            model.addAttribute("filtroActivo", "Todos");
        }
        
        // Estadísticas
        model.addAttribute("totalProductos", productoService.contarProductosActivos());
        model.addAttribute("valorInventario", productoService.calcularValorTotalInventario());
        model.addAttribute("productosStockBajo", productoService.obtenerProductosConStockBajo().size());
        model.addAttribute("productosStockCritico", productoService.obtenerProductosConStockCritico().size());
        
        // Almacenes
        model.addAttribute("almacenes", almacenService.obtenerAlmacenesActivos());
        
        return "inventario";
    }
}