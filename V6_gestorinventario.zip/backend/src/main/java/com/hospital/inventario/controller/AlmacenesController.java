package com.hospital.inventario.controller;

import com.hospital.inventario.model.Almacen;
import com.hospital.inventario.service.AlmacenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import jakarta.validation.Valid;
import java.util.Optional;

@Controller
@RequestMapping("/almacenes")
public class AlmacenesController {
    
    @Autowired
    private AlmacenService almacenService;
    
    @GetMapping
    public String listarAlmacenes(@RequestParam(required = false) String buscar,
                                 @RequestParam(required = false) String estado,
                                 Model model) {
        if (buscar != null && !buscar.trim().isEmpty()) {
            model.addAttribute("almacenes", almacenService.buscarAlmacenesPorNombre(buscar));
            model.addAttribute("buscar", buscar);
        } else if (estado != null && !estado.isEmpty()) {
            Almacen.EstadoAlmacen estadoEnum = Almacen.EstadoAlmacen.valueOf(estado.toUpperCase());
            model.addAttribute("almacenes", almacenService.obtenerAlmacenesPorEstado(estadoEnum));
            model.addAttribute("estadoSeleccionado", estado);
        } else {
            model.addAttribute("almacenes", almacenService.obtenerTodosLosAlmacenes());
        }
        
        return "almacenes";
    }
    
    @GetMapping("/nuevo")
    public String mostrarFormularioNuevo(Model model) {
        model.addAttribute("almacen", new Almacen());
        return "almacen-form";
    }
    
    @PostMapping("/guardar")
    public String guardarAlmacen(@Valid @ModelAttribute Almacen almacen,
                                BindingResult result,
                                RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "almacen-form";
        }
        
        try {
            almacenService.guardarAlmacen(almacen);
            redirectAttributes.addFlashAttribute("mensaje", "Almacén guardado exitosamente");
            redirectAttributes.addFlashAttribute("tipoMensaje", "success");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al guardar el almacén: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipoMensaje", "error");
        }
        
        return "redirect:/almacenes";
    }
    
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model) {
        Optional<Almacen> almacen = almacenService.obtenerAlmacenPorId(id);
        if (almacen.isPresent()) {
            model.addAttribute("almacen", almacen.get());
            return "almacen-form";
        }
        return "redirect:/almacenes";
    }
    
    @GetMapping("/detalle/{id}")
    public String verDetalle(@PathVariable Long id, Model model) {
        Optional<Almacen> almacen = almacenService.obtenerAlmacenPorId(id);
        if (almacen.isPresent()) {
            model.addAttribute("almacen", almacen.get());
            return "almacen-detalle";
        }
        return "redirect:/almacenes";
    }
    
    @PostMapping("/eliminar/{id}")
    public String eliminarAlmacen(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            almacenService.eliminarAlmacen(id);
            redirectAttributes.addFlashAttribute("mensaje", "Almacén eliminado exitosamente");
            redirectAttributes.addFlashAttribute("tipoMensaje", "success");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al eliminar el almacén: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipoMensaje", "error");
        }
        return "redirect:/almacenes";
    }
}