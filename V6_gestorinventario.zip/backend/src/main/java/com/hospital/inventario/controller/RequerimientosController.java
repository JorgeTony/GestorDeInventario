package com.hospital.inventario.controller;

import com.hospital.inventario.model.Requerimiento;
import com.hospital.inventario.service.RequerimientoService;
import com.hospital.inventario.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import jakarta.validation.Valid;
import java.util.Optional;

@Controller
@RequestMapping("/requerimientos")
public class RequerimientosController {
    
    @Autowired
    private RequerimientoService requerimientoService;
    
    @Autowired
    private ProductoService productoService;
    
    @GetMapping
    public String listarRequerimientos(@RequestParam(required = false) String estado,
                                      @RequestParam(required = false) String prioridad,
                                      @RequestParam(required = false) String area,
                                      Model model) {
        
        if (estado != null && !estado.isEmpty()) {
            Requerimiento.EstadoRequerimiento estadoEnum = Requerimiento.EstadoRequerimiento.valueOf(estado.toUpperCase());
            model.addAttribute("requerimientos", requerimientoService.obtenerRequerimientosPorEstado(estadoEnum));
            model.addAttribute("estadoSeleccionado", estado);
        } else if (prioridad != null && !prioridad.isEmpty()) {
            Requerimiento.PrioridadRequerimiento prioridadEnum = Requerimiento.PrioridadRequerimiento.valueOf(prioridad.toUpperCase());
            model.addAttribute("requerimientos", requerimientoService.obtenerRequerimientosPorPrioridad(prioridadEnum));
            model.addAttribute("prioridadSeleccionada", prioridad);
        } else if (area != null && !area.trim().isEmpty()) {
            model.addAttribute("requerimientos", requerimientoService.obtenerRequerimientosPorArea(area));
            model.addAttribute("areaSeleccionada", area);
        } else {
            model.addAttribute("requerimientos", requerimientoService.obtenerTodosLosRequerimientos());
        }
        
        // Estadísticas
        model.addAttribute("requerimientosPendientes", requerimientoService.obtenerRequerimientosPendientesOrdenados().size());
        model.addAttribute("requerimientosVencidos", requerimientoService.obtenerRequerimientosVencidos().size());
        
        return "requerimientos";
    }
    
    @GetMapping("/nuevo")
    public String mostrarFormularioNuevo(Model model) {
        model.addAttribute("requerimiento", new Requerimiento());
        model.addAttribute("productos", productoService.obtenerTodosLosProductos());
        return "requerimiento-form";
    }
    
    @PostMapping("/guardar")
    public String guardarRequerimiento(@Valid @ModelAttribute Requerimiento requerimiento,
                                      BindingResult result,
                                      RedirectAttributes redirectAttributes,
                                      Model model) {
        if (result.hasErrors()) {
            model.addAttribute("productos", productoService.obtenerTodosLosProductos());
            return "requerimiento-form";
        }
        
        try {
            requerimientoService.guardarRequerimiento(requerimiento);
            redirectAttributes.addFlashAttribute("mensaje", "Requerimiento creado exitosamente");
            redirectAttributes.addFlashAttribute("tipoMensaje", "success");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al crear el requerimiento: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipoMensaje", "error");
        }
        
        return "redirect:/requerimientos";
    }
    
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model) {
        Optional<Requerimiento> requerimiento = requerimientoService.obtenerRequerimientoPorId(id);
        if (requerimiento.isPresent()) {
            model.addAttribute("requerimiento", requerimiento.get());
            model.addAttribute("productos", productoService.obtenerTodosLosProductos());
            return "requerimiento-form";
        }
        return "redirect:/requerimientos";
    }
    
    @GetMapping("/detalle/{id}")
    public String verDetalle(@PathVariable Long id, Model model) {
        Optional<Requerimiento> requerimiento = requerimientoService.obtenerRequerimientoPorId(id);
        if (requerimiento.isPresent()) {
            model.addAttribute("requerimiento", requerimiento.get());
            return "requerimiento-detalle";
        }
        return "redirect:/requerimientos";
    }
}