package com.hospital.inventario.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.Min;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "almacenes")
public class Almacen {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "El nombre del almacén es obligatorio")
    @Size(max = 100, message = "El nombre no puede exceder 100 caracteres")
    @Column(nullable = false)
    private String nombre;
    
    @NotBlank(message = "El código del almacén es obligatorio")
    @Size(max = 20, message = "El código no puede exceder 20 caracteres")
    @Column(unique = true, nullable = false)
    private String codigo;
    
    @Size(max = 300, message = "La ubicación no puede exceder 300 caracteres")
    private String ubicacion;
    
    @Size(max = 200, message = "El responsable no puede exceder 200 caracteres")
    private String responsable;
    
    @Min(value = 0, message = "La capacidad no puede ser negativa")
    private Integer capacidadMaxima;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EstadoAlmacen estado = EstadoAlmacen.ACTIVO;
    
    @OneToMany(mappedBy = "almacen", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Producto> productos = new ArrayList<>();
    
    // Constructores
    public Almacen() {}
    
    public Almacen(String nombre, String codigo, String ubicacion) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.ubicacion = ubicacion;
    }
    
    // Métodos de negocio
    public int getTotalProductos() {
        return productos != null ? productos.size() : 0;
    }
    
    public int getOcupacionActual() {
        return productos != null ? 
            productos.stream().mapToInt(p -> p.getStockActual() != null ? p.getStockActual() : 0).sum() : 0;
    }
    
    public double getPorcentajeOcupacion() {
        if (capacidadMaxima == null || capacidadMaxima == 0) return 0.0;
        return (double) getOcupacionActual() / capacidadMaxima * 100;
    }
    
    public boolean estaLleno() {
        return capacidadMaxima != null && getOcupacionActual() >= capacidadMaxima;
    }
    
    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    
    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }
    
    public String getResponsable() { return responsable; }
    public void setResponsable(String responsable) { this.responsable = responsable; }
    
    public Integer getCapacidadMaxima() { return capacidadMaxima; }
    public void setCapacidadMaxima(Integer capacidadMaxima) { this.capacidadMaxima = capacidadMaxima; }
    
    public EstadoAlmacen getEstado() { return estado; }
    public void setEstado(EstadoAlmacen estado) { this.estado = estado; }
    
    public List<Producto> getProductos() { return productos; }
    public void setProductos(List<Producto> productos) { this.productos = productos; }
    
    public enum EstadoAlmacen {
        ACTIVO, INACTIVO, MANTENIMIENTO
    }
}