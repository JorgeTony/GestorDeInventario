package com.hospital.inventario.service;

import com.hospital.inventario.model.LineaProducto;
import com.hospital.inventario.model.FamiliaProducto;
import com.hospital.inventario.repository.LineaProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class LineaProductoService {
    
    @Autowired
    private LineaProductoRepository lineaProductoRepository;
    
    public List<LineaProducto> obtenerTodasLasLineas() {
        return lineaProductoRepository.findAll();
    }
    
    public Optional<LineaProducto> obtenerLineaPorId(Long id) {
        return lineaProductoRepository.findById(id);
    }
    
    public Optional<LineaProducto> obtenerLineaPorNombre(String nombre) {
        return lineaProductoRepository.findByNombre(nombre);
    }
    
    public LineaProducto guardarLinea(LineaProducto lineaProducto) {
        return lineaProductoRepository.save(lineaProducto);
    }
    
    public void eliminarLinea(Long id) {
        lineaProductoRepository.deleteById(id);
    }
    
    public List<LineaProducto> obtenerLineasPorFamilia(FamiliaProducto familiaProducto) {
        return lineaProductoRepository.findByFamiliaProducto(familiaProducto);
    }
    
    public List<LineaProducto> buscarLineasPorNombre(String nombre) {
        return lineaProductoRepository.findByNombreContainingIgnoreCase(nombre);
    }
    
    public List<LineaProducto> obtenerLineasOrdenadasPorProductos() {
        return lineaProductoRepository.findLineasOrdenadasPorCantidadProductos();
    }
    
    public List<LineaProducto> obtenerLineasConProductos() {
        return lineaProductoRepository.findLineasConProductos();
    }
    
    public boolean existeNombreLinea(String nombre) {
        return lineaProductoRepository.findByNombre(nombre).isPresent();
    }
}