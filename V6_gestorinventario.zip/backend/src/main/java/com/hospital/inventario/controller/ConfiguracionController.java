package com.hospital.inventario.controller;

import com.hospital.inventario.service.CategoriaService;
import com.hospital.inventario.service.AlmacenService;
import com.hospital.inventario.service.FamiliaProductoService;
import com.hospital.inventario.service.LineaProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/configuracion")
public class ConfiguracionController {
    
    @Autowired
    private CategoriaService categoriaService;
    
    @Autowired
    private AlmacenService almacenService;
    
    @Autowired
    private FamiliaProductoService familiaProductoService;
    
    @Autowired
    private LineaProductoService lineaProductoService;
    
    @GetMapping
    public String configuracion(@RequestParam(required = false) String seccion, Model model) {
        
        // Sección activa
        String seccionActiva = seccion != null ? seccion : "general";
        model.addAttribute("seccionActiva", seccionActiva);
        
        // Datos según sección
        switch (seccionActiva) {
            case "categorias":
                model.addAttribute("categorias", categoriaService.obtenerTodasLasCategorias());
                break;
            case "almacenes":
                model.addAttribute("almacenes", almacenService.obtenerTodosLosAlmacenes());
                break;
            case "familias":
                model.addAttribute("familias", familiaProductoService.obtenerTodasLasFamilias());
                break;
            case "lineas":
                model.addAttribute("lineas", lineaProductoService.obtenerTodasLasLineas());
                model.addAttribute("familias", familiaProductoService.obtenerTodasLasFamilias());
                break;
            default:
                // Configuración general
                model.addAttribute("totalCategorias", categoriaService.obtenerTodasLasCategorias().size());
                model.addAttribute("totalAlmacenes", almacenService.obtenerTodosLosAlmacenes().size());
                model.addAttribute("totalFamilias", familiaProductoService.obtenerTodasLasFamilias().size());
                model.addAttribute("totalLineas", lineaProductoService.obtenerTodasLasLineas().size());
                break;
        }
        
        return "configuracion";
    }
}