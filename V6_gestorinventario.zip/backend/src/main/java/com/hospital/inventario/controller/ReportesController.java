package com.hospital.inventario.controller;

import com.hospital.inventario.service.ProductoService;
import com.hospital.inventario.service.TransaccionService;
import com.hospital.inventario.service.RequerimientoService;
import com.hospital.inventario.service.OrdenCompraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Controller
@RequestMapping("/reportes")
public class ReportesController {
    
    @Autowired
    private ProductoService productoService;
    
    @Autowired
    private TransaccionService transaccionService;
    
    @Autowired
    private RequerimientoService requerimientoService;
    
    @Autowired
    private OrdenCompraService ordenCompraService;
    
    @GetMapping
    public String reportes(@RequestParam(required = false) String tipo,
                          @RequestParam(required = false) String fechaInicio,
                          @RequestParam(required = false) String fechaFin,
                          Model model) {
        
        // Fechas por defecto (último mes)
        LocalDate inicio = fechaInicio != null ? LocalDate.parse(fechaInicio) : LocalDate.now().minusMonths(1);
        LocalDate fin = fechaFin != null ? LocalDate.parse(fechaFin) : LocalDate.now();
        
        model.addAttribute("fechaInicio", inicio);
        model.addAttribute("fechaFin", fin);
        
        // Reportes según tipo
        if ("inventario".equals(tipo)) {
            model.addAttribute("productos", productoService.obtenerTodosLosProductos());
            model.addAttribute("valorTotal", productoService.calcularValorTotalInventario());
            model.addAttribute("tipoReporte", "Inventario General");
        } else if ("movimientos".equals(tipo)) {
            LocalDateTime inicioDateTime = inicio.atStartOfDay();
            LocalDateTime finDateTime = fin.atTime(23, 59, 59);
            model.addAttribute("transacciones", transaccionService.obtenerTransaccionesPorPeriodo(inicioDateTime, finDateTime));
            model.addAttribute("tipoReporte", "Movimientos de Inventario");
        } else if ("requerimientos".equals(tipo)) {
            model.addAttribute("requerimientos", requerimientoService.obtenerRequerimientosPorPeriodo(inicio, fin));
            model.addAttribute("tipoReporte", "Requerimientos por Área");
        } else if ("ordenes-compra".equals(tipo)) {
            model.addAttribute("ordenes", ordenCompraService.obtenerOrdenesPorPeriodo(inicio, fin));
            model.addAttribute("montoTotal", ordenCompraService.calcularMontoTotalPorPeriodo(inicio, fin));
            model.addAttribute("tipoReporte", "Órdenes de Compra");
        } else {
            // Dashboard de reportes
            model.addAttribute("totalProductos", productoService.contarProductosActivos());
            model.addAttribute("valorInventario", productoService.calcularValorTotalInventario());
            model.addAttribute("productosStockBajo", productoService.obtenerProductosConStockBajo().size());
            model.addAttribute("requerimientosPendientes", requerimientoService.obtenerRequerimientosPendientesOrdenados().size());
            model.addAttribute("tipoReporte", "Dashboard");
        }
        
        return "reportes";
    }
}