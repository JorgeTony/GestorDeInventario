
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Kardex() {
  const navigate = useNavigate();
  const [selectedProducto, setSelectedProducto] = useState('');
  const [selectedAlmacen, setSelectedAlmacen] = useState('');
  const [fechaInicio, setFechaInicio] = useState('2024-01-01');
  const [fechaFin, setFechaFin] = useState('2024-01-15');
  const [showDetails, setShowDetails] = useState(false);

  const productos = [
    'Mascarillas N95',
    'Guantes de Látex',
    'Jeringas Desechables',
    'Alcohol en Gel',
    'Termómetros Digitales'
  ];

  const almacenes = [
    'Almacén Central',
    'Almacén de Medicamentos',
    'Almacén de Equipos',
    'Almacén de Emergencia'
  ];

  const kardexData = [
    {
      fecha: '2024-01-15',
      hora: '14:30',
      documento: 'OC-2024-001',
      concepto: 'Compra a proveedor',
      entrada: 500,
      salida: 0,
      saldo: 1200,
      costoUnitario: 2.50,
      costoTotal: 1250.00,
      responsable: 'Carlos Mendoza'
    },
    {
      fecha: '2024-01-14',
      hora: '16:45',
      documento: 'REQ-2024-015',
      concepto: 'Entrega a emergencias',
      entrada: 0,
      salida: 200,
      saldo: 700,
      costoUnitario: 2.50,
      costoTotal: -500.00,
      responsable: 'Ana García'
    },
    {
      fecha: '2024-01-14',
      hora: '12:15',
      documento: 'TRF-2024-003',
      concepto: 'Transferencia interna',
      entrada: 0,
      salida: 100,
      saldo: 900,
      costoUnitario: 2.50,
      costoTotal: -250.00,
      responsable: 'Miguel Torres'
    },
    {
      fecha: '2024-01-13',
      hora: '09:30',
      documento: 'AJU-2024-001',
      concepto: 'Ajuste por inventario',
      entrada: 0,
      salida: 50,
      saldo: 1000,
      costoUnitario: 2.50,
      costoTotal: -125.00,
      responsable: 'Laura Vásquez'
    },
    {
      fecha: '2024-01-12',
      hora: '11:00',
      documento: 'OC-2024-002',
      concepto: 'Compra de emergencia',
      entrada: 300,
      salida: 0,
      saldo: 1050,
      costoUnitario: 2.50,
      costoTotal: 750.00,
      responsable: 'Carlos Mendoza'
    }
  ];

  const resumenKardex = {
    saldoInicial: 750,
    totalEntradas: 800,
    totalSalidas: 350,
    saldoFinal: 1200,
    valorInventario: 3000.00,
    movimientos: kardexData.length
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Navigation */}
      <header className="bg-slate-700 shadow-sm">
        <div className="px-4 lg:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <i className="ri-archive-line text-white text-lg"></i>
                </div>
                <button 
                  onClick={() => navigate('/')}
                  className="text-lg lg:text-xl font-bold text-white hover:text-blue-200 transition-colors"
                >
                  Sistema de Inventarios
                </button>
              </div>
              <div className="text-white">
                <i className="ri-arrow-right-s-line mx-2"></i>
                <span className="text-blue-200">Kardex</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 lg:px-6 py-6 lg:py-8">
        {/* Page Header */}
        <div className="mb-6">
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">Kardex de Productos</h1>
          <p className="text-gray-600">Historial detallado de movimientos por producto</p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Filtros de Consulta</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Producto
              </label>
              <select
                value={selectedProducto}
                onChange={(e) => setSelectedProducto(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8"
              >
                <option value="">Seleccionar producto</option>
                {productos.map((producto, index) => (
                  <option key={index} value={producto}>{producto}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Almacén
              </label>
              <select
                value={selectedAlmacen}
                onChange={(e) => setSelectedAlmacen(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8"
              >
                <option value="">Todos los almacenes</option>
                {almacenes.map((almacen, index) => (
                  <option key={index} value={almacen}>{almacen}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fecha Inicio
              </label>
              <input
                type="date"
                value={fechaInicio}
                onChange={(e) => setFechaInicio(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fecha Fin
              </label>
              <input
                type="date"
                value={fechaFin}
                onChange={(e) => setFechaFin(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div className="flex items-end">
              <button 
                onClick={() => setShowDetails(true)}
                className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center justify-center space-x-2 whitespace-nowrap"
              >
                <i className="ri-search-line"></i>
                <span>Consultar</span>
              </button>
            </div>
          </div>
        </div>

        {/* Resumen */}
        {showDetails && (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4 lg:gap-6 mb-6">
              <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-600 mb-1">Saldo Inicial</p>
                  <p className="text-xl font-bold text-gray-900">{resumenKardex.saldoInicial.toLocaleString()}</p>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-600 mb-1">Total Entradas</p>
                  <p className="text-xl font-bold text-green-600">+{resumenKardex.totalEntradas.toLocaleString()}</p>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-600 mb-1">Total Salidas</p>
                  <p className="text-xl font-bold text-red-600">-{resumenKardex.totalSalidas.toLocaleString()}</p>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-600 mb-1">Saldo Final</p>
                  <p className="text-xl font-bold text-gray-900">{resumenKardex.saldoFinal.toLocaleString()}</p>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-600 mb-1">Valor Inventario</p>
                  <p className="text-xl font-bold text-blue-600">${resumenKardex.valorInventario.toLocaleString()}</p>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-600 mb-1">Movimientos</p>
                  <p className="text-xl font-bold text-gray-900">{resumenKardex.movimientos}</p>
                </div>
              </div>
            </div>

            {/* Kardex Table */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-4 lg:p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Kardex - Mascarillas N95</h3>
                    <p className="text-sm text-gray-600">Almacén Central | Período: {fechaInicio} al {fechaFin}</p>
                  </div>
                  <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center space-x-2 whitespace-nowrap">
                    <i className="ri-download-line"></i>
                    <span>Exportar</span>
                  </button>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Fecha/Hora
                      </th>
                      <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Documento
                      </th>
                      <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Concepto
                      </th>
                      <th className="px-4 lg:px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Entrada
                      </th>
                      <th className="px-4 lg:px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Salida
                      </th>
                      <th className="px-4 lg:px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Saldo
                      </th>
                      <th className="px-4 lg:px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Costo Unit.
                      </th>
                      <th className="px-4 lg:px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Costo Total
                      </th>
                      <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Responsable
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {kardexData.map((item, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-4 lg:px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{item.fecha}</div>
                          <div className="text-xs text-gray-500">{item.hora}</div>
                        </td>
                        <td className="px-4 lg:px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-blue-600">{item.documento}</div>
                        </td>
                        <td className="px-4 lg:px-6 py-4">
                          <div className="text-sm text-gray-900">{item.concepto}</div>
                        </td>
                        <td className="px-4 lg:px-6 py-4 whitespace-nowrap text-center">
                          <div className={`text-sm font-medium ${item.entrada > 0 ? 'text-green-600' : 'text-gray-400'}`}>
                            {item.entrada > 0 ? item.entrada.toLocaleString() : '-'}
                          </div>
                        </td>
                        <td className="px-4 lg:px-6 py-4 whitespace-nowrap text-center">
                          <div className={`text-sm font-medium ${item.salida > 0 ? 'text-red-600' : 'text-gray-400'}`}>
                            {item.salida > 0 ? item.salida.toLocaleString() : '-'}
                          </div>
                        </td>
                        <td className="px-4 lg:px-6 py-4 whitespace-nowrap text-center">
                          <div className="text-sm font-bold text-gray-900">{item.saldo.toLocaleString()}</div>
                        </td>
                        <td className="px-4 lg:px-6 py-4 whitespace-nowrap text-right">
                          <div className="text-sm text-gray-900">${item.costoUnitario.toFixed(2)}</div>
                        </td>
                        <td className="px-4 lg:px-6 py-4 whitespace-nowrap text-right">
                          <div className={`text-sm font-medium ${item.costoTotal > 0 ? 'text-green-600' : 'text-red-600'}`}>
                            ${Math.abs(item.costoTotal).toFixed(2)}
                          </div>
                        </td>
                        <td className="px-4 lg:px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{item.responsable}</div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        {/* Empty State */}
        {!showDetails && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 lg:p-12 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-bar-chart-box-line text-gray-400 text-2xl"></i>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Selecciona los filtros para consultar</h3>
            <p className="text-gray-600 mb-6">Elige un producto y configura las fechas para ver el kardex detallado</p>
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-3 sm:space-y-0 sm:space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <i className="ri-information-line"></i>
                <span>El kardex muestra el historial completo de movimientos</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
