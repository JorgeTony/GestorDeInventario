
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Reportes() {
  const navigate = useNavigate();
  const [selectedTab, setSelectedTab] = useState('ventas');
  const [dateRange, setDateRange] = useState('6m');
  const [currency, setCurrency] = useState('USD');
  const [exchangeRate] = useState(3.75); // Tasa de cambio USD a PEN
  const [showNotifications, setShowNotifications] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [user] = useState({
    name: 'María González',
    role: 'Administrador de Inventario',
    avatar: 'https://readdy.ai/api/search-image?query=professional%20woman%20administrator%20inventory%20management%20office%20corporate%20headshot%20clean%20background%20business%20attire%20confident%20smile%20latina&width=40&height=40&seq=1&orientation=squarish'
  });

  const notifications = [
    {
      id: 1,
      title: 'Stock Bajo',
      message: 'Mascarillas N95 requieren reposición urgente',
      time: 'Hace 5 min',
      type: 'warning',
      unread: true
    },
    {
      id: 2,
      title: 'Producto Vencido',
      message: 'Vacuna COVID-19 próxima a vencer',
      time: 'Hace 15 min',
      type: 'error',
      unread: true
    },
    {
      id: 3,
      title: 'Orden Completada',
      message: 'Orden de compra OC-2024-001 recibida',
      time: 'Hace 1 hora',
      type: 'success',
      unread: false
    }
  ];

  // Función para convertir moneda
  const convertCurrency = (amount: number) => {
    if (currency === 'PEN') {
      return amount * exchangeRate;
    }
    return amount;
  };

  // Función para formatear moneda
  const formatCurrency = (amount: number) => {
    const convertedAmount = convertCurrency(amount);
    if (currency === 'PEN') {
      return `S/ ${convertedAmount.toLocaleString('es-PE', { minimumFractionDigits: 2 })}`;
    }
    return `$${convertedAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
  };

  // Función para exportar PDF
  const handleExportPDF = async () => {
    setIsExporting(true);
    
    try {
      // Simular proceso de exportación
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Crear contenido del PDF (simulado)
      const reportData = {
        title: `Reporte de ${tabs.find(t => t.id === selectedTab)?.label}`,
        dateRange: dateRange,
        currency: currency,
        generatedAt: new Date().toLocaleString('es-PE'),
        data: getTabData()
      };

      // En una implementación real, aquí se generaría el PDF
      console.log('Generando PDF con datos:', reportData);
      
      // Simular descarga
      const blob = new Blob(['Contenido del reporte PDF simulado'], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `reporte_${selectedTab}_${new Date().toISOString().split('T')[0]}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      alert('¡Reporte exportado exitosamente!');
    } catch (error) {
      alert('Error al exportar el reporte. Inténtalo nuevamente.');
    } finally {
      setIsExporting(false);
    }
  };

  const tabs = [
    { id: 'ventas', label: 'Reporte de Ventas', icon: 'ri-line-chart-line' },
    { id: 'inventario', label: 'Estado de Inventario', icon: 'ri-archive-line' },
    { id: 'movimientos', label: 'Movimientos de Stock', icon: 'ri-exchange-line' },
    { id: 'financiero', label: 'Reporte Financiero', icon: 'ri-money-dollar-circle-line' }
  ];

  // Datos simulados para los gráficos
  const salesData = [
    { month: 'Ene', value: 4000 },
    { month: 'Feb', value: 3500 },
    { month: 'Mar', value: 2800 },
    { month: 'Abr', value: 2200 },
    { month: 'May', value: 2500 },
    { month: 'Jun', value: 2800 }
  ];

  const categoryData = [
    { name: 'Medicamentos', value: 65, color: 'bg-blue-500' },
    { name: 'Material Médico', value: 20, color: 'bg-green-500' },
    { name: 'EPP', value: 10, color: 'bg-orange-500' },
    { name: 'Equipos', value: 5, color: 'bg-purple-500' }
  ];

  // Datos específicos para cada pestaña (actualizados con conversión de moneda)
  const getTabData = () => {
    switch (selectedTab) {
      case 'inventario':
        return {
          metrics: [
            { title: 'Total de Productos', value: '3,245', subtitle: 'En inventario', change: '+5.2%', icon: 'ri-archive-line', color: 'bg-blue-500' },
            { title: 'Valor Total', value: formatCurrency(348750), subtitle: 'Costo del inventario', change: '+12.8%', icon: 'ri-money-dollar-circle-line', color: 'bg-green-500' },
            { title: 'Stock Bajo', value: '23', subtitle: 'Requieren reposición', change: '-8.1%', icon: 'ri-alert-line', color: 'bg-red-500' },
            { title: 'Próximos a Vencer', value: '18', subtitle: 'En 30 días', change: '+3.4%', icon: 'ri-time-line', color: 'bg-orange-500' }
          ],
          chartTitle: 'Distribución de Stock por Categoría',
          tableTitle: 'Estado Actual del Inventario'
        };
      case 'movimientos':
        return {
          metrics: [
            { title: 'Entradas', value: '156', subtitle: 'Este mes', change: '+18.5%', icon: 'ri-arrow-down-line', color: 'bg-green-500' },
            { title: 'Salidas', value: '89', subtitle: 'Este mes', change: '-5.2%', icon: 'ri-arrow-up-line', color: 'bg-red-500' },
            { title: 'Transferencias', value: '34', subtitle: 'Entre almacenes', change: '+12.1%', icon: 'ri-exchange-line', color: 'bg-purple-500' },
            { title: 'Ajustes', value: '7', subtitle: 'Correcciones', change: '-15.3%', icon: 'ri-settings-line', color: 'bg-orange-500' }
          ],
          chartTitle: 'Movimientos de Stock por Mes',
          tableTitle: 'Últimos Movimientos'
        };
      case 'financiero':
        return {
          metrics: [
            { title: 'Costo Total', value: formatCurrency(248500), subtitle: 'Valor del inventario', change: '+8.7%', icon: 'ri-money-dollar-circle-line', color: 'bg-green-500' },
            { title: 'Costo Promedio', value: formatCurrency(76.52), subtitle: 'Por producto', change: '+3.2%', icon: 'ri-calculator-line', color: 'bg-blue-500' },
            { title: 'Rotación', value: '4.2x', subtitle: 'Veces por año', change: '+15.8%', icon: 'ri-refresh-line', color: 'bg-purple-500' },
            { title: 'Días de Stock', value: '87', subtitle: 'Días promedio', change: '-12.5%', icon: 'ri-calendar-line', color: 'bg-orange-500' }
          ],
          chartTitle: 'Análisis Financiero por Categoría',
          tableTitle: 'Métricas Financieras'
        };
      default:
        return {
          metrics: [
            { title: 'Ventas Totales', value: formatCurrency(67241), subtitle: '+12.5% vs mes anterior', change: '+12.5%', icon: 'ri-money-dollar-circle-line', color: 'bg-blue-500' },
            { title: 'Productos Vendidos', value: '1,234', subtitle: '+8.2% vs mes anterior', change: '+8.2%', icon: 'ri-shopping-cart-line', color: 'bg-green-500' },
            { title: 'Ticket Promedio', value: formatCurrency(54.48), subtitle: '+3.1% vs mes anterior', change: '+3.1%', icon: 'ri-receipt-line', color: 'bg-purple-500' },
            { title: 'Margen Bruto', value: '32.5%', subtitle: '+1.8% vs mes anterior', change: '+1.8%', icon: 'ri-percent-line', color: 'bg-orange-500' }
          ],
          chartTitle: 'Tendencia de Ventas',
          tableTitle: 'Productos Más Vendidos'
        };
    }
  };

  const renderTabContent = () => {
    switch (selectedTab) {
      case 'inventario':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-8">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-4 lg:p-6 border-b border-gray-100">
                <h3 className="text-base lg:text-lg font-semibold text-gray-900">Productos por Categoría</h3>
                <p className="text-sm text-gray-600">Estado actual del inventario</p>
              </div>
              <div className="p-4 lg:p-6">
                <div className="space-y-4">
                  {[
                    { category: 'Medicamentos', stock: 1245, value: 156800, status: 'normal' },
                    { category: 'Material Médico', stock: 856, value: 89200, status: 'normal' },
                    { category: 'EPP', stock: 432, value: 52300, status: 'bajo' },
                    { category: 'Equipos', stock: 178, value: 34750, status: 'normal' }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-3 lg:p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h4 className="font-medium text-gray-900 text-sm lg:text-base">{item.category}</h4>
                        <p className="text-xs lg:text-sm text-gray-600">{item.stock} productos</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-gray-900 text-sm lg:text-base">{formatCurrency(item.value)}</p>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          item.status === 'normal' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {item.status === 'normal' ? 'Normal' : 'Bajo Stock'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-4 lg:p-6 border-b border-gray-100">
                <h3 className="text-base lg:text-lg font-semibold text-gray-900">Alertas de Inventario</h3>
                <p className="text-sm text-gray-600">Productos que requieren atención</p>
              </div>
              <div className="p-4 lg:p-6">
                <div className="space-y-4">
                  {[
                    { name: 'Mascarillas N95', type: 'Stock Bajo', level: 'crítico', action: 'Reabastecer' },
                    { name: 'Vacuna COVID-19', type: 'Próximo a Vencer', level: 'advertencia', action: 'Usar Pronto' },
                    { name: 'Termómetros Digitales', type: 'Stock Bajo', level: 'crítico', action: 'Ordenar' },
                    { name: 'Suero Fisiológico', type: 'Próximo a Vencer', level: 'normal', action: 'Monitorear' }
                  ].map((alert, index) => (
                    <div key={index} className="flex items-center justify-between p-3 lg:p-4 bg-gray-50 rounded-lg">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-gray-900 text-sm lg:text-base truncate">{alert.name}</h4>
                        <p className="text-xs lg:text-sm text-gray-600">{alert.type}</p>
                      </div>
                      <div className="flex items-center space-x-2 ml-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium whitespace-nowrap ${
                          alert.level === 'crítico' ? 'bg-red-100 text-red-700' :
                          alert.level === 'advertencia' ? 'bg-yellow-100 text-yellow-700' :
                          'bg-green-100 text-green-700'
                        }`}>
                          {alert.action}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );

      case 'movimientos':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-8">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-4 lg:p-6 border-b border-gray-100">
                <h3 className="text-base lg:text-lg font-semibold text-gray-900">Últimos Movimientos</h3>
                <p className="text-sm text-gray-600">Transacciones recientes de inventario</p>
              </div>
              <div className="p-4 lg:p-6">
                <div className="space-y-4">
                  {[
                    { product: 'Acetaminofén 500mg', type: 'Entrada', quantity: '+150', date: '2024-01-15', user: 'María González' },
                    { product: 'Jeringa 10ml', type: 'Salida', quantity: '-85', date: '2024-01-14', user: 'Carlos Ruiz' },
                    { product: 'Alcohol Etílico 70%', type: 'Transferencia', quantity: '50', date: '2024-01-14', user: 'Ana López' },
                    { product: 'Guantes Latex M', type: 'Ajuste', quantity: '+5', date: '2024-01-13', user: 'Sistema' }
                  ].map((movement, index) => (
                    <div key={index} className="flex items-center justify-between p-3 lg:p-4 bg-gray-50 rounded-lg">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-gray-900 text-sm lg:text-base truncate">{movement.product}</h4>
                        <p className="text-xs lg:text-sm text-gray-600">{movement.date} - {movement.user}</p>
                      </div>
                      <div className="text-right ml-2">
                        <span className={`px-2 lg:px-3 py-1 rounded-full text-xs lg:text-sm font-medium whitespace-nowrap ${
                          movement.type === 'Entrada' ? 'bg-green-100 text-green-700' :
                          movement.type === 'Salida' ? 'bg-red-100 text-red-700' :
                          movement.type === 'Transferencia' ? 'bg-blue-100 text-blue-700' :
                          'bg-gray-100 text-gray-700'
                        }`}>
                          {movement.type}
                        </span>
                        <p className="text-xs lg:text-sm font-semibold text-gray-900 mt-1">{movement.quantity}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-4 lg:p-6 border-b border-gray-100">
                <h3 className="text-base lg:text-lg font-semibold text-gray-900">Resumen de Movimientos</h3>
                <p className="text-sm text-gray-600">Estadísticas del período seleccionado</p>
              </div>
              <div className="p-4 lg:p-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 lg:p-4 bg-green-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 lg:w-10 lg:h-10 bg-green-500 rounded-lg flex items-center justify-center">
                        <i className="ri-arrow-down-line text-white text-sm lg:text-base"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900 text-sm lg:text-base">Entradas</h4>
                        <p className="text-xs lg:text-sm text-gray-600">156 movimientos</p>
                      </div>
                    </div>
                    <span className="text-sm lg:text-lg font-bold text-green-600">2,450 unidades</span>
                  </div>

                  <div className="flex items-center justify-between p-3 lg:p-4 bg-red-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 lg:w-10 lg:h-10 bg-red-500 rounded-lg flex items-center justify-center">
                        <i className="ri-arrow-up-line text-white text-sm lg:text-base"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900 text-sm lg:text-base">Salidas</h4>
                        <p className="text-xs lg:text-sm text-gray-600">89 movimientos</p>
                      </div>
                    </div>
                    <span className="text-sm lg:text-lg font-bold text-red-600">1,678 unidades</span>
                  </div>

                  <div className="flex items-center justify-between p-3 lg:p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 lg:w-10 lg:h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                        <i className="ri-exchange-line text-white text-sm lg:text-base"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900 text-sm lg:text-base">Transferencias</h4>
                        <p className="text-xs lg:text-sm text-gray-600">34 movimientos</p>
                      </div>
                    </div>
                    <span className="text-sm lg:text-lg font-bold text-blue-600">567 unidades</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'financiero':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-8">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-4 lg:p-6 border-b border-gray-100">
                <h3 className="text-base lg:text-lg font-semibold text-gray-900">Análisis de Costos</h3>
                <p className="text-sm text-gray-600">Distribución financiera por categoría</p>
              </div>
              <div className="p-4 lg:p-6">
                <div className="space-y-4">
                  {[
                    { category: 'Medicamentos', cost: 156800, percentage: '45%', trend: '+8.2%' },
                    { category: 'Material Médico', cost: 89200, percentage: '26%', trend: '+5.1%' },
                    { category: 'EPP', cost: 52300, percentage: '15%', trend: '+12.5%' },
                    { category: 'Equipos', cost: 34750, percentage: '10%', trend: '+3.8%' },
                    { category: 'Otros', cost: 15700, percentage: '4%', trend: '-2.1%' }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-3 lg:p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3 flex-1 min-w-0">
                        <div className={`w-3 h-3 lg:w-4 lg:h-4 rounded ${
                          index === 0 ? 'bg-blue-500' :
                          index === 1 ? 'bg-green-500' :
                          index === 2 ? 'bg-yellow-500' :
                          index === 3 ? 'bg-purple-500' : 'bg-red-500'
                        }`}></div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-gray-900 text-sm lg:text-base truncate">{item.category}</h4>
                          <p className="text-xs lg:text-sm text-gray-600">{item.percentage} del total</p>
                        </div>
                      </div>
                      <div className="text-right ml-2">
                        <p className="font-semibold text-gray-900 text-sm lg:text-base">{formatCurrency(item.cost)}</p>
                        <span className={`text-xs lg:text-sm ${
                          item.trend.startsWith('+') ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {item.trend}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-4 lg:p-6 border-b border-gray-100">
                <h3 className="text-base lg:text-lg font-semibold text-gray-900">Métricas de Rentabilidad</h3>
                <p className="text-sm text-gray-600">Indicadores financieros clave</p>
              </div>
              <div className="p-4 lg:p-6">
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">4.2x</div>
                    <div className="text-sm text-gray-600 mb-1">Rotación de Inventario</div>
                    <div className="text-sm text-green-600">+15.8% vs período anterior</div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 lg:p-4 bg-blue-50 rounded-lg">
                      <div className="text-lg lg:text-xl font-bold text-blue-600">87</div>
                      <div className="text-xs lg:text-sm text-gray-600">Días de Stock</div>
                    </div>
                    <div className="text-center p-3 lg:p-4 bg-green-50 rounded-lg">
                      <div className="text-lg lg:text-xl font-bold text-green-600">{formatCurrency(76.52)}</div>
                      <div className="text-xs lg:text-sm text-gray-600">Costo Promedio</div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Margen Bruto</span>
                      <span className="text-sm font-semibold text-gray-900">32.5%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">ROI Inventario</span>
                      <span className="text-sm font-semibold text-gray-900">18.7%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Productos Activos</span>
                      <span className="text-sm font-semibold text-gray-900">2,847</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-8">
            <LineChart data={salesData} title={getTabData().chartTitle} />
            <PieChart data={categoryData} title="Ventas por Categoría" />
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Navigation */}
      <header className="bg-slate-700 shadow-sm">
        <div className="px-4 lg:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 lg:space-x-6">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <i className="ri-archive-line text-white text-lg"></i>
                </div>
                <button 
                  onClick={() => navigate('/')}
                  className="text-lg lg:text-xl font-bold text-white hover:text-blue-200 transition-colors cursor-pointer"
                >
                  Sistema de Inventarios
                </button>
              </div>
              
              {/* Desktop Navigation Menu */}
              <nav className="hidden lg:flex items-center space-x-8">
                <button 
                  onClick={() => navigate('/dashboard')}
                  className="text-blue-200 hover:text-white font-medium transition-colors whitespace-nowrap"
                >
                  Dashboard
                </button>
                <button 
                  onClick={() => navigate('/productos')}
                  className="text-blue-200 hover:text-white font-medium transition-colors whitespace-nowrap"
                >
                  Productos
                </button>
                <button 
                  onClick={() => navigate('/inventario')}
                  className="text-blue-200 hover:text-white font-medium transition-colors whitespace-nowrap"
                >
                  Inventario
                </button>
                <button className="text-white bg-blue-600 px-3 py-1 rounded-md font-medium whitespace-nowrap">
                  Reportes
                </button>
                <button 
                  onClick={() => navigate('/configuracion')}
                  className="text-blue-200 hover:text-white font-medium transition-colors whitespace-nowrap"
                >
                  Configuración
                </button>
              </nav>
            </div>
            
            <div className="flex items-center space-x-2 lg:space-x-4">
              {/* Mobile menu button */}
              <button 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 text-white hover:text-blue-200"
              >
                <i className={`${mobileMenuOpen ? 'ri-close-line' : 'ri-menu-line'} text-xl`}></i>
              </button>

              {/* Notifications */}
              <div className="relative">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="p-2 text-white hover:text-blue-200 relative"
                >
                  <i className="ri-notification-3-line text-xl"></i>
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center">
                    {notifications.filter(n => n.unread).length}
                  </span>
                </button>

                {/* Notifications Dropdown */}
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl border border-gray-200 z-50">
                    <div className="p-4 border-b border-gray-100">
                      <h3 className="font-semibold text-gray-900">Notificaciones</h3>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.map((notification) => (
                        <div key={notification.id} className={`p-4 border-b border-gray-100 hover:bg-gray-50 ${notification.unread ? 'bg-blue-50' : ''}`}>
                          <div className="flex items-start space-x-3">
                            <div className={`w-2 h-2 rounded-full mt-2 ${
                              notification.type === 'error' ? 'bg-red-500' :
                              notification.type === 'warning' ? 'bg-yellow-500' :
                              'bg-green-500'
                            }`}></div>
                            <div className="flex-1">
                              <h4 className="font-medium text-gray-900 text-sm">{notification.title}</h4>
                              <p className="text-sm text-gray-600 mt-1">{notification.message}</p>
                              <p className="text-xs text-gray-500 mt-2">{notification.time}</p>
                            </div>
                            {notification.unread && (
                              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="p-4 border-t border-gray-100">
                      <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
                        Ver todas las notificaciones
                      </button>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="hidden lg:flex items-center space-x-3">
                <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                <div className="text-sm">
                  <p className="font-medium text-white">{user.name}</p>
                  <p className="text-blue-200">{user.role}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile Navigation Menu */}
          {mobileMenuOpen && (
            <div className="lg:hidden mt-4 pb-4 border-t border-slate-600">
              <nav className="flex flex-col space-y-2 mt-4">
                <button 
                  onClick={() => {
                    navigate('/dashboard');
                    setMobileMenuOpen(false);
                  }}
                  className="text-blue-200 hover:text-white font-medium transition-colors text-left py-2"
                >
                  Dashboard
                </button>
                <button 
                  onClick={() => {
                    navigate('/productos');
                    setMobileMenuOpen(false);
                  }}
                  className="text-blue-200 hover:text-white font-medium transition-colors text-left py-2"
                >
                  Productos
                </button>
                <button 
                  onClick={() => {
                    navigate('/inventario');
                    setMobileMenuOpen(false);
                  }}
                  className="text-blue-200 hover:text-white font-medium transition-colors text-left py-2"
                >
                  Inventario
                </button>
                <button className="text-white bg-blue-600 px-3 py-2 rounded-md font-medium text-left">
                  Reportes
                </button>
                <button 
                  onClick={() => {
                    navigate('/configuracion');
                    setMobileMenuOpen(false);
                  }}
                  className="text-blue-200 hover:text-white font-medium transition-colors text-left py-2"
                >
                  Configuración
                </button>
              </nav>
              
              {/* Mobile User Info */}
              <div className="flex items-center space-x-3 mt-4 pt-4 border-t border-slate-600">
                <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                <div className="text-sm">
                  <p className="font-medium text-white">{user.name}</p>
                  <p className="text-blue-200">{user.role}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </header>

      <div className="px-4 lg:px-6 py-6 lg:py-8">
        {/* Page Header */}
        <div className="mb-6 lg:mb-8">
          <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">Reportes y Análisis</h2>
          <p className="text-gray-600">Visualiza el rendimiento de tu inventario con reportes detallados</p>
        </div>

        {/* Tabs */}
        <div className="mb-6 lg:mb-8">
          <div className="flex items-center space-x-1 bg-gray-100 p-1 rounded-lg overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id)}
                className={`flex items-center space-x-2 px-3 lg:px-4 py-2 rounded-md font-medium transition-colors whitespace-nowrap text-sm lg:text-base ${
                  selectedTab === tab.id
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <i className={`${tab.icon} text-lg`}></i>
                <span className="hidden sm:inline">{tab.label}</span>
                <span className="sm:hidden">{tab.label.split(' ')[0]}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Controls */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-6 lg:mb-8 space-y-4 lg:space-y-0">
          <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-4">
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium text-gray-700 whitespace-nowrap">Período:</label>
              <select 
                value={dateRange} 
                onChange={(e) => setDateRange(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8 text-sm"
              >
                <option value="7d">Últimos 7 días</option>
                <option value="30d">Últimos 30 días</option>
                <option value="6m">Últimos 6 meses</option>
                <option value="1y">Último año</option>
              </select>
            </div>
            
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium text-gray-700 whitespace-nowrap">Moneda:</label>
              <select 
                value={currency} 
                onChange={(e) => setCurrency(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8 text-sm"
              >
                <option value="USD">USD - Dólares</option>
                <option value="PEN">PEN - Soles Peruanos</option>
              </select>
            </div>
            
            {currency === 'PEN' && (
              <div className="text-sm text-gray-600 bg-blue-50 px-3 py-2 rounded-lg">
                <i className="ri-information-line mr-1"></i>
                Tasa: 1 USD = S/ {exchangeRate}
              </div>
            )}
          </div>
          
          <button 
            onClick={handleExportPDF}
            disabled={isExporting}
            className={`px-4 py-2 rounded-lg flex items-center space-x-2 whitespace-nowrap text-sm lg:text-base ${
              isExporting 
                ? 'bg-gray-400 text-white cursor-not-allowed' 
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            {isExporting ? (
              <>
                <i className="ri-loader-4-line animate-spin"></i>
                <span>Exportando...</span>
              </>
            ) : (
              <>
                <i className="ri-download-line"></i>
                <span>Exportar PDF</span>
              </>
            )}
          </button>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-6 lg:mb-8">
          {getTabData().metrics.map((metric, index) => (
            <MetricCard key={index} {...metric} />
          ))}
        </div>

        {/* Tab Content */}
        {renderTabContent()}
      </div>

      {/* Click outside to close notifications */}
      {showNotifications && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowNotifications(false)}
        ></div>
      )}
    </div>
  );
}

// MetricCard component definition
const MetricCard = ({ title, value, subtitle, change, icon, color }: any) => (
  <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
    <div className="flex items-start justify-between mb-4">
      <div className={`w-10 h-10 lg:w-12 lg:h-12 ${color} rounded-lg flex items-center justify-center`}>
        <i className={`${icon} text-white text-lg lg:text-xl`}></i>
      </div>
      <div className={`flex items-center space-x-1 text-sm ${
        change.startsWith('+') ? 'text-green-600' : 'text-red-600'
      }`}>
        <i className={`${change.startsWith('+') ? 'ri-arrow-up-line' : 'ri-arrow-down-line'}`}></i>
        <span>{change}</span>
      </div>
    </div>
    <h3 className="text-sm font-medium text-gray-600 mb-1">{title}</h3>
    <p className="text-xl lg:text-2xl font-bold text-gray-900 mb-1">{value}</p>
    <p className="text-sm text-gray-500">{subtitle}</p>
  </div>
);

// LineChart component definition
const LineChart = ({ data, title }: any) => {
  const salesData = [
    { month: 'Ene', value: 4000 },
    { month: 'Feb', value: 3500 },
    { month: 'Mar', value: 2800 },
    { month: 'Abr', value: 2200 },
    { month: 'May', value: 2500 },
    { month: 'Jun', value: 2800 }
  ];
  
  const maxValue = Math.max(...salesData.map((d: any) => d.value));
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 lg:p-6">
      <h3 className="text-base lg:text-lg font-semibold text-gray-900 mb-4">{title}</h3>
      <div className="relative h-48 lg:h-64">
        <div className="absolute inset-0 flex items-end justify-between px-2 lg:px-4 pb-6 lg:pb-8">
          {salesData.map((item: any, index: number) => (
            <div key={index} className="flex flex-col items-center space-y-2">
              <div 
                className="bg-blue-500 rounded-t-lg w-8 lg:w-12 transition-all duration-300 hover:bg-blue-600"
                style={{ height: `${(item.value / maxValue) * 140}px` }}
              ></div>
              <span className="text-xs lg:text-sm text-gray-600 font-medium">{item.month}</span>
            </div>
          ))}
        </div>
        <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-gray-500">
          <span>{maxValue}</span>
          <span>{Math.round(maxValue * 0.75)}</span>
          <span>{Math.round(maxValue * 0.5)}</span>
          <span>{Math.round(maxValue * 0.25)}</span>
          <span>0</span>
        </div>
      </div>
    </div>
  );
};

// PieChart component definition
const PieChart = ({ data, title }: any) => {
  const categoryData = [
    { name: 'Medicamentos', value: 65, color: 'bg-blue-500' },
    { name: 'Material Médico', value: 20, color: 'bg-green-500' },
    { name: 'EPP', value: 10, color: 'bg-orange-500' },
    { name: 'Equipos', value: 5, color: 'bg-purple-500' }
  ];
  
  const total = categoryData.reduce((sum: number, item: any) => sum + item.value, 0);
  let cumulativePercentage = 0;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 lg:p-6">
      <h3 className="text-base lg:text-lg font-semibold text-gray-900 mb-4">{title}</h3>
      <div className="flex items-center justify-center">
        <div className="relative w-32 h-32 lg:w-48 lg:h-48">
          <div className="w-full h-full rounded-full bg-gray-200 relative overflow-hidden">
            {categoryData.map((item: any, index: number) => {
              const percentage = (item.value / total) * 100;
              const rotation = (cumulativePercentage / 100) * 360;
              cumulativePercentage += percentage;
              
              return (
                <div
                  key={index}
                  className={`absolute inset-0 ${item.color} rounded-full`}
                  style={{
                    clipPath: `polygon(50% 50%, 50% 0%, ${
                      50 + 50 * Math.cos((rotation * Math.PI) / 180)
                    }% ${50 + 50 * Math.sin((rotation * Math.PI) / 180)}%, ${
                      50 + 50 * Math.cos(((rotation + (percentage / 100) * 360) * Math.PI) / 180)
                    }% ${50 + 50 * Math.sin(((rotation + (percentage / 100) * 360) * Math.PI) / 180)}%)`
                  }}
                ></div>
              );
            })}
          </div>
        </div>
      </div>
      <div className="mt-4 lg:mt-6 space-y-3">
        {categoryData.map((item: any, index: number) => (
          <div key={index} className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className={`w-3 h-3 lg:w-4 lg:h-4 ${item.color} rounded`}></div>
              <span className="text-sm font-medium text-gray-700">{item.name}</span>
            </div>
            <span className="text-sm font-semibold text-gray-900">{item.value}%</span>
          </div>
        ))}
      </div>
    </div>
  );
};
