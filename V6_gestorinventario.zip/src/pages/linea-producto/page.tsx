
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function LineaProducto() {
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTipo, setFilterTipo] = useState('todos');
  const [activeTab, setActiveTab] = useState('lineas');

  const lineas = [
    {
      id: 1,
      codigo: 'LIN-001',
      nombre: 'Protección y Seguridad',
      descripcion: 'Productos para protección personal y seguridad del personal médico',
      familias: 3,
      productos: 15,
      estado: 'activo',
      fechaCreacion: '2024-01-10'
    },
    {
      id: 2,
      codigo: 'LIN-002',
      nombre: 'Material Médico',
      descripcion: 'Instrumentos y materiales médicos para procedimientos',
      familias: 4,
      productos: 28,
      estado: 'activo',
      fechaCreacion: '2024-01-10'
    },
    {
      id: 3,
      codigo: 'LIN-003',
      nombre: 'Higiene y Limpieza',
      descripcion: 'Productos de higiene y limpieza hospitalaria',
      familias: 2,
      productos: 12,
      estado: 'activo',
      fechaCreacion: '2024-01-10'
    },
    {
      id: 4,
      codigo: 'LIN-004',
      nombre: 'Equipos Médicos',
      descripcion: 'Equipos y dispositivos médicos especializados',
      familias: 3,
      productos: 8,
      estado: 'inactivo',
      fechaCreacion: '2024-01-05'
    }
  ];

  const familias = [
    {
      id: 1,
      codigo: 'FAM-001',
      nombre: 'Mascarillas y Respiradores',
      descripcion: 'Mascarillas quirúrgicas, N95 y respiradores',
      linea: 'Protección y Seguridad',
      lineaId: 1,
      productos: 5,
      estado: 'activo',
      fechaCreacion: '2024-01-10'
    },
    {
      id: 2,
      codigo: 'FAM-002',
      nombre: 'Guantes Médicos',
      descripcion: 'Guantes de látex, nitrilo y vinilo',
      linea: 'Protección y Seguridad',
      lineaId: 1,
      productos: 8,
      estado: 'activo',
      fechaCreacion: '2024-01-10'
    },
    {
      id: 3,
      codigo: 'FAM-003',
      nombre: 'Batas y Uniformes',
      descripcion: 'Batas quirúrgicas y uniformes médicos',
      linea: 'Protección y Seguridad',
      lineaId: 1,
      productos: 2,
      estado: 'activo',
      fechaCreacion: '2024-01-10'
    },
    {
      id: 4,
      codigo: 'FAM-004',
      nombre: 'Jeringas y Agujas',
      descripcion: 'Jeringas desechables y agujas de diferentes calibres',
      linea: 'Material Médico',
      lineaId: 2,
      productos: 12,
      estado: 'activo',
      fechaCreacion: '2024-01-10'
    },
    {
      id: 5,
      codigo: 'FAM-005',
      nombre: 'Material de Curación',
      descripcion: 'Gasas, vendas y material para curación',
      linea: 'Material Médico',
      lineaId: 2,
      productos: 10,
      estado: 'activo',
      fechaCreacion: '2024-01-10'
    },
    {
      id: 6,
      codigo: 'FAM-006',
      nombre: 'Desinfectantes',
      descripcion: 'Alcohol, gel antibacterial y desinfectantes',
      linea: 'Higiene y Limpieza',
      lineaId: 3,
      productos: 7,
      estado: 'activo',
      fechaCreacion: '2024-01-10'
    }
  ];

  const currentData = activeTab === 'lineas' ? lineas : familias;
  const filteredData = currentData.filter(item => {
    const matchesSearch = item.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.codigo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.descripcion.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTipo = filterTipo === 'todos' || item.estado === filterTipo;
    return matchesSearch && matchesTipo;
  });

  const getEstadoColor = (estado: string) => {
    switch (estado) {
      case 'activo':
        return 'bg-green-100 text-green-800';
      case 'inactivo':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Navigation */}
      <header className="bg-slate-700 shadow-sm">
        <div className="px-4 lg:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <i className="ri-archive-line text-white text-lg"></i>
                </div>
                <button 
                  onClick={() => navigate('/')}
                  className="text-lg lg:text-xl font-bold text-white hover:text-blue-200 transition-colors"
                >
                  Sistema de Inventarios
                </button>
              </div>
              <div className="text-white">
                <i className="ri-arrow-right-s-line mx-2"></i>
                <span className="text-blue-200">Línea y Familia del Producto</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 lg:px-6 py-6 lg:py-8">
        {/* Page Header */}
        <div className="mb-6">
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">Línea y Familia del Producto</h1>
          <p className="text-gray-600">Organiza los productos por líneas y familias para una mejor gestión</p>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-4 lg:px-6">
              <button
                onClick={() => setActiveTab('lineas')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'lineas'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <i className="ri-node-tree text-lg"></i>
                  <span>Líneas de Producto</span>
                  <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs">
                    {lineas.length}
                  </span>
                </div>
              </button>
              <button
                onClick={() => setActiveTab('familias')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'familias'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <i className="ri-folder-line text-lg"></i>
                  <span>Familias de Producto</span>
                  <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs">
                    {familias.length}
                  </span>
                </div>
              </button>
            </nav>
          </div>

          {/* Filters and Search */}
          <div className="p-4 lg:p-6">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
              <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
                <div className="relative">
                  <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                  <input
                    type="text"
                    placeholder={`Buscar ${activeTab}...`}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 w-full sm:w-64"
                  />
                </div>
                <select
                  value={filterTipo}
                  onChange={(e) => setFilterTipo(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8"
                >
                  <option value="todos">Todos los estados</option>
                  <option value="activo">Activo</option>
                  <option value="inactivo">Inactivo</option>
                </select>
              </div>
              <button 
                onClick={() => setShowModal(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap"
              >
                <i className="ri-add-line"></i>
                <span>Nueva {activeTab === 'lineas' ? 'Línea' : 'Familia'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-6">
          <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">Total Líneas</p>
                <p className="text-2xl font-bold text-gray-900">{lineas.length}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <i className="ri-node-tree text-blue-600 text-xl"></i>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">Total Familias</p>
                <p className="text-2xl font-bold text-gray-900">{familias.length}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <i className="ri-folder-line text-green-600 text-xl"></i>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">Productos Organizados</p>
                <p className="text-2xl font-bold text-gray-900">63</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <i className="ri-archive-line text-purple-600 text-xl"></i>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">Líneas Activas</p>
                <p className="text-2xl font-bold text-gray-900">{lineas.filter(l => l.estado === 'activo').length}</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <i className="ri-check-line text-orange-600 text-xl"></i>
              </div>
            </div>
          </div>
        </div>

        {/* Data Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-4 lg:p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">
              {activeTab === 'lineas' ? 'Líneas de Producto' : 'Familias de Producto'}
            </h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {activeTab === 'lineas' ? 'Línea' : 'Familia'}
                  </th>
                  <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Descripción
                  </th>
                  {activeTab === 'familias' && (
                    <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Línea
                    </th>
                  )}
                  <th className="px-4 lg:px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {activeTab === 'lineas' ? 'Familias' : 'Productos'}
                  </th>
                  <th className="px-4 lg:px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Estado
                  </th>
                  <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Fecha Creación
                  </th>
                  <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Acciones
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredData.map((item) => (
                  <tr key={item.id} className="hover:bg-gray-50">
                    <td className="px-4 lg:px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">{item.nombre}</div>
                        <div className="text-sm text-gray-500">{item.codigo}</div>
                      </div>
                    </td>
                    <td className="px-4 lg:px-6 py-4">
                      <div className="text-sm text-gray-900">{item.descripcion}</div>
                    </td>
                    {activeTab === 'familias' && (
                      <td className="px-4 lg:px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{(item as any).linea}</div>
                      </td>
                    )}
                    <td className="px-4 lg:px-6 py-4 whitespace-nowrap text-center">
                      <div className="text-sm font-medium text-gray-900">
                        {activeTab === 'lineas' ? (item as any).familias : (item as any).productos}
                      </div>
                    </td>
                    <td className="px-4 lg:px-6 py-4 whitespace-nowrap text-center">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getEstadoColor(item.estado)}`}>
                        {item.estado.charAt(0).toUpperCase() + item.estado.slice(1)}
                      </span>
                    </td>
                    <td className="px-4 lg:px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{item.fechaCreacion}</div>
                    </td>
                    <td className="px-4 lg:px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex items-center space-x-2">
                        <button 
                          onClick={() => {
                            setSelectedItem(item);
                            setShowModal(true);
                          }}
                          className="text-blue-600 hover:text-blue-900"
                        >
                          <i className="ri-edit-line"></i>
                        </button>
                        <button className="text-green-600 hover:text-green-900">
                          <i className="ri-eye-line"></i>
                        </button>
                        <button className="text-red-600 hover:text-red-900">
                          <i className="ri-delete-bin-line"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Modal for Add/Edit */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-4 lg:p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-lg lg:text-xl font-semibold text-gray-900">
                  {selectedItem ? `Editar ${activeTab === 'lineas' ? 'Línea' : 'Familia'}` : `Nueva ${activeTab === 'lineas' ? 'Línea' : 'Familia'}`}
                </h2>
                <button 
                  onClick={() => {
                    setShowModal(false);
                    setSelectedItem(null);
                  }}
                  className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
                >
                  <i className="ri-close-line text-xl"></i>
                </button>
              </div>
            </div>
            
            <div className="p-4 lg:p-6">
              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Código
                    </label>
                    <input
                      type="text"
                      defaultValue={selectedItem?.codigo || ''}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder={activeTab === 'lineas' ? 'LIN-001' : 'FAM-001'}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nombre
                    </label>
                    <input
                      type="text"
                      defaultValue={selectedItem?.nombre || ''}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder={`Nombre de la ${activeTab === 'lineas' ? 'línea' : 'familia'}`}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Descripción
                  </label>
                  <textarea
                    defaultValue={selectedItem?.descripcion || ''}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Descripción detallada..."
                  ></textarea>
                </div>

                {activeTab === 'familias' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Línea de Producto
                    </label>
                    <select 
                      defaultValue={selectedItem?.lineaId || ''}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8"
                    >
                      <option value="">Seleccionar línea</option>
                      {lineas.map((linea) => (
                        <option key={linea.id} value={linea.id}>{linea.nombre}</option>
                      ))}
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Estado
                  </label>
                  <select 
                    defaultValue={selectedItem?.estado || 'activo'}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8"
                  >
                    <option value="activo">Activo</option>
                    <option value="inactivo">Inactivo</option>
                  </select>
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-end space-y-3 sm:space-y-0 sm:space-x-4 pt-4 border-t border-gray-200">
                  <button 
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setSelectedItem(null);
                    }}
                    className="w-full sm:w-auto px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 whitespace-nowrap"
                  >
                    Cancelar
                  </button>
                  <button 
                    type="submit"
                    onClick={(e) => {
                      e.preventDefault();
                      alert(`${activeTab === 'lineas' ? 'Línea' : 'Familia'} ${selectedItem ? 'actualizada' : 'creada'} exitosamente`);
                      setShowModal(false);
                      setSelectedItem(null);
                    }}
                    className="w-full sm:w-auto px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 whitespace-nowrap"
                  >
                    {selectedItem ? 'Actualizar' : 'Crear'} {activeTab === 'lineas' ? 'Línea' : 'Familia'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
