
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Transacciones() {
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);
  const [selectedTransaccion, setSelectedTransaccion] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTipo, setFilterTipo] = useState('todos');
  const [filterFecha, setFilterFecha] = useState('todos');

  const transacciones = [
    {
      id: 1,
      codigo: 'TXN-001',
      tipo: 'entrada',
      producto: 'Mascarillas N95',
      cantidad: 500,
      almacen: 'Almacén Central',
      responsable: 'Carlos Mendoza',
      fecha: '2024-01-15',
      hora: '14:30',
      observaciones: 'Recepción de orden de compra OC-2024-001',
      estado: 'completada'
    },
    {
      id: 2,
      codigo: 'TXN-002',
      tipo: 'salida',
      producto: 'Guantes de Látex',
      cantidad: 200,
      almacen: 'Almacén de Medicamentos',
      responsable: 'Ana García',
      fecha: '2024-01-15',
      hora: '16:45',
      observaciones: 'Entrega a área de emergencias',
      estado: 'completada'
    },
    {
      id: 3,
      codigo: 'TXN-003',
      tipo: 'transferencia',
      producto: 'Jeringas Desechables',
      cantidad: 1000,
      almacen: 'Almacén Central → Almacén de Medicamentos',
      responsable: 'Miguel Torres',
      fecha: '2024-01-15',
      hora: '12:15',
      observaciones: 'Transferencia por redistribución de stock',
      estado: 'en_proceso'
    },
    {
      id: 4,
      codigo: 'TXN-004',
      tipo: 'ajuste',
      producto: 'Alcohol en Gel',
      cantidad: -50,
      almacen: 'Almacén de Emergencia',
      responsable: 'Laura Vásquez',
      fecha: '2024-01-14',
      hora: '09:30',
      observaciones: 'Ajuste por productos vencidos',
      estado: 'completada'
    },
    {
      id: 5,
      codigo: 'TXN-005',
      tipo: 'entrada',
      producto: 'Termómetros Digitales',
      cantidad: 25,
      almacen: 'Almacén de Equipos',
      responsable: 'Carlos Mendoza',
      fecha: '2024-01-14',
      hora: '11:00',
      observaciones: 'Compra de emergencia',
      estado: 'pendiente'
    }
  ];

  const filteredTransacciones = transacciones.filter(transaccion => {
    const matchesSearch = transaccion.producto.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaccion.codigo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaccion.responsable.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTipo = filterTipo === 'todos' || transaccion.tipo === filterTipo;
    const matchesFecha = filterFecha === 'todos' || 
                        (filterFecha === 'hoy' && transaccion.fecha === '2024-01-15') ||
                        (filterFecha === 'ayer' && transaccion.fecha === '2024-01-14');
    return matchesSearch && matchesTipo && matchesFecha;
  });

  const getTipoColor = (tipo: string) => {
    switch (tipo) {
      case 'entrada':
        return 'bg-green-100 text-green-800';
      case 'salida':
        return 'bg-red-100 text-red-800';
      case 'transferencia':
        return 'bg-blue-100 text-blue-800';
      case 'ajuste':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getEstadoColor = (estado: string) => {
    switch (estado) {
      case 'completada':
        return 'bg-green-100 text-green-800';
      case 'en_proceso':
        return 'bg-yellow-100 text-yellow-800';
      case 'pendiente':
        return 'bg-orange-100 text-orange-800';
      case 'cancelada':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getTipoIcon = (tipo: string) => {
    switch (tipo) {
      case 'entrada':
        return 'ri-arrow-down-line';
      case 'salida':
        return 'ri-arrow-up-line';
      case 'transferencia':
        return 'ri-exchange-line';
      case 'ajuste':
        return 'ri-settings-line';
      default:
        return 'ri-file-line';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Navigation */}
      <header className="bg-slate-700 shadow-sm">
        <div className="px-4 lg:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <i className="ri-archive-line text-white text-lg"></i>
                </div>
                <button 
                  onClick={() => navigate('/')}
                  className="text-lg lg:text-xl font-bold text-white hover:text-blue-200 transition-colors"
                >
                  Sistema de Inventarios
                </button>
              </div>
              <div className="text-white">
                <i className="ri-arrow-right-s-line mx-2"></i>
                <span className="text-blue-200">Transacciones</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 lg:px-6 py-6 lg:py-8">
        {/* Page Header */}
        <div className="mb-6">
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">Registro de Transacciones</h1>
          <p className="text-gray-600">Controla todos los movimientos de entrada, salida y transferencias</p>
        </div>

        {/* Filters and Search */}
        <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100 mb-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
              <div className="relative">
                <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <input
                  type="text"
                  placeholder="Buscar transacciones..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 w-full sm:w-64"
                />
              </div>
              <select
                value={filterTipo}
                onChange={(e) => setFilterTipo(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8"
              >
                <option value="todos">Todos los tipos</option>
                <option value="entrada">Entrada</option>
                <option value="salida">Salida</option>
                <option value="transferencia">Transferencia</option>
                <option value="ajuste">Ajuste</option>
              </select>
              <select
                value={filterFecha}
                onChange={(e) => setFilterFecha(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8"
              >
                <option value="todos">Todas las fechas</option>
                <option value="hoy">Hoy</option>
                <option value="ayer">Ayer</option>
              </select>
            </div>
            <button 
              onClick={() => setShowModal(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap"
            >
              <i className="ri-add-line"></i>
              <span>Nueva Transacción</span>
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-6">
          <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">Entradas Hoy</p>
                <p className="text-2xl font-bold text-gray-900">2</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <i className="ri-arrow-down-line text-green-600 text-xl"></i>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">Salidas Hoy</p>
                <p className="text-2xl font-bold text-gray-900">1</p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <i className="ri-arrow-up-line text-red-600 text-xl"></i>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">Transferencias</p>
                <p className="text-2xl font-bold text-gray-900">1</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <i className="ri-exchange-line text-blue-600 text-xl"></i>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">Pendientes</p>
                <p className="text-2xl font-bold text-gray-900">1</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <i className="ri-time-line text-orange-600 text-xl"></i>
              </div>
            </div>
          </div>
        </div>

        {/* Transacciones Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-4 lg:p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Historial de Transacciones</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Transacción
                  </th>
                  <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Producto
                  </th>
                  <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Cantidad
                  </th>
                  <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Almacén
                  </th>
                  <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Fecha/Hora
                  </th>
                  <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Estado
                  </th>
                  <th className="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Acciones
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredTransacciones.map((transaccion) => (
                  <tr key={transaccion.id} className="hover:bg-gray-50">
                    <td className="px-4 lg:px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${getTipoColor(transaccion.tipo)}`}>
                          <i className={`${getTipoIcon(transaccion.tipo)} text-sm`}></i>
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">{transaccion.codigo}</div>
                          <div className={`text-xs px-2 py-1 rounded-full inline-block ${getTipoColor(transaccion.tipo)}`}>
                            {transaccion.tipo.charAt(0).toUpperCase() + transaccion.tipo.slice(1)}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 lg:px-6 py-4">
                      <div className="text-sm text-gray-900">{transaccion.producto}</div>
                    </td>
                    <td className="px-4 lg:px-6 py-4 whitespace-nowrap">
                      <div className={`text-sm font-medium ${transaccion.cantidad > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {transaccion.cantidad > 0 ? '+' : ''}{transaccion.cantidad.toLocaleString()}
                      </div>
                    </td>
                    <td className="px-4 lg:px-6 py-4">
                      <div className="text-sm text-gray-900">{transaccion.almacen}</div>
                    </td>
                    <td className="px-4 lg:px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{transaccion.fecha}</div>
                      <div className="text-xs text-gray-500">{transaccion.hora}</div>
                    </td>
                    <td className="px-4 lg:px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getEstadoColor(transaccion.estado)}`}>
                        {transaccion.estado.replace('_', ' ').charAt(0).toUpperCase() + transaccion.estado.replace('_', ' ').slice(1)}
                      </span>
                    </td>
                    <td className="px-4 lg:px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex items-center space-x-2">
                        <button 
                          onClick={() => {
                            setSelectedTransaccion(transaccion);
                            setShowModal(true);
                          }}
                          className="text-blue-600 hover:text-blue-900"
                        >
                          <i className="ri-eye-line"></i>
                        </button>
                        <button className="text-green-600 hover:text-green-900">
                          <i className="ri-edit-line"></i>
                        </button>
                        <button className="text-red-600 hover:text-red-900">
                          <i className="ri-delete-bin-line"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Modal for Add/View Transacción */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-4 lg:p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-lg lg:text-xl font-semibold text-gray-900">
                  {selectedTransaccion ? 'Detalles de Transacción' : 'Nueva Transacción'}
                </h2>
                <button 
                  onClick={() => {
                    setShowModal(false);
                    setSelectedTransaccion(null);
                  }}
                  className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
                >
                  <i className="ri-close-line text-xl"></i>
                </button>
              </div>
            </div>
            
            <div className="p-4 lg:p-6">
              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Tipo de Transacción
                    </label>
                    <select 
                      defaultValue={selectedTransaccion?.tipo || ''}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8"
                    >
                      <option value="">Seleccionar tipo</option>
                      <option value="entrada">Entrada</option>
                      <option value="salida">Salida</option>
                      <option value="transferencia">Transferencia</option>
                      <option value="ajuste">Ajuste</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Producto
                    </label>
                    <input
                      type="text"
                      defaultValue={selectedTransaccion?.producto || ''}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Nombre del producto"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Cantidad
                    </label>
                    <input
                      type="number"
                      defaultValue={selectedTransaccion?.cantidad || ''}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="0"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Almacén
                    </label>
                    <select 
                      defaultValue={selectedTransaccion?.almacen || ''}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8"
                    >
                      <option value="">Seleccionar almacén</option>
                      <option value="Almacén Central">Almacén Central</option>
                      <option value="Almacén de Medicamentos">Almacén de Medicamentos</option>
                      <option value="Almacén de Equipos">Almacén de Equipos</option>
                      <option value="Almacén de Emergencia">Almacén de Emergencia</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Observaciones
                  </label>
                  <textarea
                    defaultValue={selectedTransaccion?.observaciones || ''}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Observaciones adicionales..."
                  ></textarea>
                </div>

                {selectedTransaccion && (
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium text-gray-900 mb-2">Información Adicional</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Código:</span>
                        <span className="ml-2 font-medium">{selectedTransaccion.codigo}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Responsable:</span>
                        <span className="ml-2 font-medium">{selectedTransaccion.responsable}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Fecha:</span>
                        <span className="ml-2 font-medium">{selectedTransaccion.fecha} {selectedTransaccion.hora}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Estado:</span>
                        <span className={`ml-2 px-2 py-1 text-xs rounded-full ${getEstadoColor(selectedTransaccion.estado)}`}>
                          {selectedTransaccion.estado.replace('_', ' ').charAt(0).toUpperCase() + selectedTransaccion.estado.replace('_', ' ').slice(1)}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row items-center justify-end space-y-3 sm:space-y-0 sm:space-x-4 pt-4 border-t border-gray-200">
                  <button 
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setSelectedTransaccion(null);
                    }}
                    className="w-full sm:w-auto px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 whitespace-nowrap"
                  >
                    {selectedTransaccion ? 'Cerrar' : 'Cancelar'}
                  </button>
                  {!selectedTransaccion && (
                    <button 
                      type="submit"
                      onClick={(e) => {
                        e.preventDefault();
                        alert('Transacción registrada exitosamente');
                        setShowModal(false);
                      }}
                      className="w-full sm:w-auto px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 whitespace-nowrap"
                    >
                      Registrar Transacción
                    </button>
                  )}
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
