
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Dashboard() {
  const navigate = useNavigate();
  const [dateRange, setDateRange] = useState('30d');
  const [showNotifications, setShowNotifications] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [user] = useState({
    name: 'María González',
    role: 'Administrador de Inventario',
    avatar: 'https://readdy.ai/api/search-image?query=professional%20woman%20administrator%20inventory%20management%20office%20corporate%20headshot%20clean%20background%20business%20attire%20confident%20smile%20latina&width=40&height=40&seq=1&orientation=squarish'
  });

  const notifications = [
    {
      id: 1,
      title: 'Stock Bajo',
      message: 'Mascarillas N95 requieren reposición urgente',
      time: 'Hace 5 min',
      type: 'warning',
      unread: true
    },
    {
      id: 2,
      title: 'Producto Vencido',
      message: 'Vacuna COVID-19 próxima a vencer',
      time: 'Hace 15 min',
      type: 'error',
      unread: true
    },
    {
      id: 3,
      title: 'Orden Completada',
      message: 'Orden de compra OC-2024-001 recibida',
      time: 'Hace 1 hora',
      type: 'success',
      unread: false
    }
  ];

  const metrics = [
    {
      title: 'Stock Total vs Costo',
      value: '$348,750',
      items: '3,245 productos',
      change: '+15.2%',
      trend: 'up',
      icon: 'ri-money-dollar-circle-line',
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      title: 'Productos de Mayor Rotación',
      value: '127',
      items: 'productos activos',
      change: '+8.4%',
      trend: 'up',
      icon: 'ri-refresh-line',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      title: 'Próximos a Vencer',
      value: '23',
      items: 'en 30 días',
      change: '-12.3%',
      trend: 'down',
      icon: 'ri-time-line',
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    },
    {
      title: 'Stock Bajo',
      value: '18',
      items: 'productos críticos',
      change: '+5.1%',
      trend: 'up',
      icon: 'ri-alert-line',
      color: 'text-red-600',
      bgColor: 'bg-red-50'
    }
  ];

  const topProducts = [
    { name: 'Acetaminofén 500mg', category: 'Medicamentos', stock: 450, rotation: 'Alta', status: 'normal' },
    { name: 'Jeringa 10ml', category: 'Material Médico', stock: 1200, rotation: 'Alta', status: 'normal' },
    { name: 'Guantes Latex Talla M', category: 'EPP', stock: 85, rotation: 'Media', status: 'bajo' },
    { name: 'Alcohol Etílico 70%', category: 'Antisépticos', stock: 320, rotation: 'Alta', status: 'normal' },
    { name: 'Vendas Elásticas 10cm', category: 'Material Médico', stock: 156, rotation: 'Media', status: 'normal' }
  ];

  const expiringProducts = [
    { name: 'Vacuna COVID-19', batch: 'CV2024-001', expiry: '2024-02-15', days: 8, status: 'crítico' },
    { name: 'Suero Fisiológico 500ml', batch: 'SF2024-045', expiry: '2024-02-28', days: 21, status: 'advertencia' },
    { name: 'Ibuprofeno 400mg', batch: 'IB2024-023', expiry: '2024-03-10', days: 31, status: 'advertencia' },
    { name: 'Vitamina C 1000mg', batch: 'VC2024-012', expiry: '2024-03-15', days: 36, status: 'normal' }
  ];

  const lowStockProducts = [
    { name: 'Mascarillas N95', current: 12, minimum: 50, category: 'EPP', urgency: 'alta' },
    { name: 'Termómetros Digitales', current: 3, minimum: 10, category: 'Equipos', urgency: 'alta' },
    { name: 'Alcohol en Gel 250ml', current: 25, minimum: 100, category: 'Antisépticos', urgency: 'media' },
    { name: 'Gasas Estériles 10x10', current: 78, minimum: 200, category: 'Material Médico', urgency: 'media' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Navigation */}
      <header className="bg-slate-700 shadow-sm">
        <div className="px-4 lg:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 lg:space-x-6">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <i className="ri-archive-line text-white text-lg"></i>
                </div>
                <button 
                  onClick={() => navigate('/')}
                  className="text-lg lg:text-xl font-bold text-white hover:text-blue-200 transition-colors cursor-pointer"
                >
                  Sistema de Inventarios
                </button>
              </div>
              
              {/* Desktop Navigation Menu */}
              <nav className="hidden lg:flex items-center space-x-8">
                <button className="text-white bg-blue-600 px-3 py-1 rounded-md font-medium whitespace-nowrap">
                  Dashboard
                </button>
                <button 
                  onClick={() => navigate('/productos')}
                  className="text-blue-200 hover:text-white font-medium transition-colors whitespace-nowrap"
                >
                  Productos
                </button>
                <button 
                  onClick={() => navigate('/inventario')}
                  className="text-blue-200 hover:text-white font-medium transition-colors whitespace-nowrap"
                >
                  Inventario
                </button>
                <button 
                  onClick={() => navigate('/reportes')}
                  className="text-blue-200 hover:text-white font-medium transition-colors whitespace-nowrap"
                >
                  Reportes
                </button>
                <button 
                  onClick={() => navigate('/configuracion')}
                  className="text-blue-200 hover:text-white font-medium transition-colors whitespace-nowrap"
                >
                  Configuración
                </button>
              </nav>
            </div>
            
            <div className="flex items-center space-x-2 lg:space-x-4">
              {/* Mobile menu button */}
              <button 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 text-white hover:text-blue-200"
              >
                <i className={`${mobileMenuOpen ? 'ri-close-line' : 'ri-menu-line'} text-xl`}></i>
              </button>

              {/* Notifications */}
              <div className="relative">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="p-2 text-white hover:text-blue-200 relative"
                >
                  <i className="ri-notification-3-line text-xl"></i>
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center">
                    {notifications.filter(n => n.unread).length}
                  </span>
                </button>

                {/* Notifications Dropdown */}
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl border border-gray-200 z-50">
                    <div className="p-4 border-b border-gray-100">
                      <h3 className="font-semibold text-gray-900">Notificaciones</h3>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.map((notification) => (
                        <div key={notification.id} className={`p-4 border-b border-gray-100 hover:bg-gray-50 ${notification.unread ? 'bg-blue-50' : ''}`}>
                          <div className="flex items-start space-x-3">
                            <div className={`w-2 h-2 rounded-full mt-2 ${
                              notification.type === 'error' ? 'bg-red-500' :
                              notification.type === 'warning' ? 'bg-yellow-500' :
                              'bg-green-500'
                            }`}></div>
                            <div className="flex-1">
                              <h4 className="font-medium text-gray-900 text-sm">{notification.title}</h4>
                              <p className="text-sm text-gray-600 mt-1">{notification.message}</p>
                              <p className="text-xs text-gray-500 mt-2">{notification.time}</p>
                            </div>
                            {notification.unread && (
                              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="p-4 border-t border-gray-100">
                      <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
                        Ver todas las notificaciones
                      </button>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="hidden lg:flex items-center space-x-3">
                <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                <div className="text-sm">
                  <p className="font-medium text-white">{user.name}</p>
                  <p className="text-blue-200">{user.role}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile Navigation Menu */}
          {mobileMenuOpen && (
            <div className="lg:hidden mt-4 pb-4 border-t border-slate-600">
              <nav className="flex flex-col space-y-2 mt-4">
                <button className="text-white bg-blue-600 px-3 py-2 rounded-md font-medium text-left">
                  Dashboard
                </button>
                <button 
                  onClick={() => {
                    navigate('/productos');
                    setMobileMenuOpen(false);
                  }}
                  className="text-blue-200 hover:text-white font-medium transition-colors text-left py-2"
                >
                  Productos
                </button>
                <button 
                  onClick={() => {
                    navigate('/inventario');
                    setMobileMenuOpen(false);
                  }}
                  className="text-blue-200 hover:text-white font-medium transition-colors text-left py-2"
                >
                  Inventario
                </button>
                <button 
                  onClick={() => {
                    navigate('/reportes');
                    setMobileMenuOpen(false);
                  }}
                  className="text-blue-200 hover:text-white font-medium transition-colors text-left py-2"
                >
                  Reportes
                </button>
                <button 
                  onClick={() => {
                    navigate('/configuracion');
                    setMobileMenuOpen(false);
                  }}
                  className="text-blue-200 hover:text-white font-medium transition-colors text-left py-2"
                >
                  Configuración
                </button>
              </nav>
              
              {/* Mobile User Info */}
              <div className="flex items-center space-x-3 mt-4 pt-4 border-t border-slate-600">
                <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                <div className="text-sm">
                  <p className="font-medium text-white">{user.name}</p>
                  <p className="text-blue-200">{user.role}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </header>

      <div className="px-4 lg:px-6 py-6 lg:py-8">
        {/* Page Header */}
        <div className="mb-6 lg:mb-8">
          <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">Dashboard</h2>
          <p className="text-gray-600">Panel de control con métricas principales del inventario</p>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-end mb-6 lg:mb-8">
          <div className="flex items-center space-x-4">
            <select 
              value={dateRange} 
              onChange={(e) => setDateRange(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8"
            >
              <option value="7d">Últimos 7 días</option>
              <option value="30d">Últimos 30 días</option>
              <option value="90d">Últimos 90 días</option>
              <option value="1y">Último año</option>
            </select>
            
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap">
              <i className="ri-download-line"></i>
              <span>Exportar Reporte</span>
            </button>
          </div>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-6 lg:mb-8">
          {[
            {
              title: 'Stock Total vs Costo',
              value: '$348,750',
              items: '3,245 productos',
              change: '+15.2%',
              trend: 'up',
              icon: 'ri-money-dollar-circle-line',
              color: 'text-green-600',
              bgColor: 'bg-green-50'
            },
            {
              title: 'Productos de Mayor Rotación',
              value: '127',
              items: 'productos activos',
              change: '+8.4%',
              trend: 'up',
              icon: 'ri-refresh-line',
              color: 'text-blue-600',
              bgColor: 'bg-blue-50'
            },
            {
              title: 'Próximos a Vencer',
              value: '23',
              items: 'en 30 días',
              change: '-12.3%',
              trend: 'down',
              icon: 'ri-time-line',
              color: 'text-orange-600',
              bgColor: 'bg-orange-50'
            },
            {
              title: 'Stock Bajo',
              value: '18',
              items: 'productos críticos',
              change: '+5.1%',
              trend: 'up',
              icon: 'ri-alert-line',
              color: 'text-red-600',
              bgColor: 'bg-red-50'
            }
          ].map((metric, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
              <div className="flex items-start justify-between mb-4">
                <div className={`w-10 h-10 lg:w-12 lg:h-12 ${metric.bgColor} rounded-lg flex items-center justify-center`}>
                  <i className={`${metric.icon} ${metric.color} text-lg lg:text-xl`}></i>
                </div>
                <div className={`flex items-center space-x-1 text-sm ${
                  metric.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  <i className={`${metric.trend === 'up' ? 'ri-arrow-up-line' : 'ri-arrow-down-line'}`}></i>
                  <span>{metric.change}</span>
                </div>
              </div>
              <h3 className="text-sm font-medium text-gray-600 mb-1">{metric.title}</h3>
              <p className="text-xl lg:text-2xl font-bold text-gray-900 mb-1">{metric.value}</p>
              <p className="text-sm text-gray-500">{metric.items}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
          {/* Top Products */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-4 lg:p-6 border-b border-gray-100">
              <h3 className="text-base lg:text-lg font-semibold text-gray-900">Productos de Mayor Rotación</h3>
              <p className="text-sm text-gray-600">Productos más utilizados en el período</p>
            </div>
            <div className="p-4 lg:p-6">
              <div className="space-y-4">
                {[
                  { name: 'Acetaminofén 500mg', category: 'Medicamentos', stock: 450, rotation: 'Alta', status: 'normal' },
                  { name: 'Jeringa 10ml', category: 'Material Médico', stock: 1200, rotation: 'Alta', status: 'normal' },
                  { name: 'Guantes Latex Talla M', category: 'EPP', stock: 85, rotation: 'Media', status: 'bajo' },
                  { name: 'Alcohol Etílico 70%', category: 'Antisépticos', stock: 320, rotation: 'Alta', status: 'normal' },
                  { name: 'Vendas Elásticas 10cm', category: 'Material Médico', stock: 156, rotation: 'Media', status: 'normal' }
                ].map((product, index) => (
                  <div key={index} className="flex items-center justify-between p-3 lg:p-4 bg-gray-50 rounded-lg">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-gray-900 text-sm lg:text-base truncate">{product.name}</h4>
                      <p className="text-xs lg:text-sm text-gray-600">{product.category}</p>
                    </div>
                    <div className="text-right mr-2 lg:mr-4">
                      <p className="font-semibold text-gray-900 text-sm lg:text-base">{product.stock}</p>
                      <p className="text-xs lg:text-sm text-gray-600">unidades</p>
                    </div>
                    <div className="flex flex-col space-y-1">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium whitespace-nowrap ${
                        product.status === 'normal' ? 'bg-green-100 text-green-700' :
                        product.status === 'bajo' ? 'bg-red-100 text-red-700' :
                        'bg-yellow-100 text-yellow-700'
                      }`}>
                        {product.status === 'normal' ? 'Normal' : 
                         product.status === 'bajo' ? 'Bajo' : 'Medio'}
                      </span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium whitespace-nowrap ${
                        product.rotation === 'Alta' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'
                      }`}>
                        {product.rotation}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Expiring Products */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-4 lg:p-6 border-b border-gray-100">
              <h3 className="text-base lg:text-lg font-semibold text-gray-900">Productos Próximos a Vencer</h3>
              <p className="text-sm text-gray-600">Productos que requieren atención inmediata</p>
            </div>
            <div className="p-4 lg:p-6">
              <div className="space-y-4">
                {[
                  { name: 'Vacuna COVID-19', batch: 'CV2024-001', expiry: '2024-02-15', days: 8, status: 'crítico' },
                  { name: 'Suero Fisiológico 500ml', batch: 'SF2024-045', expiry: '2024-02-28', days: 21, status: 'advertencia' },
                  { name: 'Ibuprofeno 400mg', batch: 'IB2024-023', expiry: '2024-03-10', days: 31, status: 'advertencia' },
                  { name: 'Vitamina C 1000mg', batch: 'VC2024-012', expiry: '2024-03-15', days: 36, status: 'normal' }
                ].map((product, index) => (
                  <div key={index} className="flex items-center justify-between p-3 lg:p-4 bg-gray-50 rounded-lg">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-gray-900 text-sm lg:text-base truncate">{product.name}</h4>
                      <p className="text-xs lg:text-sm text-gray-600">Lote: {product.batch}</p>
                    </div>
                    <div className="text-right mr-2 lg:mr-4">
                      <p className="font-medium text-gray-900 text-sm lg:text-base">{product.expiry}</p>
                      <p className="text-xs lg:text-sm text-gray-600">{product.days} días</p>
                    </div>
                    <span className={`px-2 lg:px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap ${
                      product.status === 'crítico' ? 'bg-red-100 text-red-700' :
                      product.status === 'advertencia' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-green-100 text-green-700'
                    }`}>
                      {product.status === 'crítico' ? 'Crítico' :
                       product.status === 'advertencia' ? 'Atención' : 'Normal'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Low Stock Products */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-4 lg:p-6 border-b border-gray-100">
              <h3 className="text-base lg:text-lg font-semibold text-gray-900">Productos con Bajo Stock</h3>
              <p className="text-sm text-gray-600">Productos que necesitan reposición</p>
            </div>
            <div className="p-4 lg:p-6">
              <div className="space-y-4">
                {[
                  { name: 'Mascarillas N95', current: 12, minimum: 50, category: 'EPP', urgency: 'alta' },
                  { name: 'Termómetros Digitales', current: 3, minimum: 10, category: 'Equipos', urgency: 'alta' },
                  { name: 'Alcohol en Gel 250ml', current: 25, minimum: 100, category: 'Antisépticos', urgency: 'media' },
                  { name: 'Gasas Estériles 10x10', current: 78, minimum: 200, category: 'Material Médico', urgency: 'media' }
                ].map((product, index) => (
                  <div key={index} className="flex items-center justify-between p-3 lg:p-4 bg-gray-50 rounded-lg">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-gray-900 text-sm lg:text-base truncate">{product.name}</h4>
                      <p className="text-xs lg:text-sm text-gray-600">{product.category}</p>
                    </div>
                    <div className="text-right mr-2 lg:mr-4">
                      <p className="font-medium text-gray-900 text-sm lg:text-base">{product.current}/{product.minimum}</p>
                      <p className="text-xs lg:text-sm text-gray-600">actual/mínimo</p>
                    </div>
                    <span className={`px-2 lg:px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap ${
                      product.urgency === 'alta' ? 'bg-red-100 text-red-700' :
                      product.urgency === 'media' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-green-100 text-green-700'
                    }`}>
                      {product.urgency === 'alta' ? 'Urgente' :
                       product.urgency === 'media' ? 'Medio' : 'Bajo'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Cost Analysis Chart Placeholder */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-4 lg:p-6 border-b border-gray-100">
              <h3 className="text-base lg:text-lg font-semibold text-gray-900">Análisis de Costos por Categoría</h3>
              <p className="text-sm text-gray-600">Distribución del valor del inventario</p>
            </div>
            <div className="p-4 lg:p-6">
              <div className="space-y-4">
                {[
                  { name: 'Medicamentos', value: 156800, percentage: '45%', color: 'bg-blue-500' },
                  { name: 'Material Médico', value: 89200, percentage: '26%', color: 'bg-green-500' },
                  { name: 'EPP', value: 52300, percentage: '15%', color: 'bg-yellow-500' },
                  { name: 'Equipos', value: 34750, percentage: '10%', color: 'bg-purple-500' },
                  { name: 'Otros', value: 15700, percentage: '4%', color: 'bg-red-500' }
                ].map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 lg:w-4 lg:h-4 ${item.color} rounded`}></div>
                      <span className="text-sm font-medium">{item.name}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-semibold text-sm lg:text-base">${item.value.toLocaleString()}</span>
                      <span className="text-xs lg:text-sm text-gray-600 ml-2">({item.percentage})</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Click outside to close notifications */}
      {showNotifications && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowNotifications(false)}
        ></div>
      )}
    </div>
  );
}
