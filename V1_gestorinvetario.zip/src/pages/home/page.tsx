
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Home() {
  const navigate = useNavigate();

  const modules = [
    {
      id: 'ordenes-compra',
      title: 'Órdenes de compra',
      icon: 'ri-file-list-3-line',
      description: 'Gestión de órdenes de compra y proveedores',
      color: 'bg-blue-50 hover:bg-blue-100',
      iconColor: 'text-blue-600'
    },
    {
      id: 'almacenes',
      title: 'Almacenes',
      icon: 'ri-building-2-line',
      description: 'Control de almacenes y ubicaciones',
      color: 'bg-green-50 hover:bg-green-100',
      iconColor: 'text-green-600'
    },
    {
      id: 'transacciones',
      title: 'Transacciones',
      icon: 'ri-exchange-line',
      description: 'Registro de movimientos y transacciones',
      color: 'bg-purple-50 hover:bg-purple-100',
      iconColor: 'text-purple-600'
    },
    {
      id: 'kardex',
      title: 'Kardex',
      icon: 'ri-bar-chart-box-line',
      description: 'Historial detallado de movimientos',
      color: 'bg-orange-50 hover:bg-orange-100',
      iconColor: 'text-orange-600'
    },
    {
      id: 'dashboard',
      title: 'Dashboard',
      icon: 'ri-dashboard-3-line',
      description: 'Panel de control y métricas',
      color: 'bg-indigo-50 hover:bg-indigo-100',
      iconColor: 'text-indigo-600'
    },
    {
      id: 'inventarios',
      title: 'Inventarios',
      icon: 'ri-archive-line',
      description: 'Control de stock y productos',
      color: 'bg-teal-50 hover:bg-teal-100',
      iconColor: 'text-teal-600'
    },
    {
      id: 'requerimientos',
      title: 'Requerimientos',
      icon: 'ri-task-line',
      description: 'Solicitudes de productos por área',
      color: 'bg-red-50 hover:bg-red-100',
      iconColor: 'text-red-600'
    },
    {
      id: 'catalogo-productos',
      title: 'Catálogo de productos',
      icon: 'ri-book-open-line',
      description: 'Gestión del catálogo de productos',
      color: 'bg-yellow-50 hover:bg-yellow-100',
      iconColor: 'text-yellow-600'
    },
    {
      id: 'linea-producto',
      title: 'Línea y familia del producto',
      icon: 'ri-node-tree',
      description: 'Organización por líneas y familias',
      color: 'bg-pink-50 hover:bg-pink-100',
      iconColor: 'text-pink-600'
    }
  ];

  const [user] = useState({
    name: 'María González',
    role: 'Administrador de Inventario',
    avatar: 'https://readdy.ai/api/search-image?query=professional%20woman%20administrator%20inventory%20management%20office%20corporate%20headshot%20clean%20background%20business%20attire%20confident%20smile%20latina&width=40&height=40&seq=1&orientation=squarish'
  });

  const quickStats = [
    { label: 'Productos en Stock', value: '2,847', change: '+12%', trend: 'up' },
    { label: 'Órdenes Pendientes', value: '23', change: '-5%', trend: 'down' },
    { label: 'Valor Total Inventario', value: '$248,500', change: '+8%', trend: 'up' },
    { label: 'Productos Críticos', value: '15', change: '0%', trend: 'neutral' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <i className="ri-archive-line text-white text-lg"></i>
              </div>
              <h1 className="text-2xl font-bold text-gray-900">Sistema de Inventarios</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <button className="p-2 text-gray-400 hover:text-gray-600 relative">
                  <i className="ri-notification-3-line text-xl"></i>
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center">3</span>
                </button>
              </div>
              
              <div className="flex items-center space-x-3">
                <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                <div className="text-sm">
                  <p className="font-medium text-gray-900">{user.name}</p>
                  <p className="text-gray-500">{user.role}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Bienvenido, {user.name}</h2>
          <p className="text-gray-600">Gestiona tu inventario de manera eficiente desde el panel de control</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {quickStats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`flex items-center space-x-1 text-sm ${
                  stat.trend === 'up' ? 'text-green-600' : 
                  stat.trend === 'down' ? 'text-red-600' : 
                  'text-gray-500'
                }`}>
                  {stat.trend === 'up' && <i className="ri-arrow-up-line"></i>}
                  {stat.trend === 'down' && <i className="ri-arrow-down-line"></i>}
                  <span>{stat.change}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Main Modules */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Módulos del Sistema</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {modules.map((module) => (
              <div
                key={module.id}
                className={`${module.color} rounded-xl p-6 border border-gray-200 cursor-pointer transition-all duration-200 hover:shadow-md`}
                onClick={() => navigate(`/${module.id}`)}
              >
                <div className="flex items-start space-x-4">
                  <div className={`w-12 h-12 rounded-lg bg-white flex items-center justify-center ${module.iconColor}`}>
                    <i className={`${module.icon} text-xl`}></i>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-2">{module.title}</h4>
                    <p className="text-sm text-gray-600">{module.description}</p>
                  </div>
                  <i className="ri-arrow-right-s-line text-gray-400 text-lg"></i>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Acciones Rápidas</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <button className="flex items-center space-x-3 p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors whitespace-nowrap">
              <i className="ri-add-line text-blue-600 text-lg"></i>
              <span className="font-medium text-blue-700">Nuevo Requerimiento</span>
            </button>
            
            <button className="flex items-center space-x-3 p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors whitespace-nowrap">
              <i className="ri-shopping-cart-line text-green-600 text-lg"></i>
              <span className="font-medium text-green-700">Crear Orden de Compra</span>
            </button>
            
            <button className="flex items-center space-x-3 p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors whitespace-nowrap">
              <i className="ri-truck-line text-purple-600 text-lg"></i>
              <span className="font-medium text-purple-700">Registrar Recepción</span>
            </button>
            
            <button className="flex items-center space-x-3 p-4 bg-orange-50 hover:bg-orange-100 rounded-lg transition-colors whitespace-nowrap">
              <i className="ri-file-chart-line text-orange-600 text-lg"></i>
              <span className="font-medium text-orange-700">Generar Reporte</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
