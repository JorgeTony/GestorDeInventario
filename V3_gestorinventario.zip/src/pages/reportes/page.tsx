
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Reportes() {
  const navigate = useNavigate();
  const [selectedTab, setSelectedTab] = useState('ventas');
  const [dateRange, setDateRange] = useState('6m');

  const [user] = useState({
    name: 'María González',
    role: 'Administrador de Inventario',
    avatar: 'https://readdy.ai/api/search-image?query=professional%20woman%20administrator%20inventory%20management%20office%20corporate%20headshot%20clean%20background%20business%20attire%20confident%20smile%20latina&width=40&height=40&seq=1&orientation=squarish'
  });

  const tabs = [
    { id: 'ventas', label: 'Reporte de Ventas', icon: 'ri-line-chart-line' },
    { id: 'inventario', label: 'Estado de Inventario', icon: 'ri-archive-line' },
    { id: 'movimientos', label: 'Movimientos de Stock', icon: 'ri-exchange-line' },
    { id: 'financiero', label: 'Reporte Financiero', icon: 'ri-money-dollar-circle-line' }
  ];

  // Datos simulados para los gráficos
  const salesData = [
    { month: 'Ene', value: 4000 },
    { month: 'Feb', value: 3500 },
    { month: 'Mar', value: 2800 },
    { month: 'Abr', value: 2200 },
    { month: 'May', value: 2500 },
    { month: 'Jun', value: 2800 }
  ];

  const categoryData = [
    { name: 'Medicamentos', value: 65, color: 'bg-blue-500' },
    { name: 'Material Médico', value: 20, color: 'bg-green-500' },
    { name: 'EPP', value: 10, color: 'bg-orange-500' },
    { name: 'Equipos', value: 5, color: 'bg-purple-500' }
  ];

  // Datos específicos para cada pestaña
  const getTabData = () => {
    switch (selectedTab) {
      case 'inventario':
        return {
          metrics: [
            { title: 'Total de Productos', value: '3,245', subtitle: 'En inventario', change: '+5.2%', icon: 'ri-archive-line', color: 'bg-blue-500' },
            { title: 'Valor Total', value: '$348,750', subtitle: 'Costo del inventario', change: '+12.8%', icon: 'ri-money-dollar-circle-line', color: 'bg-green-500' },
            { title: 'Stock Bajo', value: '23', subtitle: 'Requieren reposición', change: '-8.1%', icon: 'ri-alert-line', color: 'bg-red-500' },
            { title: 'Próximos a Vencer', value: '18', subtitle: 'En 30 días', change: '+3.4%', icon: 'ri-time-line', color: 'bg-orange-500' }
          ],
          chartTitle: 'Distribución de Stock por Categoría',
          tableTitle: 'Estado Actual del Inventario'
        };
      case 'movimientos':
        return {
          metrics: [
            { title: 'Entradas', value: '156', subtitle: 'Este mes', change: '+18.5%', icon: 'ri-arrow-down-line', color: 'bg-green-500' },
            { title: 'Salidas', value: '89', subtitle: 'Este mes', change: '-5.2%', icon: 'ri-arrow-up-line', color: 'bg-red-500' },
            { title: 'Transferencias', value: '34', subtitle: 'Entre almacenes', change: '+12.1%', icon: 'ri-exchange-line', color: 'bg-purple-500' },
            { title: 'Ajustes', value: '7', subtitle: 'Correcciones', change: '-15.3%', icon: 'ri-settings-line', color: 'bg-orange-500' }
          ],
          chartTitle: 'Movimientos de Stock por Mes',
          tableTitle: 'Últimos Movimientos'
        };
      case 'financiero':
        return {
          metrics: [
            { title: 'Costo Total', value: '$248,500', subtitle: 'Valor del inventario', change: '+8.7%', icon: 'ri-money-dollar-circle-line', color: 'bg-green-500' },
            { title: 'Costo Promedio', value: '$76.52', subtitle: 'Por producto', change: '+3.2%', icon: 'ri-calculator-line', color: 'bg-blue-500' },
            { title: 'Rotación', value: '4.2x', subtitle: 'Veces por año', change: '+15.8%', icon: 'ri-refresh-line', color: 'bg-purple-500' },
            { title: 'Días de Stock', value: '87', subtitle: 'Días promedio', change: '-12.5%', icon: 'ri-calendar-line', color: 'bg-orange-500' }
          ],
          chartTitle: 'Análisis Financiero por Categoría',
          tableTitle: 'Métricas Financieras'
        };
      default:
        return {
          metrics: [
            { title: 'Ventas Totales', value: '$67,241', subtitle: '+12.5% vs mes anterior', change: '+12.5%', icon: 'ri-money-dollar-circle-line', color: 'bg-blue-500' },
            { title: 'Productos Vendidos', value: '1,234', subtitle: '+8.2% vs mes anterior', change: '+8.2%', icon: 'ri-shopping-cart-line', color: 'bg-green-500' },
            { title: 'Ticket Promedio', value: '$54.48', subtitle: '+3.1% vs mes anterior', change: '+3.1%', icon: 'ri-receipt-line', color: 'bg-purple-500' },
            { title: 'Margen Bruto', value: '32.5%', subtitle: '+1.8% vs mes anterior', change: '+1.8%', icon: 'ri-percent-line', color: 'bg-orange-500' }
          ],
          chartTitle: 'Tendencia de Ventas',
          tableTitle: 'Productos Más Vendidos'
        };
    }
  };

  const tabData = getTabData();

  const MetricCard = ({ title, value, subtitle, change, icon, color }: any) => (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
      <div className="flex items-start justify-between mb-4">
        <div className={`w-12 h-12 ${color} rounded-lg flex items-center justify-center`}>
          <i className={`${icon} text-white text-xl`}></i>
        </div>
        <div className={`flex items-center space-x-1 text-sm ${
          change.startsWith('+') ? 'text-green-600' : 'text-red-600'
        }`}>
          <i className={`${change.startsWith('+') ? 'ri-arrow-up-line' : 'ri-arrow-down-line'}`}></i>
          <span>{change}</span>
        </div>
      </div>
      <h3 className="text-sm font-medium text-gray-600 mb-1">{title}</h3>
      <p className="text-2xl font-bold text-gray-900 mb-1">{value}</p>
      <p className="text-sm text-gray-500">{subtitle}</p>
    </div>
  );

  const LineChart = ({ data, title }: any) => {
    const maxValue = Math.max(...data.map((d: any) => d.value));
    
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>
        <div className="relative h-64">
          <div className="absolute inset-0 flex items-end justify-between px-4 pb-8">
            {data.map((item: any, index: number) => (
              <div key={index} className="flex flex-col items-center space-y-2">
                <div 
                  className="bg-blue-500 rounded-t-lg w-12 transition-all duration-300 hover:bg-blue-600"
                  style={{ height: `${(item.value / maxValue) * 180}px` }}
                ></div>
                <span className="text-sm text-gray-600 font-medium">{item.month}</span>
              </div>
            ))}
          </div>
          <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-gray-500">
            <span>{maxValue}</span>
            <span>{Math.round(maxValue * 0.75)}</span>
            <span>{Math.round(maxValue * 0.5)}</span>
            <span>{Math.round(maxValue * 0.25)}</span>
            <span>0</span>
          </div>
        </div>
      </div>
    );
  };

  const PieChart = ({ data, title }: any) => {
    const total = data.reduce((sum: number, item: any) => sum + item.value, 0);
    let cumulativePercentage = 0;

    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>
        <div className="flex items-center justify-center">
          <div className="relative w-48 h-48">
            <div className="w-full h-full rounded-full bg-gray-200 relative overflow-hidden">
              {data.map((item: any, index: number) => {
                const percentage = (item.value / total) * 100;
                const rotation = (cumulativePercentage / 100) * 360;
                cumulativePercentage += percentage;
                
                return (
                  <div
                    key={index}
                    className={`absolute inset-0 ${item.color} rounded-full`}
                    style={{
                      clipPath: `polygon(50% 50%, 50% 0%, ${
                        50 + 50 * Math.cos((rotation * Math.PI) / 180)
                      }% ${50 + 50 * Math.sin((rotation * Math.PI) / 180)}%, ${
                        50 + 50 * Math.cos(((rotation + (percentage / 100) * 360) * Math.PI) / 180)
                      }% ${50 + 50 * Math.sin(((rotation + (percentage / 100) * 360) * Math.PI) / 180)}%)`
                    }}
                  ></div>
                );
              })}
            </div>
          </div>
        </div>
        <div className="mt-6 space-y-3">
          {data.map((item: any, index: number) => (
            <div key={index} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-4 h-4 ${item.color} rounded`}></div>
                <span className="text-sm font-medium text-gray-700">{item.name}</span>
              </div>
              <span className="text-sm font-semibold text-gray-900">{item.value}%</span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderTabContent = () => {
    switch (selectedTab) {
      case 'inventario':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-6 border-b border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900">Productos por Categoría</h3>
                <p className="text-sm text-gray-600">Estado actual del inventario</p>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {[
                    { category: 'Medicamentos', stock: 1245, value: '$156,800', status: 'normal' },
                    { category: 'Material Médico', stock: 856, value: '$89,200', status: 'normal' },
                    { category: 'EPP', stock: 432, value: '$52,300', status: 'bajo' },
                    { category: 'Equipos', stock: 178, value: '$34,750', status: 'normal' }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h4 className="font-medium text-gray-900">{item.category}</h4>
                        <p className="text-sm text-gray-600">{item.stock} productos</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-gray-900">{item.value}</p>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          item.status === 'normal' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {item.status === 'normal' ? 'Normal' : 'Bajo Stock'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-6 border-b border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900">Alertas de Inventario</h3>
                <p className="text-sm text-gray-600">Productos que requieren atención</p>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {[
                    { name: 'Mascarillas N95', type: 'Stock Bajo', level: 'crítico', action: 'Reabastecer' },
                    { name: 'Vacuna COVID-19', type: 'Próximo a Vencer', level: 'advertencia', action: 'Usar Pronto' },
                    { name: 'Termómetros Digitales', type: 'Stock Bajo', level: 'crítico', action: 'Ordenar' },
                    { name: 'Suero Fisiológico', type: 'Próximo a Vencer', level: 'normal', action: 'Monitorear' }
                  ].map((alert, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h4 className="font-medium text-gray-900">{alert.name}</h4>
                        <p className="text-sm text-gray-600">{alert.type}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          alert.level === 'crítico' ? 'bg-red-100 text-red-700' :
                          alert.level === 'advertencia' ? 'bg-yellow-100 text-yellow-700' :
                          'bg-green-100 text-green-700'
                        }`}>
                          {alert.action}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );

      case 'movimientos':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-6 border-b border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900">Últimos Movimientos</h3>
                <p className="text-sm text-gray-600">Transacciones recientes de inventario</p>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {[
                    { product: 'Acetaminofén 500mg', type: 'Entrada', quantity: '+150', date: '2024-01-15', user: 'María González' },
                    { product: 'Jeringa 10ml', type: 'Salida', quantity: '-85', date: '2024-01-14', user: 'Carlos Ruiz' },
                    { product: 'Alcohol Etílico 70%', type: 'Transferencia', quantity: '50', date: '2024-01-14', user: 'Ana López' },
                    { product: 'Guantes Latex M', type: 'Ajuste', quantity: '+5', date: '2024-01-13', user: 'Sistema' }
                  ].map((movement, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{movement.product}</h4>
                        <p className="text-sm text-gray-600">{movement.date} - {movement.user}</p>
                      </div>
                      <div className="text-right">
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                          movement.type === 'Entrada' ? 'bg-green-100 text-green-700' :
                          movement.type === 'Salida' ? 'bg-red-100 text-red-700' :
                          movement.type === 'Transferencia' ? 'bg-blue-100 text-blue-700' :
                          'bg-gray-100 text-gray-700'
                        }`}>
                          {movement.type}
                        </span>
                        <p className="text-sm font-semibold text-gray-900 mt-1">{movement.quantity}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-6 border-b border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900">Resumen de Movimientos</h3>
                <p className="text-sm text-gray-600">Estadísticas del período seleccionado</p>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                        <i className="ri-arrow-down-line text-white"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">Entradas</h4>
                        <p className="text-sm text-gray-600">156 movimientos</p>
                      </div>
                    </div>
                    <span className="text-lg font-bold text-green-600">2,450 unidades</span>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-red-500 rounded-lg flex items-center justify-center">
                        <i className="ri-arrow-up-line text-white"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">Salidas</h4>
                        <p className="text-sm text-gray-600">89 movimientos</p>
                      </div>
                    </div>
                    <span className="text-lg font-bold text-red-600">1,678 unidades</span>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                        <i className="ri-exchange-line text-white"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">Transferencias</h4>
                        <p className="text-sm text-gray-600">34 movimientos</p>
                      </div>
                    </div>
                    <span className="text-lg font-bold text-blue-600">567 unidades</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'financiero':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-6 border-b border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900">Análisis de Costos</h3>
                <p className="text-sm text-gray-600">Distribución financiera por categoría</p>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {[
                    { category: 'Medicamentos', cost: '$156,800', percentage: '45%', trend: '+8.2%' },
                    { category: 'Material Médico', cost: '$89,200', percentage: '26%', trend: '+5.1%' },
                    { category: 'EPP', cost: '$52,300', percentage: '15%', trend: '+12.5%' },
                    { category: 'Equipos', cost: '$34,750', percentage: '10%', trend: '+3.8%' },
                    { category: 'Otros', cost: '$15,700', percentage: '4%', trend: '-2.1%' }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className={`w-4 h-4 rounded ${
                          index === 0 ? 'bg-blue-500' :
                          index === 1 ? 'bg-green-500' :
                          index === 2 ? 'bg-yellow-500' :
                          index === 3 ? 'bg-purple-500' : 'bg-red-500'
                        }`}></div>
                        <div>
                          <h4 className="font-medium text-gray-900">{item.category}</h4>
                          <p className="text-sm text-gray-600">{item.percentage} del total</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-gray-900">{item.cost}</p>
                        <span className={`text-sm ${
                          item.trend.startsWith('+') ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {item.trend}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-6 border-b border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900">Métricas de Rentabilidad</h3>
                <p className="text-sm text-gray-600">Indicadores financieros clave</p>
              </div>
              <div className="p-6">
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gray-900 mb-2">4.2x</div>
                    <div className="text-sm text-gray-600 mb-1">Rotación de Inventario</div>
                    <div className="text-sm text-green-600">+15.8% vs período anterior</div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <div className="text-xl font-bold text-blue-600">87</div>
                      <div className="text-sm text-gray-600">Días de Stock</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="text-xl font-bold text-green-600">$76.52</div>
                      <div className="text-sm text-gray-600">Costo Promedio</div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Margen Bruto</span>
                      <span className="text-sm font-semibold text-gray-900">32.5%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">ROI Inventario</span>
                      <span className="text-sm font-semibold text-gray-900">18.7%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Productos Activos</span>
                      <span className="text-sm font-semibold text-gray-900">2,847</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <LineChart data={salesData} title={tabData.chartTitle} />
            <PieChart data={categoryData} title="Ventas por Categoría" />
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Navigation */}
      <header className="bg-slate-700 shadow-sm">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <i className="ri-archive-line text-white text-lg"></i>
                </div>
                <h1 className="text-xl font-bold text-white">Sistema de Inventarios</h1>
              </div>
              
              {/* Navigation Menu */}
              <nav className="hidden lg:flex items-center space-x-8">
                <button 
                  onClick={() => navigate('/dashboard')}
                  className="text-blue-200 hover:text-white font-medium transition-colors"
                >
                  Dashboard
                </button>
                <button className="text-blue-200 hover:text-white font-medium transition-colors">
                  Productos
                </button>
                <button className="text-blue-200 hover:text-white font-medium transition-colors">
                  Inventario
                </button>
                <button className="text-white bg-blue-600 px-3 py-1 rounded-md font-medium">
                  Reportes
                </button>
                <button className="text-blue-200 hover:text-white font-medium transition-colors">
                  Configuración
                </button>
              </nav>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <button className="p-2 text-white hover:text-blue-200 relative">
                  <i className="ri-notification-3-line text-xl"></i>
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center">3</span>
                </button>
              </div>
              
              <div className="flex items-center space-x-3">
                <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                <div className="text-sm">
                  <p className="font-medium text-white">{user.name}</p>
                  <p className="text-blue-200">{user.role}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-6 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Reportes y Análisis</h2>
          <p className="text-gray-600">Visualiza el rendimiento de tu inventario con reportes detallados</p>
        </div>

        {/* Tabs */}
        <div className="mb-8">
          <div className="flex items-center space-x-1 bg-gray-100 p-1 rounded-lg w-fit">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-md font-medium transition-colors whitespace-nowrap ${
                  selectedTab === tab.id
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <i className={`${tab.icon} text-lg`}></i>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium text-gray-700">Período:</label>
              <select 
                value={dateRange} 
                onChange={(e) => setDateRange(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8"
              >
                <option value="7d">Últimos 7 días</option>
                <option value="30d">Últimos 30 días</option>
                <option value="6m">Últimos 6 meses</option>
                <option value="1y">Último año</option>
              </select>
            </div>
          </div>
          
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap">
            <i className="ri-download-line"></i>
            <span>Exportar PDF</span>
          </button>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {tabData.metrics.map((metric, index) => (
            <MetricCard key={index} {...metric} />
          ))}
        </div>

        {/* Tab Content */}
        {renderTabContent()}

        {/* Additional Tables for Sales Tab */}
        {selectedTab === 'ventas' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
            {/* Top Products */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-6 border-b border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900">Productos Más Vendidos</h3>
                <p className="text-sm text-gray-600">Top 5 productos por ventas</p>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {[
                    { name: 'Acetaminofén 500mg', sales: '$8,450', units: '845', growth: '+15%' },
                    { name: 'Jeringa 10ml', sales: '$6,780', units: '678', growth: '+12%' },
                    { name: 'Alcohol Etílico 70%', sales: '$5,230', units: '523', growth: '+8%' },
                    { name: 'Guantes Latex M', sales: '$4,890', units: '489', growth: '+5%' },
                    { name: 'Vendas Elásticas', sales: '$3,670', units: '367', growth: '+3%' }
                  ].map((product, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                          <span className="text-sm font-bold text-blue-600">{index + 1}</span>
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">{product.name}</h4>
                          <p className="text-sm text-gray-600">{product.units} unidades</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-gray-900">{product.sales}</p>
                        <p className="text-sm text-green-600">{product.growth}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Inventory Status */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-6 border-b border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900">Estado del Inventario</h3>
                <p className="text-sm text-gray-600">Resumen de stock actual</p>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {[
                    { category: 'Medicamentos', total: 1245, low: 23, critical: 5, color: 'bg-blue-500' },
                    { category: 'Material Médico', total: 856, low: 12, critical: 2, color: 'bg-green-500' },
                    { category: 'EPP', total: 432, low: 8, critical: 3, color: 'bg-orange-500' },
                    { category: 'Equipos', total: 178, low: 4, critical: 1, color: 'bg-purple-500' }
                  ].map((item, index) => (
                    <div key={index} className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className={`w-4 h-4 ${item.color} rounded`}></div>
                          <h4 className="font-medium text-gray-900">{item.category}</h4>
                        </div>
                        <span className="text-sm font-semibold text-gray-900">{item.total} productos</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-yellow-600">Stock bajo: {item.low}</span>
                        <span className="text-red-600">Crítico: {item.critical}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}