
import type { RouteObject } from "react-router-dom";
import NotFound from "../pages/NotFound";
import Home from "../pages/home/page";
import Dashboard from "../pages/dashboard/page";
import Requerimientos from "../pages/requerimientos/page";
import OrdenesCompra from "../pages/ordenes-compra/page";

const routes: RouteObject[] = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/dashboard",
    element: <Dashboard />,
  },
  {
    path: "/requerimientos",
    element: <Requerimientos />,
  },
  {
    path: "/ordenes-compra",
    element: <OrdenesCompra />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
];

export default routes;
