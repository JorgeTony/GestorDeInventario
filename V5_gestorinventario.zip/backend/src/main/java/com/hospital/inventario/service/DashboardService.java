
package com.hospital.inventario.service;

import com.hospital.inventario.model.Notificacion;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class DashboardService {
    
    public Map<String, Object> getProductosEnStock() {
        Map<String, Object> data = new HashMap<>();
        data.put("value", "2,847");
        data.put("change", "+12%");
        data.put("trend", "up");
        return data;
    }
    
    public Map<String, Object> getOrdenesPendientes() {
        Map<String, Object> data = new HashMap<>();
        data.put("value", "23");
        data.put("change", "-5%");
        data.put("trend", "down");
        return data;
    }
    
    public Map<String, Object> getValorTotalInventario() {
        Map<String, Object> data = new HashMap<>();
        data.put("value", "$248,500");
        data.put("change", "+8%");
        data.put("trend", "up");
        return data;
    }
    
    public Map<String, Object> getProductosCriticos() {
        Map<String, Object> data = new HashMap<>();
        data.put("value", "15");
        data.put("change", "0%");
        data.put("trend", "neutral");
        return data;
    }
    
    public List<Notificacion> getNotificaciones() {
        List<Notificacion> notificaciones = new ArrayList<>();
        
        Notificacion notif1 = new Notificacion("Stock Bajo", 
            "Mascarillas N95 requieren reposición urgente", 
            Notificacion.TipoNotificacion.WARNING);
        notif1.setLeida(false);
        notif1.setFechaCreacion(LocalDateTime.now().minusMinutes(5));
        
        Notificacion notif2 = new Notificacion("Producto Vencido", 
            "Vacuna COVID-19 próxima a vencer", 
            Notificacion.TipoNotificacion.ERROR);
        notif2.setLeida(false);
        notif2.setFechaCreacion(LocalDateTime.now().minusMinutes(15));
        
        Notificacion notif3 = new Notificacion("Orden Completada", 
            "Orden de compra OC-2024-001 recibida", 
            Notificacion.TipoNotificacion.SUCCESS);
        notif3.setLeida(true);
        notif3.setFechaCreacion(LocalDateTime.now().minusHours(1));
        
        notificaciones.add(notif1);
        notificaciones.add(notif2);
        notificaciones.add(notif3);
        
        return notificaciones;
    }
    
    public List<Map<String, Object>> getModulosSistema() {
        List<Map<String, Object>> modulos = new ArrayList<>();
        
        modulos.add(createModulo("ordenes-compra", "Órdenes de compra", "ri-file-list-3-line", 
            "Gestión de órdenes de compra y proveedores", "bg-blue-50 hover:bg-blue-100", "text-blue-600"));
        modulos.add(createModulo("almacenes", "Almacenes", "ri-building-2-line", 
            "Control de almacenes y ubicaciones", "bg-green-50 hover:bg-green-100", "text-green-600"));
        modulos.add(createModulo("transacciones", "Transacciones", "ri-exchange-line", 
            "Registro de movimientos y transacciones", "bg-purple-50 hover:bg-purple-100", "text-purple-600"));
        modulos.add(createModulo("kardex", "Kardex", "ri-bar-chart-box-line", 
            "Historial detallado de movimientos", "bg-orange-50 hover:bg-orange-100", "text-orange-600"));
        modulos.add(createModulo("dashboard", "Dashboard", "ri-dashboard-3-line", 
            "Panel de control y métricas", "bg-indigo-50 hover:bg-indigo-100", "text-indigo-600"));
        modulos.add(createModulo("inventarios", "Inventarios", "ri-archive-line", 
            "Control de stock y productos", "bg-teal-50 hover:bg-teal-100", "text-teal-600"));
        modulos.add(createModulo("requerimientos", "Requerimientos", "ri-task-line", 
            "Solicitudes de productos por área", "bg-red-50 hover:bg-red-100", "text-red-600"));
        modulos.add(createModulo("catalogo-productos", "Catálogo de productos", "ri-book-open-line", 
            "Gestión del catálogo de productos", "bg-yellow-50 hover:bg-yellow-100", "text-yellow-600"));
        modulos.add(createModulo("linea-producto", "Línea y familia del producto", "ri-node-tree", 
            "Organización por líneas y familias", "bg-pink-50 hover:bg-pink-100", "text-pink-600"));
        
        return modulos;
    }
    
    private Map<String, Object> createModulo(String id, String title, String icon, String description, String color, String iconColor) {
        Map<String, Object> modulo = new HashMap<>();
        modulo.put("id", id);
        modulo.put("title", title);
        modulo.put("icon", icon);
        modulo.put("description", description);
        modulo.put("color", color);
        modulo.put("iconColor", iconColor);
        return modulo;
    }
    
    public List<Map<String, Object>> getAccionesRapidas() {
        List<Map<String, Object>> acciones = new ArrayList<>();
        
        acciones.add(createAccion("ri-add-line", "text-blue-600", "bg-blue-50 hover:bg-blue-100", 
            "text-blue-700", "Nuevo Requerimiento"));
        acciones.add(createAccion("ri-shopping-cart-line", "text-green-600", "bg-green-50 hover:bg-green-100", 
            "text-green-700", "Crear Orden de Compra"));
        acciones.add(createAccion("ri-truck-line", "text-purple-600", "bg-purple-50 hover:bg-purple-100", 
            "text-purple-700", "Registrar Recepción"));
        acciones.add(createAccion("ri-file-chart-line", "text-orange-600", "bg-orange-50 hover:bg-orange-100", 
            "text-orange-700", "Generar Reporte"));
        
        return acciones;
    }
    
    private Map<String, Object> createAccion(String icon, String iconColor, String bgColor, String textColor, String text) {
        Map<String, Object> accion = new HashMap<>();
        accion.put("icon", icon);
        accion.put("iconColor", iconColor);
        accion.put("bgColor", bgColor);
        accion.put("textColor", textColor);
        accion.put("text", text);
        return accion;
    }
    
    // Métodos para Dashboard
    public List<Map<String, Object>> getMetricasDashboard() {
        List<Map<String, Object>> metricas = new ArrayList<>();
        
        metricas.add(createMetrica("Stock Total vs Costo", "$348,750", "3,245 productos", 
            "+15.2%", "up", "ri-money-dollar-circle-line", "text-green-600", "bg-green-50"));
        metricas.add(createMetrica("Productos de Mayor Rotación", "127", "productos activos", 
            "+8.4%", "up", "ri-refresh-line", "text-blue-600", "bg-blue-50"));
        metricas.add(createMetrica("Próximos a Vencer", "23", "en 30 días", 
            "-12.3%", "down", "ri-time-line", "text-orange-600", "bg-orange-50"));
        metricas.add(createMetrica("Stock Bajo", "18", "productos críticos", 
            "+5.1%", "up", "ri-alert-line", "text-red-600", "bg-red-50"));
        
        return metricas;
    }
    
    private Map<String, Object> createMetrica(String title, String value, String items, String change, 
                                            String trend, String icon, String color, String bgColor) {
        Map<String, Object> metrica = new HashMap<>();
        metrica.put("title", title);
        metrica.put("value", value);
        metrica.put("items", items);
        metrica.put("change", change);
        metrica.put("trend", trend);
        metrica.put("icon", icon);
        metrica.put("color", color);
        metrica.put("bgColor", bgColor);
        return metrica;
    }
    
    public List<Map<String, Object>> getProductosMayorRotacion() {
        List<Map<String, Object>> productos = new ArrayList<>();
        
        productos.add(createProductoRotacion("Acetaminofén 500mg", "Medicamentos", 450, "Alta", "normal"));
        productos.add(createProductoRotacion("Jeringa 10ml", "Material Médico", 1200, "Alta", "normal"));
        productos.add(createProductoRotacion("Guantes Latex Talla M", "EPP", 85, "Media", "bajo"));
        productos.add(createProductoRotacion("Alcohol Etílico 70%", "Antisépticos", 320, "Alta", "normal"));
        productos.add(createProductoRotacion("Vendas Elásticas 10cm", "Material Médico", 156, "Media", "normal"));
        
        return productos;
    }
    
    private Map<String, Object> createProductoRotacion(String name, String category, int stock, String rotation, String status) {
        Map<String, Object> producto = new HashMap<>();
        producto.put("name", name);
        producto.put("category", category);
        producto.put("stock", stock);
        producto.put("rotation", rotation);
        producto.put("status", status);
        return producto;
    }
    
    public List<Map<String, Object>> getProductosProximosVencer() {
        List<Map<String, Object>> productos = new ArrayList<>();
        
        productos.add(createProductoVencer("Vacuna COVID-19", "CV2024-001", "2024-02-15", 8, "crítico"));
        productos.add(createProductoVencer("Suero Fisiológico 500ml", "SF2024-045", "2024-02-28", 21, "advertencia"));
        productos.add(createProductoVencer("Ibuprofeno 400mg", "IB2024-023", "2024-03-10", 31, "advertencia"));
        productos.add(createProductoVencer("Vitamina C 1000mg", "VC2024-012", "2024-03-15", 36, "normal"));
        
        return productos;
    }
    
    private Map<String, Object> createProductoVencer(String name, String batch, String expiry, int days, String status) {
        Map<String, Object> producto = new HashMap<>();
        producto.put("name", name);
        producto.put("batch", batch);
        producto.put("expiry", expiry);
        producto.put("days", days);
        producto.put("status", status);
        return producto;
    }
    
    public List<Map<String, Object>> getProductosBajoStock() {
        List<Map<String, Object>> productos = new ArrayList<>();
        
        productos.add(createProductoBajoStock("Mascarillas N95", 12, 50, "EPP", "alta"));
        productos.add(createProductoBajoStock("Termómetros Digitales", 3, 10, "Equipos", "alta"));
        productos.add(createProductoBajoStock("Alcohol en Gel 250ml", 25, 100, "Antisépticos", "media"));
        productos.add(createProductoBajoStock("Gasas Estériles 10x10", 78, 200, "Material Médico", "media"));
        
        return productos;
    }
    
    private Map<String, Object> createProductoBajoStock(String name, int current, int minimum, String category, String urgency) {
        Map<String, Object> producto = new HashMap<>();
        producto.put("name", name);
        producto.put("current", current);
        producto.put("minimum", minimum);
        producto.put("category", category);
        producto.put("urgency", urgency);
        return producto;
    }
    
    public List<Map<String, Object>> getAnalisisCostosPorCategoria() {
        List<Map<String, Object>> categorias = new ArrayList<>();
        
        categorias.add(createCategoriaCosto("Medicamentos", 156800, "45%", "bg-blue-500"));
        categorias.add(createCategoriaCosto("Material Médico", 89200, "26%", "bg-green-500"));
        categorias.add(createCategoriaCosto("EPP", 52300, "15%", "bg-yellow-500"));
        categorias.add(createCategoriaCosto("Equipos", 34750, "10%", "bg-purple-500"));
        categorias.add(createCategoriaCosto("Otros", 15700, "4%", "bg-red-500"));
        
        return categorias;
    }
    
    private Map<String, Object> createCategoriaCosto(String name, int value, String percentage, String color) {
        Map<String, Object> categoria = new HashMap<>();
        categoria.put("name", name);
        categoria.put("value", value);
        categoria.put("percentage", percentage);
        categoria.put("color", color);
        return categoria;
    }
}
