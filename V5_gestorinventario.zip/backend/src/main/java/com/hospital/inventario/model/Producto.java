
package com.hospital.inventario.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "productos")
public class Producto {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String nombre;
    
    @Column(unique = true, nullable = false)
    private String codigo;
    
    @Column(nullable = false)
    private String categoria;
    
    @Column(nullable = false)
    private Integer stockActual;
    
    @Column(nullable = false)
    private Integer stockMinimo;
    
    @Column(nullable = false)
    private Integer stockMaximo;
    
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal precioUnitario;
    
    private LocalDate fechaVencimiento;
    
    private String proveedor;
    
    private String imagen;
    
    @Enumerated(EnumType.STRING)
    private EstadoStock estado;
    
    public enum EstadoStock {
        NORMAL, BAJO, CRITICO
    }
    
    // Constructores
    public Producto() {}
    
    public Producto(String nombre, String codigo, String categoria, Integer stockActual, 
                   Integer stockMinimo, BigDecimal precioUnitario) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.categoria = categoria;
        this.stockActual = stockActual;
        this.stockMinimo = stockMinimo;
        this.precioUnitario = precioUnitario;
        this.estado = determinarEstado();
    }
    
    // Método para determinar el estado del stock
    public EstadoStock determinarEstado() {
        if (stockActual <= stockMinimo * 0.5) {
            return EstadoStock.CRITICO;
        } else if (stockActual <= stockMinimo) {
            return EstadoStock.BAJO;
        } else {
            return EstadoStock.NORMAL;
        }
    }
    
    // Getters y Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getCodigo() {
        return codigo;
    }
    
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    
    public String getCategoria() {
        return categoria;
    }
    
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
    public Integer getStockActual() {
        return stockActual;
    }
    
    public void setStockActual(Integer stockActual) {
        this.stockActual = stockActual;
        this.estado = determinarEstado();
    }
    
    public Integer getStockMinimo() {
        return stockMinimo;
    }
    
    public void setStockMinimo(Integer stockMinimo) {
        this.stockMinimo = stockMinimo;
        this.estado = determinarEstado();
    }
    
    public Integer getStockMaximo() {
        return stockMaximo;
    }
    
    public void setStockMaximo(Integer stockMaximo) {
        this.stockMaximo = stockMaximo;
    }
    
    public BigDecimal getPrecioUnitario() {
        return precioUnitario;
    }
    
    public void setPrecioUnitario(BigDecimal precioUnitario) {
        this.precioUnitario = precioUnitario;
    }
    
    public LocalDate getFechaVencimiento() {
        return fechaVencimiento;
    }
    
    public void setFechaVencimiento(LocalDate fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }
    
    public String getProveedor() {
        return proveedor;
    }
    
    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }
    
    public String getImagen() {
        return imagen;
    }
    
    public void setImagen(String imagen) {
        this.imagen = imagen;
    }
    
    public EstadoStock getEstado() {
        return estado;
    }
    
    public void setEstado(EstadoStock estado) {
        this.estado = estado;
    }
    
    // Método para calcular valor total
    public BigDecimal getValorTotal() {
        return precioUnitario.multiply(BigDecimal.valueOf(stockActual));
    }
}
