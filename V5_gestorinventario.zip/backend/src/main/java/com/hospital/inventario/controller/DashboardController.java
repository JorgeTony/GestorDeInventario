
package com.hospital.inventario.controller;

import com.hospital.inventario.model.Usuario;
import com.hospital.inventario.service.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/dashboard")
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;

    @GetMapping
    public String dashboard(Model model) {
        // Datos del usuario
        Usuario usuario = new Usuario();
        usuario.setNombre("María González");
        usuario.setRol("Administrador de Inventario");
        usuario.setAvatar("https://readdy.ai/api/search-image?query=professional%20woman%20administrator%20inventory%20management%20office%20corporate%20headshot%20clean%20background%20business%20attire%20confident%20smile%20latina&width=40&height=40&seq=1&orientation=squarish");
        
        model.addAttribute("usuario", usuario);
        model.addAttribute("notificaciones", dashboardService.getNotificaciones());
        model.addAttribute("metricas", dashboardService.getMetricasDashboard());
        model.addAttribute("productosRotacion", dashboardService.getProductosMayorRotacion());
        model.addAttribute("productosVencer", dashboardService.getProductosProximosVencer());
        model.addAttribute("productosBajoStock", dashboardService.getProductosBajoStock());
        model.addAttribute("analisisCostos", dashboardService.getAnalisisCostosPorCategoria());
        
        return "dashboard";
    }
}
