
package com.hospital.inventario.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "notificaciones")
public class Notificacion {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String titulo;
    
    @Column(nullable = false, length = 500)
    private String mensaje;
    
    @Column(nullable = false)
    private LocalDateTime fechaCreacion;
    
    @Enumerated(EnumType.STRING)
    private TipoNotificacion tipo;
    
    @Column(nullable = false)
    private Boolean leida = false;
    
    public enum TipoNotificacion {
        WARNING, ERROR, SUCCESS, INFO
    }
    
    // Constructores
    public Notificacion() {
        this.fechaCreacion = LocalDateTime.now();
    }
    
    public Notificacion(String titulo, String mensaje, TipoNotificacion tipo) {
        this();
        this.titulo = titulo;
        this.mensaje = mensaje;
        this.tipo = tipo;
    }
    
    // Getters y Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getTitulo() {
        return titulo;
    }
    
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    public String getMensaje() {
        return mensaje;
    }
    
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }
    
    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }
    
    public TipoNotificacion getTipo() {
        return tipo;
    }
    
    public void setTipo(TipoNotificacion tipo) {
        this.tipo = tipo;
    }
    
    public Boolean getLeida() {
        return leida;
    }
    
    public void setLeida(Boolean leida) {
        this.leida = leida;
    }
    
    // Método para obtener el tiempo transcurrido
    public String getTiempoTranscurrido() {
        LocalDateTime ahora = LocalDateTime.now();
        long minutos = java.time.Duration.between(fechaCreacion, ahora).toMinutes();
        
        if (minutos < 60) {
            return "Hace " + minutos + " min";
        } else if (minutos < 1440) {
            return "Hace " + (minutos / 60) + " hora" + (minutos / 60 > 1 ? "s" : "");
        } else {
            return "Hace " + (minutos / 1440) + " día" + (minutos / 1440 > 1 ? "s" : "");
        }
    }
}
