
# Sistema de Inventarios - Backend Spring Boot

Este proyecto implementa el backend del Sistema de Inventarios utilizando Spring Boot, siguiendo los principios del **Capítulo 2: Implementación del back-end estático con Spring**.

## 🏗️ Arquitectura del Proyecto

### Configuración del Entorno

El proyecto está configurado con:
- **Spring Boot 3.2.0**
- **Java 17**
- **Maven** como gestor de dependencias
- **H2 Database** (base de datos en memoria para desarrollo)
- **Thymeleaf** como motor de plantillas
- **Spring Data JPA** para persistencia

### Estructura del Proyecto

```
backend/
├── src/main/java/com/hospital/inventario/
│   ├── InventarioBackendApplication.java    # Clase principal
│   ├── controller/                          # Controladores REST
│   │   ├── HomeController.java             # Controlador página principal
│   │   └── DashboardController.java        # Controlador dashboard
│   ├── model/                              # Entidades del dominio
│   │   ├── Usuario.java                    # Modelo de usuario
│   │   ├── Producto.java                   # Modelo de producto
│   │   └── Notificacion.java              # Modelo de notificación
│   └── service/                            # Servicios de negocio
│       └── DashboardService.java           # Servicio del dashboard
├── src/main/resources/
│   ├── templates/                          # Plantillas Thymeleaf
│   │   ├── home.html                       # Página principal
│   │   └── dashboard.html                  # Dashboard
│   └── application.properties              # Configuración
└── pom.xml                                 # Dependencias Maven
```

## 🚀 Funcionalidades Implementadas

### Controladores y Vistas

#### HomeController (`/`)
- **Función**: Maneja la página principal del sistema
- **Vista**: `home.html` - Renderiza la interfaz estática del frontend React
- **Datos**: Proporciona información del usuario, estadísticas y módulos del sistema

#### DashboardController (`/dashboard`)
- **Función**: Gestiona el panel de control
- **Vista**: `dashboard.html` - Muestra métricas y análisis del inventario
- **Datos**: Métricas, productos de rotación, alertas de vencimiento y stock bajo

### Modelos de Datos

#### Usuario
```java
@Entity
public class Usuario {
    private Long id;
    private String nombre;
    private String rol;
    private String avatar;
    private String email;
}
```

#### Producto
```java
@Entity
public class Producto {
    private Long id;
    private String nombre;
    private String codigo;
    private String categoria;
    private Integer stockActual;
    private Integer stockMinimo;
    private BigDecimal precioUnitario;
    private LocalDate fechaVencimiento;
    private EstadoStock estado;
}
```

#### Notificación
```java
@Entity
public class Notificacion {
    private Long id;
    private String titulo;
    private String mensaje;
    private LocalDateTime fechaCreacion;
    private TipoNotificacion tipo;
    private Boolean leida;
}
```

### Integración con Thymeleaf

Las plantillas Thymeleaf mantienen **exactamente el mismo diseño visual** del frontend React, pero ahora son servidas desde el backend Spring Boot:

- **Sintaxis Thymeleaf**: `th:text`, `th:each`, `th:class`, `th:if`
- **Datos dinámicos**: Los controladores inyectan datos reales en las vistas
- **Interactividad**: JavaScript mantiene la funcionalidad del menú móvil y notificaciones
- **Estilos**: TailwindCSS y RemixIcon preservan el diseño original

## 🛠️ Configuración y Ejecución

### Prerrequisitos
- Java 17 o superior
- Maven 3.6 o superior

### Instalación

1. **Clonar el repositorio**:
```bash
git clone <repository-url>
cd backend
```

2. **Compilar el proyecto**:
```bash
mvn clean compile
```

3. **Ejecutar la aplicación**:
```bash
mvn spring-boot:run
```

4. **Acceder a la aplicación**:
- Aplicación: http://localhost:8080
- H2 Console: http://localhost:8080/h2-console

### Configuración de Base de Datos

La aplicación utiliza H2 en memoria por defecto. Para conectar a una base de datos persistente, modificar `application.properties`:

```properties
# Para MySQL
spring.datasource.url=jdbc:mysql://localhost:3306/inventario
spring.datasource.username=usuario
spring.datasource.password=contraseña
spring.jpa.hibernate.ddl-auto=update
```

## 🔄 Integración Frontend-Backend

### Migración de React a Thymeleaf

El proceso de migración mantiene:

1. **Diseño Visual**: Clases CSS, estructura HTML y componentes visuales idénticos
2. **Funcionalidad**: JavaScript para interacciones del lado cliente
3. **Datos Dinámicos**: Reemplaza datos estáticos con datos del backend
4. **Navegación**: URLs mapeadas a controladores Spring

### Ventajas de la Integración

- **Renderizado del Servidor**: Mejor SEO y tiempo de carga inicial
- **Gestión de Estado**: El backend maneja el estado de la aplicación
- **Seguridad**: Validación y autorización en el servidor
- **Escalabilidad**: Arquitectura preparada para crecimiento

## 📋 Próximos Pasos

1. **Implementar CRUD completo** para productos e inventario
2. **Agregar autenticación y autorización** con Spring Security
3. **Conectar base de datos persistente** (MySQL/PostgreSQL)
4. **Implementar API REST** para integración con frontend React
5. **Agregar validaciones** y manejo de errores
6. **Implementar testing** unitario e integración

## 🤝 Contribución

Este proyecto sigue las mejores prácticas de Spring Boot y está diseñado para ser fácilmente extensible y mantenible.
