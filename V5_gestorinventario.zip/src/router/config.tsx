
import type { RouteObject } from "react-router-dom";
import NotFound from "../pages/NotFound";
import Home from "../pages/home/page";
import Dashboard from "../pages/dashboard/page";
import Requerimientos from "../pages/requerimientos/page";
import OrdenesCompra from "../pages/ordenes-compra/page";
import Reportes from "../pages/reportes/page";
import Productos from "../pages/productos/page";
import Inventario from "../pages/inventario/page";
import Configuracion from "../pages/configuracion/page";

const routes: RouteObject[] = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/dashboard",
    element: <Dashboard />,
  },
  {
    path: "/productos",
    element: <Productos />,
  },
  {
    path: "/inventario",
    element: <Inventario />,
  },
  {
    path: "/requerimientos",
    element: <Requerimientos />,
  },
  {
    path: "/ordenes-compra",
    element: <OrdenesCompra />,
  },
  {
    path: "/reportes",
    element: <Reportes />,
  },
  {
    path: "/configuracion",
    element: <Configuracion />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
];

export default routes;
