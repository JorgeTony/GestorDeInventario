
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Productos() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('todos');
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<any>(null);

  const [user] = useState({
    name: 'María González',
    role: 'Administrador de Inventario',
    avatar: 'https://readdy.ai/api/search-image?query=professional%20woman%20administrator%20inventory%20management%20office%20corporate%20headshot%20clean%20background%20business%20attire%20confident%20smile%20latina&width=40&height=40&seq=1&orientation=squarish'
  });

  const categories = [
    { id: 'todos', name: 'Todos los productos' },
    { id: 'medicamentos', name: 'Medicamentos' },
    { id: 'material-medico', name: 'Material Médico' },
    { id: 'epp', name: 'EPP' },
    { id: 'equipos', name: 'Equipos' },
    { id: 'antisepticos', name: 'Antisépticos' }
  ];

  const products = [
    {
      id: 1,
      name: 'Acetaminofén 500mg',
      code: 'MED-001',
      category: 'Medicamentos',
      stock: 450,
      minStock: 100,
      unitPrice: 2.50,
      totalValue: 1125.00,
      expiryDate: '2025-06-15',
      supplier: 'Farmacéutica ABC',
      status: 'normal',
      image: 'https://readdy.ai/api/search-image?query=acetaminophen%20500mg%20pharmaceutical%20medicine%20tablets%20box%20package%20medical%20healthcare%20product%20clean%20white%20background%20professional&width=60&height=60&seq=1&orientation=squarish'
    },
    {
      id: 2,
      name: 'Jeringa 10ml',
      code: 'MAT-002',
      category: 'Material Médico',
      stock: 1200,
      minStock: 300,
      unitPrice: 0.85,
      totalValue: 1020.00,
      expiryDate: '2026-12-31',
      supplier: 'Equipos Médicos SAC',
      status: 'normal',
      image: 'https://readdy.ai/api/search-image?query=medical%20syringe%2010ml%20disposable%20healthcare%20equipment%20sterile%20medical%20device%20clean%20white%20background%20professional&width=60&height=60&seq=2&orientation=squarish'
    },
    {
      id: 3,
      name: 'Mascarillas N95',
      code: 'EPP-003',
      category: 'EPP',
      stock: 25,
      minStock: 50,
      unitPrice: 3.20,
      totalValue: 80.00,
      expiryDate: '2024-08-30',
      supplier: 'Protección Total EIRL',
      status: 'bajo',
      image: 'https://readdy.ai/api/search-image?query=N95%20face%20mask%20protective%20equipment%20personal%20protection%20healthcare%20medical%20safety%20white%20clean%20background%20professional&width=60&height=60&seq=3&orientation=squarish'
    },
    {
      id: 4,
      name: 'Termómetro Digital',
      code: 'EQU-004',
      category: 'Equipos',
      stock: 8,
      minStock: 10,
      unitPrice: 25.00,
      totalValue: 200.00,
      expiryDate: '2027-03-15',
      supplier: 'TecnoMed Perú',
      status: 'crítico',
      image: 'https://readdy.ai/api/search-image?query=digital%20thermometer%20medical%20equipment%20healthcare%20device%20temperature%20measurement%20clean%20white%20background%20professional%20medical&width=60&height=60&seq=4&orientation=squarish'
    },
    {
      id: 5,
      name: 'Alcohol Etílico 70%',
      code: 'ANT-005',
      category: 'Antisépticos',
      stock: 320,
      minStock: 100,
      unitPrice: 4.50,
      totalValue: 1440.00,
      expiryDate: '2025-11-20',
      supplier: 'Química Farmacéutica',
      status: 'normal',
      image: 'https://readdy.ai/api/search-image?query=ethyl%20alcohol%2070%25%20antiseptic%20bottle%20medical%20disinfectant%20healthcare%20product%20clean%20white%20background%20professional&width=60&height=60&seq=5&orientation=squarish'
    },
    {
      id: 6,
      name: 'Guantes Latex Talla M',
      code: 'EPP-006',
      category: 'EPP',
      stock: 85,
      minStock: 200,
      unitPrice: 0.15,
      totalValue: 12.75,
      expiryDate: '2025-09-10',
      supplier: 'Protección Total EIRL',
      status: 'bajo',
      image: 'https://readdy.ai/api/search-image?query=latex%20gloves%20medium%20size%20medical%20protective%20equipment%20healthcare%20safety%20disposable%20white%20clean%20background%20professional&width=60&height=60&seq=6&orientation=squarish'
    }
  ];

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.code.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'todos' || 
                           product.category.toLowerCase().replace(' ', '-') === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return 'bg-green-100 text-green-700';
      case 'bajo': return 'bg-yellow-100 text-yellow-700';
      case 'crítico': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'normal': return 'Normal';
      case 'bajo': return 'Stock Bajo';
      case 'crítico': return 'Crítico';
      default: return 'Sin definir';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Navigation */}
      <header className="bg-slate-700 shadow-sm">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <i className="ri-archive-line text-white text-lg"></i>
                </div>
                <h1 className="text-xl font-bold text-white">Sistema de Inventarios</h1>
              </div>
              
              {/* Navigation Menu */}
              <nav className="hidden lg:flex items-center space-x-8">
                <button 
                  onClick={() => navigate('/dashboard')}
                  className="text-blue-200 hover:text-white font-medium transition-colors"
                >
                  Dashboard
                </button>
                <button className="text-white bg-blue-600 px-3 py-1 rounded-md font-medium">
                  Productos
                </button>
                <button 
                  onClick={() => navigate('/inventario')}
                  className="text-blue-200 hover:text-white font-medium transition-colors"
                >
                  Inventario
                </button>
                <button 
                  onClick={() => navigate('/reportes')}
                  className="text-blue-200 hover:text-white font-medium transition-colors"
                >
                  Reportes
                </button>
                <button 
                  onClick={() => navigate('/configuracion')}
                  className="text-blue-200 hover:text-white font-medium transition-colors"
                >
                  Configuración
                </button>
              </nav>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <button className="p-2 text-white hover:text-blue-200 relative">
                  <i className="ri-notification-3-line text-xl"></i>
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center">3</span>
                </button>
              </div>
              
              <div className="flex items-center space-x-3">
                <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                <div className="text-sm">
                  <p className="font-medium text-white">{user.name}</p>
                  <p className="text-blue-200">{user.role}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-6 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Gestión de Productos</h2>
          <p className="text-gray-600">Administra el catálogo completo de productos del inventario</p>
        </div>

        {/* Filters and Actions */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between space-y-4 lg:space-y-0">
            <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-4">
              <div className="relative">
                <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <input
                  type="text"
                  placeholder="Buscar productos por nombre o código..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 w-80 text-sm"
                />
              </div>
              
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8 text-sm"
              >
                {categories.map(category => (
                  <option key={category.id} value={category.id}>{category.name}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center space-x-3">
              <button className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 flex items-center space-x-2 whitespace-nowrap">
                <i className="ri-download-line"></i>
                <span>Exportar</span>
              </button>
              
              <button 
                onClick={() => setShowAddProduct(true)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap"
              >
                <i className="ri-add-line"></i>
                <span>Nuevo Producto</span>
              </button>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredProducts.map((product) => (
            <div key={product.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-start space-x-4">
                    <img 
                      src={product.image} 
                      alt={product.name}
                      className="w-16 h-16 rounded-lg object-cover bg-gray-100"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900 mb-1">{product.name}</h3>
                      <p className="text-sm text-gray-600 mb-1">Código: {product.code}</p>
                      <p className="text-sm text-gray-600">{product.category}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(product.status)}`}>
                      {getStatusText(product.status)}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Stock Actual</p>
                    <p className="font-semibold text-gray-900">{product.stock}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Stock Mínimo</p>
                    <p className="font-semibold text-gray-900">{product.minStock}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Precio Unitario</p>
                    <p className="font-semibold text-gray-900">${product.unitPrice}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Valor Total</p>
                    <p className="font-semibold text-gray-900">${product.totalValue}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                  <span>Vence: {product.expiryDate}</span>
                  <span>{product.supplier}</span>
                </div>

                <div className="flex items-center space-x-2">
                  <button 
                    onClick={() => setSelectedProduct(product)}
                    className="flex-1 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm whitespace-nowrap"
                  >
                    Ver Detalles
                  </button>
                  <button className="px-3 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 text-sm">
                    <i className="ri-edit-line"></i>
                  </button>
                  <button className="px-3 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 text-sm">
                    <i className="ri-more-2-line"></i>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <i className="ri-search-line text-4xl text-gray-400 mb-4"></i>
            <p className="text-lg font-medium text-gray-900 mb-2">No se encontraron productos</p>
            <p className="text-gray-600">Intenta con otros términos de búsqueda o filtros</p>
          </div>
        )}
      </div>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900">Detalles del Producto</h2>
                <button 
                  onClick={() => setSelectedProduct(null)}
                  className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
                >
                  <i className="ri-close-line text-xl"></i>
                </button>
              </div>
            </div>
            
            <div className="p-6">
              <div className="flex items-start space-x-6 mb-6">
                <img 
                  src={selectedProduct.image} 
                  alt={selectedProduct.name}
                  className="w-32 h-32 rounded-lg object-cover bg-gray-100"
                />
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{selectedProduct.name}</h3>
                  <p className="text-gray-600 mb-2">Código: {selectedProduct.code}</p>
                  <p className="text-gray-600 mb-4">Categoría: {selectedProduct.category}</p>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(selectedProduct.status)}`}>
                    {getStatusText(selectedProduct.status)}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6 mb-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Stock Actual</label>
                    <p className="text-2xl font-bold text-gray-900">{selectedProduct.stock}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Stock Mínimo</label>
                    <p className="text-lg font-semibold text-gray-900">{selectedProduct.minStock}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Fecha de Vencimiento</label>
                    <p className="text-lg font-semibold text-gray-900">{selectedProduct.expiryDate}</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Precio Unitario</label>
                    <p className="text-2xl font-bold text-green-600">${selectedProduct.unitPrice}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Valor Total</label>
                    <p className="text-lg font-semibold text-gray-900">${selectedProduct.totalValue}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Proveedor</label>
                    <p className="text-lg font-semibold text-gray-900">{selectedProduct.supplier}</p>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end space-x-4 pt-6 border-t border-gray-200">
                <button 
                  onClick={() => setSelectedProduct(null)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 whitespace-nowrap"
                >
                  Cerrar
                </button>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 whitespace-nowrap">
                  Editar Producto
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Product Modal */}
      {showAddProduct && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900">Agregar Nuevo Producto</h2>
                <button 
                  onClick={() => setShowAddProduct(false)}
                  className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
                >
                  <i className="ri-close-line text-xl"></i>
                </button>
              </div>
            </div>
            
            <div className="p-6">
              <form className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Nombre del Producto</label>
                    <input 
                      type="text" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Ej: Acetaminofén 500mg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Código</label>
                    <input 
                      type="text" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Ej: MED-001"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Categoría</label>
                    <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8">
                      <option value="">Seleccionar categoría</option>
                      <option value="medicamentos">Medicamentos</option>
                      <option value="material-medico">Material Médico</option>
                      <option value="epp">EPP</option>
                      <option value="equipos">Equipos</option>
                      <option value="antisepticos">Antisépticos</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Proveedor</label>
                    <input 
                      type="text" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Nombre del proveedor"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Stock Inicial</label>
                    <input 
                      type="number" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="0"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Stock Mínimo</label>
                    <input 
                      type="number" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="0"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Precio Unitario</label>
                    <input 
                      type="number" 
                      step="0.01"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="0.00"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Fecha de Vencimiento</label>
                    <input 
                      type="date" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end space-x-4 pt-6 border-t border-gray-200">
                  <button 
                    type="button"
                    onClick={() => setShowAddProduct(false)}
                    className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 whitespace-nowrap"
                  >
                    Cancelar
                  </button>
                  <button 
                    type="submit"
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 whitespace-nowrap"
                  >
                    Agregar Producto
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
