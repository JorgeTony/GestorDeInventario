
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Home() {
  const navigate = useNavigate();
  const [showNotifications, setShowNotifications] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [user] = useState({
    name: 'María González',
    role: 'Administrador de Inventario',
    avatar: 'https://readdy.ai/api/search-image?query=professional%20woman%20administrator%20inventory%20management%20office%20corporate%20headshot%20clean%20background%20business%20attire%20confident%20smile%20latina&width=40&height=40&seq=1&orientation=squarish'
  });

  const notifications = [
    {
      id: 1,
      title: 'Stock Bajo',
      message: 'Mascarillas N95 requieren reposición urgente',
      time: 'Hace 5 min',
      type: 'warning',
      unread: true
    },
    {
      id: 2,
      title: 'Producto Vencido',
      message: 'Vacuna COVID-19 próxima a vencer',
      time: 'Hace 15 min',
      type: 'error',
      unread: true
    },
    {
      id: 3,
      title: 'Orden Completada',
      message: 'Orden de compra OC-2024-001 recibida',
      time: 'Hace 1 hora',
      type: 'success',
      unread: false
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Navigation */}
      <header className="bg-slate-700 shadow-sm">
        <div className="px-4 lg:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 lg:space-x-6">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <i className="ri-archive-line text-white text-lg"></i>
                </div>
                <h1 className="text-lg lg:text-xl font-bold text-white">Sistema de Inventarios</h1>
              </div>
              
              {/* Desktop Navigation Menu */}
              <nav className="hidden lg:flex items-center space-x-8">
                <button 
                  onClick={() => navigate('/dashboard')}
                  className="text-blue-200 hover:text-white font-medium transition-colors whitespace-nowrap"
                >
                  Dashboard
                </button>
                <button className="text-blue-200 hover:text-white font-medium transition-colors whitespace-nowrap">
                  Productos
                </button>
                <button className="text-blue-200 hover:text-white font-medium transition-colors whitespace-nowrap">
                  Inventario
                </button>
                <button className="text-blue-200 hover:text-white font-medium transition-colors whitespace-nowrap">
                  Reportes
                </button>
                <button className="text-blue-200 hover:text-white font-medium transition-colors whitespace-nowrap">
                  Configuración
                </button>
              </nav>
            </div>
            
            <div className="flex items-center space-x-2 lg:space-x-4">
              {/* Mobile menu button */}
              <button 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 text-white hover:text-blue-200"
              >
                <i className={`${mobileMenuOpen ? 'ri-close-line' : 'ri-menu-line'} text-xl`}></i>
              </button>

              {/* Notifications */}
              <div className="relative">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="p-2 text-white hover:text-blue-200 relative"
                >
                  <i className="ri-notification-3-line text-xl"></i>
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center">
                    {notifications.filter(n => n.unread).length}
                  </span>
                </button>

                {/* Notifications Dropdown */}
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl border border-gray-200 z-50">
                    <div className="p-4 border-b border-gray-100">
                      <h3 className="font-semibold text-gray-900">Notificaciones</h3>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.map((notification) => (
                        <div key={notification.id} className={`p-4 border-b border-gray-100 hover:bg-gray-50 ${notification.unread ? 'bg-blue-50' : ''}`}>
                          <div className="flex items-start space-x-3">
                            <div className={`w-2 h-2 rounded-full mt-2 ${
                              notification.type === 'error' ? 'bg-red-500' :
                              notification.type === 'warning' ? 'bg-yellow-500' :
                              'bg-green-500'
                            }`}></div>
                            <div className="flex-1">
                              <h4 className="font-medium text-gray-900 text-sm">{notification.title}</h4>
                              <p className="text-sm text-gray-600 mt-1">{notification.message}</p>
                              <p className="text-xs text-gray-500 mt-2">{notification.time}</p>
                            </div>
                            {notification.unread && (
                              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="p-4 border-t border-gray-100">
                      <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
                        Ver todas las notificaciones
                      </button>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="hidden lg:flex items-center space-x-3">
                <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                <div className="text-sm">
                  <p className="font-medium text-white">{user.name}</p>
                  <p className="text-blue-200">{user.role}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile Navigation Menu */}
          {mobileMenuOpen && (
            <div className="lg:hidden mt-4 pb-4 border-t border-slate-600">
              <nav className="flex flex-col space-y-2 mt-4">
                <button 
                  onClick={() => {
                    navigate('/dashboard');
                    setMobileMenuOpen(false);
                  }}
                  className="text-blue-200 hover:text-white font-medium transition-colors text-left py-2"
                >
                  Dashboard
                </button>
                <button className="text-blue-200 hover:text-white font-medium transition-colors text-left py-2">
                  Productos
                </button>
                <button className="text-blue-200 hover:text-white font-medium transition-colors text-left py-2">
                  Inventario
                </button>
                <button className="text-blue-200 hover:text-white font-medium transition-colors text-left py-2">
                  Reportes
                </button>
                <button className="text-blue-200 hover:text-white font-medium transition-colors text-left py-2">
                  Configuración
                </button>
              </nav>
              
              {/* Mobile User Info */}
              <div className="flex items-center space-x-3 mt-4 pt-4 border-t border-slate-600">
                <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                <div className="text-sm">
                  <p className="font-medium text-white">{user.name}</p>
                  <p className="text-blue-200">{user.role}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </header>

      <div className="px-4 lg:px-6 py-6 lg:py-8">
        {/* Welcome Section */}
        <div className="mb-6 lg:mb-8">
          <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">Bienvenido, {user.name}</h2>
          <p className="text-gray-600">Gestiona tu inventario de manera eficiente desde el panel de control</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-6 lg:mb-8">
          {[
            { label: 'Productos en Stock', value: '2,847', change: '+12%', trend: 'up' },
            { label: 'Órdenes Pendientes', value: '23', change: '-5%', trend: 'down' },
            { label: 'Valor Total Inventario', value: '$248,500', change: '+8%', trend: 'up' },
            { label: 'Productos Críticos', value: '15', change: '0%', trend: 'neutral' }
          ].map((stat, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">{stat.label}</p>
                  <p className="text-xl lg:text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`flex items-center space-x-1 text-sm ${
                  stat.trend === 'up' ? 'text-green-600' : 
                  stat.trend === 'down' ? 'text-red-600' : 
                  'text-gray-500'
                }`}>
                  {stat.trend === 'up' && <i className="ri-arrow-up-line"></i>}
                  {stat.trend === 'down' && <i className="ri-arrow-down-line"></i>}
                  <span>{stat.change}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Main Modules */}
        <div className="mb-6 lg:mb-8">
          <h3 className="text-lg lg:text-xl font-semibold text-gray-900 mb-4 lg:mb-6">Módulos del Sistema</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
            {[
              {
                id: 'ordenes-compra',
                title: 'Órdenes de compra',
                icon: 'ri-file-list-3-line',
                description: 'Gestión de órdenes de compra y proveedores',
                color: 'bg-blue-50 hover:bg-blue-100',
                iconColor: 'text-blue-600'
              },
              {
                id: 'almacenes',
                title: 'Almacenes',
                icon: 'ri-building-2-line',
                description: 'Control de almacenes y ubicaciones',
                color: 'bg-green-50 hover:bg-green-100',
                iconColor: 'text-green-600'
              },
              {
                id: 'transacciones',
                title: 'Transacciones',
                icon: 'ri-exchange-line',
                description: 'Registro de movimientos y transacciones',
                color: 'bg-purple-50 hover:bg-purple-100',
                iconColor: 'text-purple-600'
              },
              {
                id: 'kardex',
                title: 'Kardex',
                icon: 'ri-bar-chart-box-line',
                description: 'Historial detallado de movimientos',
                color: 'bg-orange-50 hover:bg-orange-100',
                iconColor: 'text-orange-600'
              },
              {
                id: 'dashboard',
                title: 'Dashboard',
                icon: 'ri-dashboard-3-line',
                description: 'Panel de control y métricas',
                color: 'bg-indigo-50 hover:bg-indigo-100',
                iconColor: 'text-indigo-600'
              },
              {
                id: 'inventarios',
                title: 'Inventarios',
                icon: 'ri-archive-line',
                description: 'Control de stock y productos',
                color: 'bg-teal-50 hover:bg-teal-100',
                iconColor: 'text-teal-600'
              },
              {
                id: 'requerimientos',
                title: 'Requerimientos',
                icon: 'ri-task-line',
                description: 'Solicitudes de productos por área',
                color: 'bg-red-50 hover:bg-red-100',
                iconColor: 'text-red-600'
              },
              {
                id: 'catalogo-productos',
                title: 'Catálogo de productos',
                icon: 'ri-book-open-line',
                description: 'Gestión del catálogo de productos',
                color: 'bg-yellow-50 hover:bg-yellow-100',
                iconColor: 'text-yellow-600'
              },
              {
                id: 'linea-producto',
                title: 'Línea y familia del producto',
                icon: 'ri-node-tree',
                description: 'Organización por líneas y familias',
                color: 'bg-pink-50 hover:bg-pink-100',
                iconColor: 'text-pink-600'
              }
            ].map((module) => (
              <div
                key={module.id}
                className={`${module.color} rounded-xl p-4 lg:p-6 border border-gray-200 cursor-pointer transition-all duration-200 hover-shadow-md`}
              >
                <div className="flex items-start space-x-3 lg:space-x-4">
                  <div className={`w-10 h-10 lg:w-12 lg:h-12 rounded-lg bg-white flex items-center justify-center ${module.iconColor}`}>
                    <i className={`${module.icon} text-lg lg:text-xl`}></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-gray-900 mb-1 lg:mb-2 text-sm lg:text-base">{module.title}</h4>
                    <p className="text-xs lg:text-sm text-gray-600">{module.description}</p>
                  </div>
                  <i className="ri-arrow-right-s-line text-gray-400 text-lg"></i>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-xl shadow-sm p-4 lg:p-6 border border-gray-100">
          <h3 className="text-base lg:text-lg font-semibold text-gray-900 mb-4">Acciones Rápidas</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
            <button className="flex items-center space-x-2 lg:space-x-3 p-3 lg:p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors">
              <i className="ri-add-line text-blue-600 text-lg"></i>
              <span className="font-medium text-blue-700 text-sm lg:text-base">Nuevo Requerimiento</span>
            </button>
            
            <button className="flex items-center space-x-2 lg:space-x-3 p-3 lg:p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors">
              <i className="ri-shopping-cart-line text-green-600 text-lg"></i>
              <span className="font-medium text-green-700 text-sm lg:text-base">Crear Orden de Compra</span>
            </button>
            
            <button className="flex items-center space-x-2 lg:space-x-3 p-3 lg:p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors">
              <i className="ri-truck-line text-purple-600 text-lg"></i>
              <span className="font-medium text-purple-700 text-sm lg:text-base">Registrar Recepción</span>
            </button>
            
            <button className="flex items-center space-x-2 lg:space-x-3 p-3 lg:p-4 bg-orange-50 hover:bg-orange-100 rounded-lg transition-colors">
              <i className="ri-file-chart-line text-orange-600 text-lg"></i>
              <span className="font-medium text-orange-700 text-sm lg:text-base">Generar Reporte</span>
            </button>
          </div>
        </div>
      </div>

      {/* Click outside to close notifications */}
      {showNotifications && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowNotifications(false)}
        ></div>
      )}
    </div>
  );
}