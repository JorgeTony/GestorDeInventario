
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Inventario() {
  const navigate = useNavigate();
  const [selectedView, setSelectedView] = useState('stock');
  const [selectedWarehouse, setSelectedWarehouse] = useState('todos');
  const [showMovementModal, setShowMovementModal] = useState(false);
  const [movementType, setMovementType] = useState('entrada');

  const [user] = useState({
    name: 'María González',
    role: 'Administrador de Inventario',
    avatar: 'https://readdy.ai/api/search-image?query=professional%20woman%20administrator%20inventory%20management%20office%20corporate%20headshot%20clean%20background%20business%20attire%20confident%20smile%20latina&width=40&height=40&seq=1&orientation=squarish'
  });

  const warehouses = [
    { id: 'todos', name: 'Todos los almacenes' },
    { id: 'principal', name: 'Almacén Principal' },
    { id: 'emergencia', name: 'Almacén de Emergencia' },
    { id: 'farmacia', name: 'Farmacia Central' },
    { id: 'quirofano', name: 'Stock Quirófano' }
  ];

  const views = [
    { id: 'stock', label: 'Estado de Stock', icon: 'ri-archive-line' },
    { id: 'movimientos', label: 'Movimientos', icon: 'ri-exchange-line' },
    { id: 'ubicaciones', label: 'Ubicaciones', icon: 'ri-map-pin-line' },
    { id: 'alertas', label: 'Alertas', icon: 'ri-alert-line' }
  ];

  const stockData = [
    {
      product: 'Acetaminofén 500mg',
      code: 'MED-001',
      category: 'Medicamentos',
      warehouse: 'Almacén Principal',
      currentStock: 450,
      minStock: 100,
      maxStock: 1000,
      reserved: 25,
      available: 425,
      lastMovement: '2024-01-15',
      status: 'normal'
    },
    {
      product: 'Mascarillas N95',
      code: 'EPP-003',
      category: 'EPP',
      warehouse: 'Almacén Principal',
      currentStock: 25,
      minStock: 50,
      maxStock: 500,
      reserved: 5,
      available: 20,
      lastMovement: '2024-01-14',
      status: 'bajo'
    },
    {
      product: 'Termómetro Digital',
      code: 'EQU-004',
      category: 'Equipos',
      warehouse: 'Farmacia Central',
      currentStock: 8,
      minStock: 10,
      maxStock: 50,
      reserved: 2,
      available: 6,
      lastMovement: '2024-01-13',
      status: 'crítico'
    }
  ];

  const movements = [
    {
      id: 1,
      date: '2024-01-15',
      time: '14:30',
      product: 'Acetaminofén 500mg',
      type: 'entrada',
      quantity: 150,
      reason: 'Compra',
      user: 'María González',
      warehouse: 'Almacén Principal',
      reference: 'OC-2024-001'
    },
    {
      id: 2,
      date: '2024-01-15',
      time: '11:15',
      product: 'Jeringa 10ml',
      type: 'salida',
      quantity: 85,
      reason: 'Uso médico',
      user: 'Carlos Ruiz',
      warehouse: 'Quirófano',
      reference: 'REQ-2024-045'
    },
    {
      id: 3,
      date: '2024-01-14',
      time: '16:20',
      product: 'Alcohol Etílico 70%',
      type: 'transferencia',
      quantity: 50,
      reason: 'Transferencia entre almacenes',
      user: 'Ana López',
      warehouse: 'Farmacia Central',
      reference: 'TRF-2024-012'
    }
  ];

  const alerts = [
    {
      id: 1,
      type: 'stock_bajo',
      product: 'Mascarillas N95',
      message: 'Stock por debajo del mínimo requerido',
      severity: 'alta',
      warehouse: 'Almacén Principal',
      date: '2024-01-15'
    },
    {
      id: 2,
      type: 'vencimiento',
      product: 'Vacuna COVID-19',
      message: 'Próximo a vencer en 8 días',
      severity: 'crítica',
      warehouse: 'Farmacia Central',
      date: '2024-01-15'
    },
    {
      id: 3,
      type: 'stock_crítico',
      product: 'Termómetro Digital',
      message: 'Stock crítico - Reposición urgente',
      severity: 'crítica',
      warehouse: 'Farmacia Central',
      date: '2024-01-14'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return 'bg-green-100 text-green-700';
      case 'bajo': return 'bg-yellow-100 text-yellow-700';
      case 'crítico': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getMovementTypeColor = (type: string) => {
    switch (type) {
      case 'entrada': return 'bg-green-100 text-green-700';
      case 'salida': return 'bg-red-100 text-red-700';
      case 'transferencia': return 'bg-blue-100 text-blue-700';
      case 'ajuste': return 'bg-purple-100 text-purple-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'crítica': return 'bg-red-100 text-red-700 border-red-200';
      case 'alta': return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'media': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const renderContent = () => {
    switch (selectedView) {
      case 'stock':
        return (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-6 border-b border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900">Estado Actual del Stock</h3>
              <p className="text-sm text-gray-600">Información detallada del inventario por almacén</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Producto</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Almacén</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Disponible</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {stockData.map((item, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div>
                          <div className="text-sm font-medium text-gray-900">{item.product}</div>
                          <div className="text-sm text-gray-500">{item.code} • {item.category}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-900">{item.warehouse}</td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">
                          <div className="font-medium">{item.currentStock}</div>
                          <div className="text-xs text-gray-500">Min: {item.minStock} | Max: {item.maxStock}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">
                          <div className="font-medium">{item.available}</div>
                          <div className="text-xs text-gray-500">Reservado: {item.reserved}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(item.status)}`}>
                          {item.status === 'normal' ? 'Normal' : 
                           item.status === 'bajo' ? 'Stock Bajo' : 'Crítico'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <button className="p-1 text-blue-600 hover:bg-blue-50 rounded">
                            <i className="ri-edit-line"></i>
                          </button>
                          <button 
                            onClick={() => setShowMovementModal(true)}
                            className="p-1 text-green-600 hover:bg-green-50 rounded"
                          >
                            <i className="ri-add-line"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'movimientos':
        return (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Últimos Movimientos</h3>
                  <p className="text-sm text-gray-600">Historial de entradas, salidas y transferencias</p>
                </div>
                <button 
                  onClick={() => setShowMovementModal(true)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap"
                >
                  <i className="ri-add-line"></i>
                  <span>Nuevo Movimiento</span>
                </button>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha/Hora</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Producto</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tipo</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cantidad</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Usuario</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Referencia</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {movements.map((movement) => (
                    <tr key={movement.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">
                          <div className="font-medium">{movement.date}</div>
                          <div className="text-gray-500">{movement.time}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">
                          <div className="font-medium">{movement.product}</div>
                          <div className="text-gray-500">{movement.warehouse}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getMovementTypeColor(movement.type)}`}>
                          {movement.type.charAt(0).toUpperCase() + movement.type.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-sm font-medium ${
                          movement.type === 'entrada' ? 'text-green-600' : 
                          movement.type === 'salida' ? 'text-red-600' : 'text-blue-600'
                        }`}>
                          {movement.type === 'entrada' ? '+' : movement.type === 'salida' ? '-' : ''}
                          {movement.quantity}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-900">{movement.user}</td>
                      <td className="px-6 py-4 text-sm text-gray-500">{movement.reference}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'alertas':
        return (
          <div className="space-y-4">
            {alerts.map((alert) => (
              <div key={alert.id} className={`border rounded-xl p-6 ${getSeverityColor(alert.severity)}`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      <i className={`${
                        alert.type === 'stock_bajo' ? 'ri-arrow-down-line' :
                        alert.type === 'vencimiento' ? 'ri-time-line' :
                        alert.type === 'stock_crítico' ? 'ri-alert-line' : 'ri-error-warning-line'
                      } text-2xl`}></i>
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-lg mb-1">{alert.product}</h4>
                      <p className="text-sm mb-2">{alert.message}</p>
                      <div className="flex items-center space-x-4 text-sm">
                        <span>📍 {alert.warehouse}</span>
                        <span>📅 {alert.date}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button className="px-3 py-1 bg-white text-gray-700 rounded-lg hover:bg-gray-50 text-sm border">
                      Revisar
                    </button>
                    <button className="px-3 py-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm">
                      Resolver
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        );

      default:
        return (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
            <i className="ri-map-pin-line text-4xl text-gray-400 mb-4"></i>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Gestión de Ubicaciones</h3>
            <p className="text-gray-600">Funcionalidad de ubicaciones en desarrollo</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Navigation */}
      <header className="bg-slate-700 shadow-sm">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <i className="ri-archive-line text-white text-lg"></i>
                </div>
                <h1 className="text-xl font-bold text-white">Sistema de Inventarios</h1>
              </div>
              
              {/* Navigation Menu */}
              <nav className="hidden lg:flex items-center space-x-8">
                <button 
                  onClick={() => navigate('/dashboard')}
                  className="text-blue-200 hover:text-white font-medium transition-colors"
                >
                  Dashboard
                </button>
                <button 
                  onClick={() => navigate('/productos')}
                  className="text-blue-200 hover:text-white font-medium transition-colors"
                >
                  Productos
                </button>
                <button className="text-white bg-blue-600 px-3 py-1 rounded-md font-medium">
                  Inventario
                </button>
                <button 
                  onClick={() => navigate('/reportes')}
                  className="text-blue-200 hover:text-white font-medium transition-colors"
                >
                  Reportes
                </button>
                <button 
                  onClick={() => navigate('/configuracion')}
                  className="text-blue-200 hover:text-white font-medium transition-colors"
                >
                  Configuración
                </button>
              </nav>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <button className="p-2 text-white hover:text-blue-200 relative">
                  <i className="ri-notification-3-line text-xl"></i>
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center">3</span>
                </button>
              </div>
              
              <div className="flex items-center space-x-3">
                <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                <div className="text-sm">
                  <p className="font-medium text-white">{user.name}</p>
                  <p className="text-blue-200">{user.role}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-6 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Control de Inventario</h2>
          <p className="text-gray-600">Monitorea y gestiona el stock en tiempo real</p>
        </div>

        {/* Tabs */}
        <div className="mb-8">
          <div className="flex items-center space-x-1 bg-gray-100 p-1 rounded-lg w-fit">
            {views.map((view) => (
              <button
                key={view.id}
                onClick={() => setSelectedView(view.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-md font-medium transition-colors whitespace-nowrap ${
                  selectedView === view.id
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <i className={`${view.icon} text-lg`}></i>
                <span>{view.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium text-gray-700">Almacén:</label>
              <select 
                value={selectedWarehouse} 
                onChange={(e) => setSelectedWarehouse(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8"
              >
                {warehouses.map(warehouse => (
                  <option key={warehouse.id} value={warehouse.id}>{warehouse.name}</option>
                ))}
              </select>
            </div>
          </div>
          
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap">
            <i className="ri-download-line"></i>
            <span>Exportar</span>
          </button>
        </div>

        {/* Content */}
        {renderContent()}
      </div>

      {/* Movement Modal */}
      {showMovementModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900">Registrar Movimiento</h2>
                <button 
                  onClick={() => setShowMovementModal(false)}
                  className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
                >
                  <i className="ri-close-line text-xl"></i>
                </button>
              </div>
            </div>
            
            <div className="p-6">
              <form className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Tipo de Movimiento</label>
                    <select 
                      value={movementType} 
                      onChange={(e) => setMovementType(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8"
                    >
                      <option value="entrada">Entrada</option>
                      <option value="salida">Salida</option>
                      <option value="transferencia">Transferencia</option>
                      <option value="ajuste">Ajuste</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Producto</label>
                    <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8">
                      <option value="">Seleccionar producto</option>
                      <option value="1">Acetaminofén 500mg</option>
                      <option value="2">Jeringa 10ml</option>
                      <option value="3">Mascarillas N95</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Cantidad</label>
                    <input 
                      type="number" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="0"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Almacén</label>
                    <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8">
                      <option value="principal">Almacén Principal</option>
                      <option value="emergencia">Almacén de Emergencia</option>
                      <option value="farmacia">Farmacia Central</option>
                      <option value="quirofano">Stock Quirófano</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Motivo</label>
                  <input 
                    type="text" 
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Describir el motivo del movimiento"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Observaciones</label>
                  <textarea 
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Observaciones adicionales (opcional)"
                  ></textarea>
                </div>

                <div className="flex items-center justify-end space-x-4 pt-6 border-t border-gray-200">
                  <button 
                    type="button"
                    onClick={() => setShowMovementModal(false)}
                    className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 whitespace-nowrap"
                  >
                    Cancelar
                  </button>
                  <button 
                    type="submit"
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 whitespace-nowrap"
                  >
                    Registrar Movimiento
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
