
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Home() {
  const navigate = useNavigate();
  const [showReportModal, setShowReportModal] = useState(false);
  const [selectedReportType, setSelectedReportType] = useState('');
  const [reportDateRange, setReportDateRange] = useState('30d');

  const modules = [
    {
      id: 'ordenes-compra',
      title: 'Órdenes de compra',
      icon: 'ri-file-list-3-line',
      description: 'Gestión de órdenes de compra y proveedores',
      color: 'bg-blue-50 hover:bg-blue-100',
      iconColor: 'text-blue-600'
    },
    {
      id: 'almacenes',
      title: 'Almacenes',
      icon: 'ri-building-2-line',
      description: 'Control de almacenes y ubicaciones',
      color: 'bg-green-50 hover:bg-green-100',
      iconColor: 'text-green-600'
    },
    {
      id: 'transacciones',
      title: 'Transacciones',
      icon: 'ri-exchange-line',
      description: 'Registro de movimientos y transacciones',
      color: 'bg-purple-50 hover:bg-purple-100',
      iconColor: 'text-purple-600'
    },
    {
      id: 'kardex',
      title: 'Kardex',
      icon: 'ri-bar-chart-box-line',
      description: 'Historial detallado de movimientos',
      color: 'bg-orange-50 hover:bg-orange-100',
      iconColor: 'text-orange-600'
    },
    {
      id: 'dashboard',
      title: 'Dashboard',
      icon: 'ri-dashboard-3-line',
      description: 'Panel de control y métricas',
      color: 'bg-indigo-50 hover:bg-indigo-100',
      iconColor: 'text-indigo-600'
    },
    {
      id: 'inventarios',
      title: 'Inventarios',
      icon: 'ri-archive-line',
      description: 'Control de stock y productos',
      color: 'bg-teal-50 hover:bg-teal-100',
      iconColor: 'text-teal-600'
    },
    {
      id: 'requerimientos',
      title: 'Requerimientos',
      icon: 'ri-task-line',
      description: 'Solicitudes de productos por área',
      color: 'bg-red-50 hover:bg-red-100',
      iconColor: 'text-red-600'
    },
    {
      id: 'catalogo-productos',
      title: 'Catálogo de productos',
      icon: 'ri-book-open-line',
      description: 'Gestión del catálogo de productos',
      color: 'bg-yellow-50 hover:bg-yellow-100',
      iconColor: 'text-yellow-600'
    },
    {
      id: 'linea-producto',
      title: 'Línea y familia del producto',
      icon: 'ri-node-tree',
      description: 'Organización por líneas y familias',
      color: 'bg-pink-50 hover:bg-pink-100',
      iconColor: 'text-pink-600'
    }
  ];

  const [user] = useState({
    name: 'María González',
    role: 'Administrador de Inventario',
    avatar: 'https://readdy.ai/api/search-image?query=professional%20woman%20administrator%20inventory%20management%20office%20corporate%20headshot%20clean%20background%20business%20attire%20confident%20smile%20latina&width=40&height=40&seq=1&orientation=squarish'
  });

  const quickStats = [
    { label: 'Productos en Stock', value: '2,847', change: '+12%', trend: 'up' },
    { label: 'Órdenes Pendientes', value: '23', change: '-5%', trend: 'down' },
    { label: 'Valor Total Inventario', value: '$248,500', change: '+8%', trend: 'up' },
    { label: 'Productos Críticos', value: '15', change: '0%', trend: 'neutral' }
  ];

  const reportTypes = [
    {
      id: 'stock-costo',
      title: 'Stock Total vs Costo',
      description: 'Reporte completo del inventario con valores monetarios',
      icon: 'ri-money-dollar-circle-line',
      color: 'text-green-600'
    },
    {
      id: 'mayor-rotacion',
      title: 'Productos de Mayor Rotación',
      description: 'Análisis de productos más utilizados',
      icon: 'ri-refresh-line',
      color: 'text-blue-600'
    },
    {
      id: 'proximos-vencer',
      title: 'Productos Próximos a Vencer',
      description: 'Lista de productos con fechas de vencimiento cercanas',
      icon: 'ri-time-line',
      color: 'text-orange-600'
    },
    {
      id: 'bajo-stock',
      title: 'Productos con Bajo Stock',
      description: 'Productos que requieren reposición inmediata',
      icon: 'ri-alert-line',
      color: 'text-red-600'
    },
    {
      id: 'movimientos',
      title: 'Reporte de Movimientos',
      description: 'Historial completo de entradas y salidas',
      icon: 'ri-exchange-line',
      color: 'text-purple-600'
    },
    {
      id: 'ordenes-compra',
      title: 'Órdenes de Compra',
      description: 'Estado y seguimiento de órdenes de compra',
      icon: 'ri-file-list-3-line',
      color: 'text-indigo-600'
    }
  ];

  const handleGenerateReport = () => {
    if (!selectedReportType) {
      alert('Por favor selecciona un tipo de reporte');
      return;
    }

    // Simular generación de reporte
    const reportData = {
      type: selectedReportType,
      dateRange: reportDateRange,
      generatedAt: new Date().toISOString(),
      filename: `reporte_${selectedReportType}_${new Date().toISOString().split('T')[0]}.pdf`
    };

    // Aquí se implementaría la lógica real de generación
    console.log('Generando reporte:', reportData);
    
    // Simular descarga
    alert(`Reporte "${reportTypes.find(r => r.id === selectedReportType)?.title}" generado exitosamente`);
    setShowReportModal(false);
    setSelectedReportType('');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Navigation */}
      <header className="bg-slate-700 shadow-sm">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <i className="ri-archive-line text-white text-lg"></i>
                </div>
                <h1 className="text-xl font-bold text-white">Sistema de Inventarios</h1>
              </div>
              
              {/* Navigation Menu */}
              <nav className="hidden lg:flex items-center space-x-8">
                <button 
                  onClick={() => navigate('/dashboard')}
                  className="text-white hover:text-blue-200 font-medium transition-colors"
                >
                  Dashboard
                </button>
                <button 
                  onClick={() => navigate('/productos')}
                  className="text-white hover:text-blue-200 font-medium transition-colors"
                >
                  Productos
                </button>
                <button 
                  onClick={() => navigate('/inventario')}
                  className="text-white hover:text-blue-200 font-medium transition-colors"
                >
                  Inventario
                </button>
                <button 
                  onClick={() => navigate('/reportes')}
                  className="text-white hover:text-blue-200 font-medium transition-colors"
                >
                  Reportes
                </button>
                <button 
                  onClick={() => navigate('/configuracion')}
                  className="text-white hover:text-blue-200 font-medium transition-colors"
                >
                  Configuración
                </button>
              </nav>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <button className="p-2 text-white hover:text-blue-200 relative">
                  <i className="ri-notification-3-line text-xl"></i>
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center">3</span>
                </button>
              </div>
              
              <div className="flex items-center space-x-3">
                <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                <div className="text-sm">
                  <p className="font-medium text-white">{user.name}</p>
                  <p className="text-blue-200">{user.role}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Bienvenido, {user.name}</h2>
          <p className="text-gray-600">Gestiona tu inventario de manera eficiente desde el panel de control</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {quickStats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`flex items-center space-x-1 text-sm ${
                  stat.trend === 'up' ? 'text-green-600' : 
                  stat.trend === 'down' ? 'text-red-600' : 
                  'text-gray-500'
                }`}>
                  {stat.trend === 'up' && <i className="ri-arrow-up-line"></i>}
                  {stat.trend === 'down' && <i className="ri-arrow-down-line"></i>}
                  <span>{stat.change}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Main Modules */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Módulos del Sistema</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {modules.map((module) => (
              <div
                key={module.id}
                className={`${module.color} rounded-xl p-6 border border-gray-200 cursor-pointer transition-all duration-200 hover:shadow-md`}
                onClick={() => navigate(`/${module.id}`)}
              >
                <div className="flex items-start space-x-4">
                  <div className={`w-12 h-12 rounded-lg bg-white flex items-center justify-center ${module.iconColor}`}>
                    <i className={`${module.icon} text-xl`}></i>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-2">{module.title}</h4>
                    <p className="text-sm text-gray-600">{module.description}</p>
                  </div>
                  <i className="ri-arrow-right-s-line text-gray-400 text-lg"></i>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Acciones Rápidas</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <button 
              onClick={() => navigate('/requerimientos')}
              className="flex items-center space-x-3 p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors whitespace-nowrap"
            >
              <i className="ri-add-line text-blue-600 text-lg"></i>
              <span className="font-medium text-blue-700">Nuevo Requerimiento</span>
            </button>
            
            <button 
              onClick={() => navigate('/ordenes-compra')}
              className="flex items-center space-x-3 p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors whitespace-nowrap"
            >
              <i className="ri-shopping-cart-line text-green-600 text-lg"></i>
              <span className="font-medium text-green-700">Crear Orden de Compra</span>
            </button>
            
            <button className="flex items-center space-x-3 p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors whitespace-nowrap">
              <i className="ri-truck-line text-purple-600 text-lg"></i>
              <span className="font-medium text-purple-700">Registrar Recepción</span>
            </button>
            
            <button 
              onClick={() => setShowReportModal(true)}
              className="flex items-center space-x-3 p-4 bg-orange-50 hover:bg-orange-100 rounded-lg transition-colors whitespace-nowrap"
            >
              <i className="ri-file-chart-line text-orange-600 text-lg"></i>
              <span className="font-medium text-orange-700">Generar Reporte</span>
            </button>
          </div>
        </div>
      </div>

      {/* Report Generation Modal */}
      {showReportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900">Generar Reporte</h2>
                <button 
                  onClick={() => setShowReportModal(false)}
                  className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
                >
                  <i className="ri-close-line text-xl"></i>
                </button>
              </div>
            </div>
            
            <div className="p-6">
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Tipo de Reporte
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {reportTypes.map((report) => (
                      <div
                        key={report.id}
                        className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                          selectedReportType === report.id
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => setSelectedReportType(report.id)}
                      >
                        <div className="flex items-start space-x-3">
                          <div className={`w-8 h-8 flex items-center justify-center ${report.color}`}>
                            <i className={`${report.icon} text-lg`}></i>
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900 mb-1">{report.title}</h4>
                            <p className="text-sm text-gray-600">{report.description}</p>
                          </div>
                          {selectedReportType === report.id && (
                            <i className="ri-check-line text-blue-600 text-lg"></i>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Período de Tiempo
                  </label>
                  <select 
                    value={reportDateRange} 
                    onChange={(e) => setReportDateRange(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8"
                  >
                    <option value="7d">Últimos 7 días</option>
                    <option value="30d">Últimos 30 días</option>
                    <option value="90d">Últimos 90 días</option>
                    <option value="6m">Últimos 6 meses</option>
                    <option value="1y">Último año</option>
                    <option value="custom">Período personalizado</option>
                  </select>
                </div>

                {reportDateRange === 'custom' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Fecha Inicio
                      </label>
                      <input 
                        type="date" 
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Fecha Fin
                      </label>
                      <input 
                        type="date" 
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Formato de Exportación
                  </label>
                  <div className="flex items-center space-x-4">
                    <label className="flex items-center">
                      <input type="radio" name="format" value="pdf" defaultChecked className="mr-2" />
                      <span className="text-sm">PDF</span>
                    </label>
                    <label className="flex items-center">
                      <input type="radio" name="format" value="excel" className="mr-2" />
                      <span className="text-sm">Excel</span>
                    </label>
                    <label className="flex items-center">
                      <input type="radio" name="format" value="csv" className="mr-2" />
                      <span className="text-sm">CSV</span>
                    </label>
                  </div>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-start space-x-3">
                    <i className="ri-information-line text-blue-600 text-lg mt-0.5"></i>
                    <div>
                      <h4 className="font-medium text-blue-900 mb-1">Información del Reporte</h4>
                      <p className="text-sm text-blue-700">
                        {selectedReportType ? 
                          reportTypes.find(r => r.id === selectedReportType)?.description :
                          'Selecciona un tipo de reporte para ver más información'
                        }
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end space-x-4 pt-6 mt-6 border-t border-gray-200">
                <button 
                  onClick={() => setShowReportModal(false)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 whitespace-nowrap"
                >
                  Cancelar
                </button>
                <button 
                  onClick={handleGenerateReport}
                  disabled={!selectedReportType}
                  className={`px-4 py-2 rounded-lg whitespace-nowrap flex items-center space-x-2 ${
                    selectedReportType 
                      ? 'bg-blue-600 text-white hover:bg-blue-700' 
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  <i className="ri-download-line"></i>
                  <span>Generar y Descargar</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
